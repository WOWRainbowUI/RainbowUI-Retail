# Changelog

## Release

- Fixed General tab Blizzard CT logic:
- `Enable Blizzard CT In Group` now only controls Blizzard CT while grouped.
- `Disable Blizzard CT While Solo` now only controls Blizzard CT while solo.
- Resolved the bug where enabling group Blizzard CT could incorrectly disable Blizzard CT in solo.
