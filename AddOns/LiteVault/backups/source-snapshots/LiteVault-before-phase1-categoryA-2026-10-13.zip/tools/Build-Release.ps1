[CmdletBinding()]
param(
    [string]$OutputDirectory = (Join-Path $PSScriptRoot '..\dist')
)

$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory)
$stageRoot = Join-Path $OutputDirectory 'LiteVault'
$zipPath = Join-Path $OutputDirectory 'LiteVault.zip'

$excludedTopLevel = @(
    'backups', '.agents', '.git', '.github', '.vscode', 'tools', 'dist'
)
$excludedFiles = @(
    '.pkgmeta', 'ClaudeOPUS4.5.ps1', 'CLAUDE_md', 'GOLDTRACKER_RULES.md',
    'STABILITY_TEST_CHECKLIST.md'
)

function Test-ForbiddenPackagePath {
    param([Parameter(Mandatory)][string]$RelativePath)

    $normalized = $RelativePath.Replace('\', '/')
    $segments = $normalized.Split('/')
    if ($segments | Where-Object { $_ -in @('.git', '.agents', '.github', '.vscode', 'backups') }) { return $true }
    if ($normalized -match '(^|/)Libs/LibStub/tests(/|$)') { return $true }
    if ($normalized -match 'SavedVariables') { return $true }
    if ($normalized -match '\.(?:lua\.)?bak$') { return $true }
    if ($normalized -match '\.obj$') { return $true }
    if ($normalized -match '\.zip$') { return $true }
    if ((Split-Path $normalized -Leaf) -in $excludedFiles) { return $true }
    return $false
}

New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null
if (Test-Path -LiteralPath $stageRoot) { Remove-Item -LiteralPath $stageRoot -Recurse -Force }
if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }
New-Item -ItemType Directory -Force -Path $stageRoot | Out-Null

Get-ChildItem -LiteralPath $projectRoot -Recurse -File | ForEach-Object {
    $relative = $_.FullName.Substring($projectRoot.Length + 1)
    $topLevel = $relative.Split([IO.Path]::DirectorySeparatorChar)[0]
    if ($topLevel -in $excludedTopLevel -or $_.Name -in $excludedFiles -or (Test-ForbiddenPackagePath $relative)) { return }

    $destination = Join-Path $stageRoot $relative
    New-Item -ItemType Directory -Force -Path (Split-Path $destination -Parent) | Out-Null
    Copy-Item -LiteralPath $_.FullName -Destination $destination
}

$forbidden = @(Get-ChildItem -LiteralPath $stageRoot -Recurse -File | ForEach-Object {
    $relative = $_.FullName.Substring($stageRoot.Length + 1)
    if (Test-ForbiddenPackagePath $relative) { $relative.Replace('\', '/') }
})
if ($forbidden.Count -gt 0) {
    $forbidden | Sort-Object -Unique | ForEach-Object { Write-Error "Forbidden package path: $_" }
    throw 'Release validation failed.'
}

Compress-Archive -LiteralPath $stageRoot -DestinationPath $zipPath -CompressionLevel Optimal
Write-Output "Release package validated: LiteVault.zip"
