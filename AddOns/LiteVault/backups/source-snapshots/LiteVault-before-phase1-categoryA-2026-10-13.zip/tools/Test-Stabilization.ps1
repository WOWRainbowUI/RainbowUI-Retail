﻿[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$failures = @()

function Assert-Source {
    param([string]$File, [string]$Pattern, [string]$Message, [switch]$Absent)
    $text = Get-Content -LiteralPath (Join-Path $root $File) -Raw -Encoding UTF8
    $matched = $text -match $Pattern
    if (($Absent -and $matched) -or (-not $Absent -and -not $matched)) { $script:failures += $Message }
}

$tocLuaFiles = Get-Content -LiteralPath (Join-Path $root 'LiteVault.toc') -Encoding UTF8 |
    Where-Object { $_ -match '\.lua\s*$' -and $_ -notmatch '^\s*#' } |
    ForEach-Object { Join-Path $root $_.Trim() }

$removedBlizzardGlobals = @(
    'GetItemCount',
    'GetItemInfo',
    'GetItemInfoInstant',
    'GetItemQualityColor',
    'GetDetailedItemLevelInfo',
    'GetItemIcon',
    'GetCoinTextureString'
)
foreach ($luaFile in $tocLuaFiles) {
    $luaSource = Get-Content -LiteralPath $luaFile -Raw -Encoding UTF8
    foreach ($apiName in $removedBlizzardGlobals) {
        $bareGlobalPattern = '(?<![\w.])' + [regex]::Escape($apiName) + '\b'
        if ($luaSource -match $bareGlobalPattern) {
            $relativeLuaPath = [IO.Path]::GetRelativePath($root, $luaFile)
            $failures += "Removed Blizzard global $apiName remains in TOC-loaded file $relativeLuaPath."
        }
    }
}

Assert-Source 'Core.lua' 'local db = LiteVaultDB\[lv\.PLAYER_KEY\][\s\S]*db\.class = select\(2, UnitClass\("player"\)\) or db\.class[\s\S]*db\.region = lv\.REGION[\s\S]*ProcessCharacterWeeklyAndMonthlyResets\(db, lastResetTime, d\)' 'Current character class and region are not initialized before weekly reset processing.'
Assert-Source 'Core.lua' 'ProcessCharacterWeeklyAndMonthlyResets\(db, lastResetTime, d\)[\s\S]*UpdateCurrentVaultSnapshot\(db\)[\s\S]*db\.gold = GetMoney\(\)' 'Weekly reset and vault initialization no longer precede general character-data collection.'
Assert-Source 'Core.lua' 'if needsGlobalReset then[\s\S]*db\.lastWeeklyReset = lastResetTime[\s\S]*LiteVaultDB\.accountWideWeeklyQuests = nil' 'The initiating character record can retain a stale weekly reset timestamp.'
Assert-Source 'Core.lua' 'function lv\.RunCurrentCharacterRefresh\(\)[\s\S]*xpcall\(lv\.UpdateCurrentCharData, geterrorhandler\(\)\)' 'Character refresh no longer preserves stack traces through WoW''s error handler.'
Assert-Source 'Core.lua' 'C_Item\.GetItemCount\(' 'C_Item.GetItemCount migration is missing.'
Assert-Source 'Core.lua' 'C_Item\.GetItemInfo\(' 'C_Item.GetItemInfo migration is missing.'
Assert-Source 'Core.lua' 'C_Item\.GetItemInfoInstant\(' 'C_Item.GetItemInfoInstant migration is missing.'
Assert-Source 'Core.lua' 'C_Item\.GetDetailedItemLevelInfo\(' 'C_Item.GetDetailedItemLevelInfo migration is missing.'
Assert-Source 'Utils.lua' 'C_Item\.GetItemQualityColor\(' 'C_Item.GetItemQualityColor migration is missing.'
Assert-Source 'List.lua' 'C_Item\.GetItemIconByID\(' 'C_Item.GetItemIconByID migration is missing.'
Assert-Source 'Core.lua' 'C_CurrencyInfo\.GetCoinTextureString\(' 'C_CurrencyInfo.GetCoinTextureString migration is missing.'
Assert-Source 'LiteVault.toc' '## Interface: 120001, 120005, 120007, 120100, 120105' 'TOC interface 120105 is missing.'

if ($failures.Count -gt 0) {
    $failures | ForEach-Object { Write-Error $_ }
    throw '12.1.5 compatibility preflight failed.'
}

$luaCompiler = $null
if ($env:LITEVAULT_LUAC51 -and (Test-Path -LiteralPath $env:LITEVAULT_LUAC51)) {
    $luaCompiler = $env:LITEVAULT_LUAC51
} else {
    foreach ($candidate in @('luac5.1','luac51','luac')) {
        $command = Get-Command $candidate -ErrorAction SilentlyContinue
        if ($command) { $luaCompiler = $command.Source; break }
    }
}
if (-not $luaCompiler) {
    throw 'Lua 5.1 compiler not found. Set LITEVAULT_LUAC51 to luac 5.1; compilation is required to catch WoW upvalue-limit failures.'
}
$luaCompilerVersion = (& $luaCompiler -v 2>&1 | Out-String)
if ($luaCompilerVersion -notmatch 'Lua 5\.1') {
    throw "Lua compiler must be version 5.1 for WoW validation; found: $($luaCompilerVersion.Trim())"
}
& $luaCompiler -p @tocLuaFiles
if ($LASTEXITCODE -ne 0) { throw 'Lua 5.1 compilation failed for addon TOC files.' }
$achievementListing = & $luaCompiler -l -p (Join-Path $root 'Achievements.lua')
$achievementUpvalueCounts = @($achievementListing | ForEach-Object { if ($_ -match '(\d+) upvalues') { [int]$matches[1] } })
$maximumAchievementUpvalues = ($achievementUpvalueCounts | Measure-Object -Maximum).Maximum
if ($maximumAchievementUpvalues -gt 60) { throw "Achievements.lua contains a function with $maximumAchievementUpvalues upvalues; WoW permits at most 60." }

Assert-Source 'RaidLockouts.lua' 'RAID_SCHEMA_VERSION\s*=\s*5' 'Raid data schema version is not 5.'
Assert-Source 'RaidLockouts.lua' 'raidData\.seasons\[seasonKey\]' 'Season-aware raid storage is missing.'
Assert-Source 'RaidLockouts.lua' 'migratedRaidKillsS1' 'Season 1 raidKills migration guard is missing.'
Assert-Source 'RaidLockouts.lua' 'raidProgression is deliberately retained' 'Ambiguous legacy progression preservation is undocumented.'
Assert-Source 'Core.lua' 'raidProgression\s*=\s*nil' 'Destructive raid progression reset remains.' -Absent
Assert-Source 'Core.lua' 'raidKills\s*=\s*nil' 'Destructive raidKills reset remains.' -Absent
Assert-Source 'Core.lua' 'timePlayedLoginRetryTicker' 'Dedicated login retry ticker is missing.'
Assert-Source 'Core.lua' 'function lv\.RestoreTimePlayedChat[\s\S]*timePlayedSuppressTicker:Cancel\(\)[\s\S]*timePlayedLoginRetryTicker:Cancel\(\)' 'Restore does not cancel both suppression tickers.'
Assert-Source 'Achievements.lua' 'lv\.SetGlyphWaypoint\(glyph, zoneData\)' 'Glyph Hunter does not use SetGlyphWaypoint.'
Assert-Source 'Achievements.lua' 'lv\.SetMapWaypoint' 'Obsolete Glyph Hunter waypoint call remains.' -Absent
Assert-Source 'Achievements.lua' 'zoneData\.mapID' 'Wrong Glyph Hunter map field remains.' -Absent
Assert-Source 'Achievements.lua' 'glyph\.name' 'Wrong Glyph Hunter display field remains.' -Absent
Assert-Source 'Professions.lua' 'local COILED_ISLE_GLYPH_ZONE\s*=\s*\{' 'The Coiled Isle Glyph Hunter zone is missing.'
Assert-Source 'Professions.lua' 'map\s*=\s*2512' 'The Coiled Isle map is not 2512.'
Assert-Source 'Professions.lua' 'achievementID\s*=\s*63395' 'The Coiled Isle meta achievement is not 63395.'
Assert-Source 'Professions.lua' 'minInterface\s*=\s*120100' 'The Coiled Isle is not gated to interface 120100.'
Assert-Source 'Professions.lua' 'glyph\.achievementID[\s\S]*GetAchievementInfo\(glyph\.achievementID\)' 'Individual Coiled Isle achievement completion is not used.'
$professionSource = Get-Content -LiteralPath (Join-Path $root 'Professions.lua') -Raw -Encoding UTF8
$coiledBlock = [regex]::Match($professionSource, 'local COILED_ISLE_GLYPH_ZONE\s*=\s*\{([\s\S]*?)\n\}').Groups[1].Value
$expectedCoiledGlyphs = @(
    @(63394,0.374,0.605), @(63421,0.288,0.753), @(63423,0.458,0.649),
    @(63425,0.641,0.607), @(63427,0.520,0.384), @(63430,0.438,0.442),
    @(63420,0.266,0.631), @(63422,0.406,0.905), @(63424,0.589,0.489),
    @(63426,0.703,0.482), @(63428,0.429,0.306)
)
if ([regex]::Matches($coiledBlock, '(?m)^\s*\{ x = ').Count -ne 11) { $failures += 'The Coiled Isle does not contain exactly 11 glyphs.' }
foreach ($glyph in $expectedCoiledGlyphs) {
    $pattern = 'x\s*=\s*' + [regex]::Escape(([string]$glyph[1])) + '0*\s*,\s*y\s*=\s*' + [regex]::Escape(([string]$glyph[2])) + '0*\s*,\s*achievementID\s*=\s*' + $glyph[0]
    if ($coiledBlock -notmatch $pattern) { $failures += "The Coiled Isle glyph $($glyph[0]) has incorrect coordinates or is missing." }
}
if ([regex]::Matches($coiledBlock, 'label\s*=').Count -ne 11) { $failures += 'The Coiled Isle glyphs do not consistently use glyph.label.' }
if ($coiledBlock -match '\bcriteriaID\s*=|\bname\s*=') { $failures += 'The Coiled Isle uses a noncanonical glyph field.' }
Assert-Source 'Calendar.lua' 'local todayDate\s*=\s*today\.month\s*\*\s*100' 'MMDD-only active-event comparison remains.' -Absent
Assert-Source 'Calendar.lua' 'BuildWorldEventAliases' 'Locale-independent Calendar aliases are missing.'
Assert-Source 'List.lua' 'changeLog|showingChangeLog|SetOptionsSubpanel' 'Change Log UI references remain.' -Absent
Assert-Source 'List.lua' 'lv\.OptionsPanel\s*=\s*OptionsPanel' 'Options panel export regressed.'
Assert-Source 'Locales\Localization.lua' '\\127-\\159|127-159' 'Runtime locale validator rejects valid UTF-8 continuation bytes.' -Absent
Assert-Source 'Locales\Localization.lua' 'IsBrokenLocaleValueForTests' 'Runtime locale validator is not exposed for regression checks.'
Assert-Source 'Core.lua' 'function lv\.IsLiteVaultCharacterRecord' 'Character-record predicate is missing.'
Assert-Source 'Core.lua' 'lv\.IsLiteVaultCharacterRecord\(charKey, charData\)' 'Raid migration is not restricted to character records.'
Assert-Source 'Core.lua' 'MarkHaratiCompletedForCurrentReset\(relic\.firstQuestID,\s*"first",\s*"same_reset_flag_transition"\)' 'First-time Hara''ti flag transitions still mark the weekly complete.' -Absent
Assert-Source 'Core.lua' 'RepairInvalidHaratiTransitionCompletion[\s\S]*record\.source ~= "same_reset_flag_transition"[\s\S]*db\.haratiWeekly = nil' 'Narrow Hara''ti transition-record repair is missing.'
Assert-Source 'Core.lua' 'parentSaved\.state == "done"[\s\S]*parentSaved\.questID == record\.questID[\s\S]*db\.weeklyQuests\[parent\.name\] = nil' 'Contaminated Hara''ti parent DONE repair is missing or insufficiently scoped.'
Assert-Source 'Core.lua' 'haratiFirstQuestObservations\[relic\.firstQuestID\] = \{[\s\S]*completed = completed[\s\S]*resetStart = currentReset' 'Hara''ti first-time observations are no longer retained for diagnostics.'
Assert-Source 'Core.lua' 'event == "QUEST_TURNED_IN"[\s\S]*GetHaratiRelicForQuestID\(questID\)[\s\S]*MarkHaratiCompletedForCurrentReset' 'Authoritative Hara''ti relic turn-in completion path is missing.'
Assert-Source 'Core.lua' 'HARATI_SELECTOR_LOOKUP\[questID\][\s\S]*MarkHaratiSelectedForCurrentReset\(questID, "selector_turn_in"\)' 'Hara''ti selectors no longer use selection-only tracking.'
Assert-Source 'UI.lua' 'if #rows == 0 then\s*return UIText\("MSG_NO_FACTION_WEEKLY_COMPLETIONS"\), 0' 'Faction Weeklies completed-only empty state is not using the localized empty-state message or changes the rendered row count.'
Assert-Source 'UI.lua' 'emptyCompletedRows = renderedRows == 0[\s\S]*SetJustifyH\(emptyCompletedRows and "CENTER" or "LEFT"\)[\s\S]*theme\.textMuted' 'Faction Weeklies empty state is not driven by rendered completed rows or does not use muted styling.'
Assert-Source 'List.lua' 'width = lv\.GetActiveUpgradeSeasonKey\(\) == "midnight_s1" and 174 or 90' 'Dashboard legacy Ascendant resource container is not seasonally compacted.'
Assert-Source 'List.lua' 'if lv\.GetActiveUpgradeSeasonKey\(\) == "midnight_s1" then\s*r\.voidshardBtn = CreateFrame[\s\S]*r\.voidcoreBtn = CreateFrame' 'Dashboard Ascendant Voidshard/Voidcore construction is not gated to Midnight Season 1.'
Assert-Source 'Core.lua' 'db\.ascendantVoidshards = C_Item\.GetItemCount\(lv\.ASCENDANT_VOIDSHARD_ITEM_ID, true\)[\s\S]*db\.ascendantVoidcores = C_Item\.GetItemCount\(lv\.ASCENDANT_VOIDCORE_ITEM_ID, true\)' 'Legacy Ascendant Voidshard/Voidcore character history capture was removed.'
Assert-Source 'Core.lua' 'ASCENDANT_VENOMSTONE|Ascendant Venomstone' 'Speculative Ascendant Venomstone core implementation was added.' -Absent
Assert-Source 'List.lua' 'ASCENDANT_VENOMSTONE|Ascendant Venomstone' 'Speculative Ascendant Venomstone Dashboard implementation was added.' -Absent
Assert-Source 'RaidLockouts.lua' 'raidOrder\s*=\s*\{\s*"midnight_s2_venomous_abyss"' 'Season 2 internal raid order is missing.'
Assert-Source 'RaidLockouts.lua' 'GetCurrentSeasonLabel\(\)' 'Current season label is not configuration-driven.'
Assert-Source 'RaidLockouts.lua' 'TITLE_RAIDS_CHARACTER_FMT' 'Localized unified Raids title format is missing.'
Assert-Source 'RaidLockouts.lua' 'bucket\.encounters\[key\]\s*=\s*nil' 'Encounter fallback deduplication is missing.'
Assert-Source 'RaidLockouts.lua' 'BossStatMap\s*=\s*\{\s*seasonKey\s*=\s*"midnight_s1"' 'Statistics backfill is not explicitly scoped to Season 1.'
Assert-Source 'RaidLockouts.lua' 'lv\._liveRaidResetEpoch' 'Live raid state is not tied to weekly reset identity.'
Assert-Source 'RaidLockouts.lua' '"March on Quel''Danas"' 'Confirmed March on Quel''Danas API alias is missing.'
Assert-Source 'Folio.lua' 'frame\.emptyText:SetText\("Omnium Folio is unavailable\."\)' 'Visible Folio fallback is still hardcoded.' -Absent
Assert-Source 'RaidLockouts.lua' 'midnight_s1\s*=\s*\{\s*category\s*=\s*"legacy"' 'Season 1 is not categorized as Legacy.'
Assert-Source 'RaidLockouts.lua' 'midnight_s2\s*=\s*\{\s*category\s*=\s*"current"' 'Season 2 is not categorized as Current.'
Assert-Source 'RaidLockouts.lua' 'CURRENT_RAID_SEASON\s*=\s*"midnight_s2"' 'Season 2 is not the current raid season.'
Assert-Source 'RaidLockouts.lua' 'function lv\.ResolveConfiguredRaid\(instanceName, instanceID\)[\s\S]*DetectTrackedRaid\(instanceName, instanceID\)' 'Shared season-aware raid resolver is missing.'
Assert-Source 'RaidLockouts.lua' 'for _, candidate in ipairs\(\{ alias, LT\(alias\) \}\)' 'Raid aliases do not include localized-name fallback.'
Assert-Source 'Modules\InstanceTracker.lua' 'lv\.ResolveConfiguredRaid\(instanceName, mapID\)[\s\S]*lv\.RAID_SEASONS\[seasonKey\][\s\S]*season\.category ~= "current"[\s\S]*seasonKey ~= lv\.CURRENT_RAID_SEASON' 'InstanceTracker raid classification is not season-aware.'
Assert-Source 'Modules\InstanceTracker.lua' 'CURRENT_RAID_NAMES|IsCurrentTierRaidName' 'InstanceTracker retains a duplicate hardcoded current-raid list.' -Absent
Assert-Source 'RaidLockouts.lua' 'function lv\.GetCharacterRaidBossState' 'Context-safe character raid accessor is missing.'
Assert-Source 'RaidLockouts.lua' 'function lv\.GetWarbandRaidBossState' 'Derived Warband raid accessor is missing.'
Assert-Source 'RaidLockouts.lua' 'lv\.IsLiteVaultCharacterRecord' 'Warband aggregation does not use the character predicate.'
Assert-Source 'RaidLockouts.lua' 'warbandRaidData' 'Persisted duplicate Warband raid data was introduced.' -Absent
Assert-Source 'RaidLockouts.lua' 'selectedRaidBySeason\[CURRENT_RAID_SEASON\]' 'Roster current-season accessors depend on Legacy browsing state.'
Assert-Source 'RaidLockouts.lua' 'SLASH_LVRAIDDEBUG1\s*=\s*"/lvraiddebug"' 'Raid diagnostics command is missing.'
Assert-Source 'RaidLockouts.lua' 'achievementID\s*=\s*nil' 'Pending AOTC/CE achievement slots are missing.'

$raidSource = Get-Content -LiteralPath (Join-Path $root 'RaidLockouts.lua') -Raw -Encoding UTF8
$uiSource = Get-Content -LiteralPath (Join-Path $root 'UI.lua') -Raw -Encoding UTF8
$coreSource = Get-Content -LiteralPath (Join-Path $root 'Core.lua') -Raw -Encoding UTF8
$upgradeSelector = [regex]::Match($coreSource, 'function lv\.GetActiveUpgradeSeasonKey[\s\S]*?\nend').Value
if(-not $upgradeSelector -or $upgradeSelector -match '\bdate\b|\btime\b|GetServerTime'){$failures += 'Upgrade season selection depends on wall-clock time.'}
$teleportSource = Get-Content -LiteralPath (Join-Path $root 'Teleports.lua') -Raw -Encoding UTF8
$s1TeleportBlock = [regex]::Match($teleportSource, 'local MIDNIGHT_S1_TELEPORTS\s*=\s*\{([\s\S]*?)\n\}').Groups[1].Value
$s2TeleportBlock = [regex]::Match($teleportSource, 'local MIDNIGHT_S2_TELEPORTS\s*=\s*\{([\s\S]*?)\n\}').Groups[1].Value
if([regex]::Matches($s1TeleportBlock, '\{ name').Count -ne 8){$failures += 'Season 1 teleport pool no longer contains eight entries.'}
if([regex]::Matches($s2TeleportBlock, '\{ name').Count -ne 8){$failures += 'Season 2 teleport pool does not contain eight entries.'}
$achievementSource = Get-Content -LiteralPath (Join-Path $root 'Achievements.lua') -Raw -Encoding UTF8
$coiledTreasureBlock = [regex]::Match($achievementSource, 'local COILED_ISLE_TREASURES\s*=\s*\{([\s\S]*?)\n\}\n\nif lv\.GetClientInterfaceVersion').Groups[1].Value
if (-not $coiledTreasureBlock) { $failures += 'Treasures of the Coiled Isle definition is missing.' }
if ($coiledTreasureBlock -notmatch 'id\s*=\s*63359') { $failures += 'Coiled Isle treasure achievement ID is not 63359.' }
if ($coiledTreasureBlock -notmatch 'minInterface\s*=\s*120100') { $failures += 'Coiled Isle treasures are not gated to interface 120100.' }
if ([regex]::Matches($coiledTreasureBlock, '\bname\s*=').Count -ne 23) { $failures += 'Coiled Isle does not contain exactly 22 named treasures.' }
$expectedCoiledTreasures = @(
    @("Amani Privateer's Cache",'71.82','66.66'), @("Sunken Diver's Chest",'65.41','5.58'), @('Profane Ritual Spoils','43.56','67.51'),
    @('Possessed Vase','31.38','83.60'), @('Tarnished Amani Glaive','55.20','37.96'), @('Lost Spirit','68.05','65.89'),
    @('Damaged Loa Trinket','46.86','29.62'), @('Ornate Bottle','66.92','28.05'), @('Waterlogged Basket','49.33','31.96'),
    @('Crumbling Urn','73.35','56.67'), @("Vul'zahn's Smuggled Treasure",'58.14','45.76'), @('Fangbound Sack','45.90','66.20'),
    @('Grave of Someone Forgotten','67.21','48.38'), @('Brine-Crusted Chest','70.61','76.70'), @('Malfunctioning Staff','75.38','68.37'),
    @("Jaktu's Cursed Blade",'60.41','59.49'), @('Cracked Skull','58.14','43.62'), @('Venomjade Necklace','64.71','36.65'),
    @('Stinking Vessel','53.15','43.14'), @('Smoldering Incense','29.53','67.08'), @('Forgotten Mask','64.92','79.00'),
    @("Zul'jan's Stash",'44.01','26.60')
)
foreach ($treasure in $expectedCoiledTreasures) {
    $pattern = 'mapID\s*=\s*2512\s*,\s*x\s*=\s*' + [regex]::Escape($treasure[1]) + '\s*,\s*y\s*=\s*' + [regex]::Escape($treasure[2]) + '\s*,\s*name\s*=\s*"' + [regex]::Escape($treasure[0]) + '"'
    if ($coiledTreasureBlock -notmatch $pattern) { $failures += "Coiled Isle treasure '$($treasure[0])' is missing or has incorrect coordinates." }
}
if ([regex]::Matches($coiledTreasureBlock, 'name\s*=\s*"Forgotten Mask"').Count -ne 1) { $failures += 'Forgotten Mask must appear exactly once in Coiled Isle treasure data.' }
$forgottenMaskEntry = [regex]::Match($coiledTreasureBlock, '\{\s*mapID\s*=\s*2512\s*,\s*x\s*=\s*64\.92\s*,\s*y\s*=\s*79\.00\s*,\s*name\s*=\s*"Forgotten Mask"([^}]*)\}').Groups[1].Value
if (-not $forgottenMaskEntry -or $forgottenMaskEntry -notmatch 'note\s*=\s*"On a broken stone wall on Gnarldor Isle, south of the delve entrance\."') { $failures += 'Forgotten Mask location note is missing or incorrect.' }
if ($forgottenMaskEntry -match '\bsteps\s*=|\bitemID\s*=|\bobjectID\s*=|\bspellID\s*=|\bquestID\s*=') { $failures += 'Forgotten Mask was given non-achievement tracking or puzzle data.' }
if ($achievementSource -notmatch 'treasureButtons\s*=\s*\{\}[\s\S]*?for i\s*=\s*1,\s*22 do') { $failures += 'Treasure Hunter does not allocate rows for all 22 Coiled Isle treasures.' }
if ($achievementSource -notmatch 'completedTreasureLookup\[NormalizeAchievementTreasureName\(currentTreasure\.name\)\]') { $failures += 'Treasure completion no longer comes from Blizzard achievement criteria.' }
if ($achievementSource -notmatch 'SetAchievementTreasureWaypoint\(currentTreasure\.mapID, currentTreasure\.x, currentTreasure\.y, currentTreasure\.name\)') { $failures += 'Simple treasure rows no longer use the shared TomTom/native waypoint path.' }
foreach ($multiStepName in @("Amani Privateer's Cache","Sunken Diver's Chest",'Profane Ritual Spoils','Lost Spirit',"Vul'zahn's Smuggled Treasure",'Grave of Someone Forgotten','Brine-Crusted Chest')) {
    $entryPattern = 'name\s*=\s*"' + [regex]::Escape($multiStepName) + '"\s*,[\s\S]*?steps\s*=\s*\{'
    if ($coiledTreasureBlock -notmatch $entryPattern) { $failures += "Coiled Isle multi-step data is missing for '$multiStepName'." }
}
if ($coiledTreasureBlock -match '\bquestID\s*=') { $failures += 'Hidden quest tracking was added to Coiled Isle treasures.' }
if ($coiledTreasureBlock -match '\breward\s*=|\brewards\s*=|\bitemID\s*=') { $failures += 'Guessed individual Coiled Isle treasure rewards were added.' }
if ([regex]::Matches($coiledTreasureBlock, 'steps\s*=\s*\{').Count -ne 7) { $failures += 'Coiled Isle should contain exactly seven multi-step treasures.' }
$coiledStepRows = [regex]::Matches($coiledTreasureBlock, '\{\s*mapID\s*=\s*(\d+)\s*,[^{}]*?text\s*=')
if ($coiledStepRows.Count -ne 33 -or @($coiledStepRows | Where-Object { $_.Groups[1].Value -ne '2512' }).Count) { $failures += 'A Coiled Isle treasure step is missing map 2512.' }
if ($achievementSource -notmatch '\[63359\]\s*=\s*\{\s*type\s*=\s*"mount"\s*,\s*name\s*=\s*"Auriferous Venomfang"\s*,\s*itemID\s*=\s*275656') { $failures += 'Auriferous Venomfang reward override is incorrect.' }
if ($achievementSource -notmatch 'if lv\.GetClientInterfaceVersion\(\) >= COILED_ISLE_TREASURES\.minInterface') { $failures += 'Coiled Isle treasure gating does not use the canonical interface helper.' }
if ($achievementSource -match 'tonumber\(select\(4, GetBuildInfo\(\)\)\)') { $failures += 'Broken multi-return interface conversion was introduced.' }
if ($achievementSource -match 'UIText\("Track the four Midnight treasure achievements and their rewards\."\)') { $failures += 'Stale four-treasure summary wording remains in use.' }
foreach ($existingTreasureAchievement in @(61960,62126,62125,61263)) {
    if ($achievementSource -notmatch ('id\s*=\s*' + $existingTreasureAchievement)) { $failures += "Existing treasure achievement $existingTreasureAchievement is missing." }
}
$rareDetailsSource = [regex]::Match($achievementSource, 'local MIDNIGHT_RARES_DETAILS\s*=\s*\{([\s\S]*?)\n\}\nif lv\.GetClientInterfaceVersion').Groups[1].Value
$coiledRareBlock = [regex]::Match($rareDetailsSource, '\[63358\]\s*=\s*\{([\s\S]*?)\n\s*\},\s*$').Groups[1].Value
if (-not $coiledRareBlock) { $failures += 'Coiled to Strike rare details are missing.' }
if ([regex]::Matches($coiledRareBlock, '\bname\s*=').Count -ne 12) { $failures += 'Coiled to Strike does not contain exactly 12 rare details.' }
$expectedCoiledRares = @(
    @('Farthik the Plunderer',2512,'53.8','72.0'), @("Kari'zah the Forgotten",2512,'24.9','73.6'),
    @('Hisstara',2512,'43.9','50.9'), @('Garsecg',2512,'69.6','44.8'), @('Coin-Eye Skully',2512,'57.6','67.4'),
    @("Sss'alik",2512,'58.1','40.1'), @('Siltmouth',2512,'50.1','68.9'), @('Lockjaw',2512,'31.7','56.7'),
    @('Szarith the Fanged',2613,'37.7','17.5'), @("Nar'zira",2642,'63.5','62.4'),
    @('Big Mon',2512,'70.4','63.7'), @('Destra',2512,'52.1','32.4')
)
foreach ($rare in $expectedCoiledRares) {
    $pattern = 'mapID\s*=\s*' + $rare[1] + '\s*,\s*x\s*=\s*' + [regex]::Escape($rare[2]) + '\s*,\s*y\s*=\s*' + [regex]::Escape($rare[3]) + '\s*,\s*name\s*=\s*"' + [regex]::Escape($rare[0]) + '"'
    if ($coiledRareBlock -notmatch $pattern) { $failures += "Coiled Isle rare '$($rare[0])' is missing or has incorrect coordinates." }
}
if ([regex]::Matches($coiledRareBlock, 'rep\s*=\s*"50 Zul''jarra''s Forces rep"').Count -ne 12) { $failures += 'Every Coiled Isle rare must display 50 Zul''jarra''s Forces reputation.' }
if ($coiledRareBlock -notmatch 'Szarith the Fanged[\s\S]*45\.4, 64\.9[\s\S]*map 2512[\s\S]*47\.3, 6\.4[\s\S]*map 2509') { $failures += 'Szarith route note is incomplete.' }
if ($coiledRareBlock -notmatch 'Nar''zira[\s\S]*52\.4, 43\.1[\s\S]*map 2512') { $failures += 'Nar''zira surface entrance note is incomplete.' }
if ($coiledRareBlock -notmatch 'Big Mon[\s\S]*itemID\s*=\s*280540\s*,\s*label\s*=\s*"Lil'' Mon"') { $failures += 'Big Mon Lil'' Mon reward is missing or incorrect.' }
if ([regex]::Matches($coiledRareBlock, '\bitemID\s*=').Count -ne 1) { $failures += 'Speculative per-rare Coiled Isle loot was added.' }
if ($coiledRareBlock -match '\bquestID\s*=|\bvignette') { $failures += 'Hidden or vignette completion tracking was added for Coiled Isle rares.' }
if ($achievementSource -notmatch 'COILED_ISLE_RARES_ACHIEVEMENT\s*=\s*\{\s*id\s*=\s*63358\s*,\s*name\s*=\s*"Coiled to Strike"\s*,\s*minInterface\s*=\s*120100') { $failures += 'Coiled to Strike achievement definition or gate is incorrect.' }
if ($achievementSource -notmatch 'if lv\.GetClientInterfaceVersion\(\) >= COILED_ISLE_RARES_ACHIEVEMENT\.minInterface[\s\S]*table\.insert\(MIDNIGHT_RARES_OF_MIDNIGHT, COILED_ISLE_RARES_ACHIEVEMENT\)') { $failures += 'Coiled to Strike is not appended with the canonical 12.1 gate.' }
if ($achievementSource -notmatch '\[63358\]\s*=\s*\{\s*type\s*=\s*"item"\s*,\s*itemID\s*=\s*263873\s*,\s*label\s*=\s*"Housing Decor: Amani Forge"') { $failures += 'Amani Forge achievement reward is incorrect.' }
$coiledSharedLoot = [regex]::Match($achievementSource, '\[63358\]\s*=\s*\{\s*\{ itemID = 276803, label = "Ruby Writhe" \},\s*\{ itemID = 276549, label = "Topaz Skyfang" \}').Value
if (-not $coiledSharedLoot) { $failures += 'Coiled Isle shared mount loot is missing or incorrect.' }
foreach ($existingRareAchievement in @(61507,62122,61264,62130)) {
    if ($achievementSource -notmatch ('\{ id\s*=\s*' + $existingRareAchievement + ',')) { $failures += "Existing rare achievement $existingRareAchievement is missing." }
}
if ($achievementSource -match 'UIText\("Track the four Midnight rare achievements\."\)') { $failures += 'Stale four-achievement Rare Hunter summary remains in use.' }
if ($achievementSource -match 'UIText\("Track the four Midnight rare achievements and zone rare rewards\."\)') { $failures += 'Stale four-achievement Rare Hunter home text remains in use.' }
if ($achievementSource -match 'coiledRares|rareKills|rareKillStates') { $failures += 'New Rare Hunter completion SavedVariables were introduced.' }
if ($achievementSource -notmatch 'completedRareLookup\[NormalizeAchievementTreasureName') { $failures += 'Rare Hunter no longer shares the achievement criterion normalizer.' }
$studentLoreBlock = [regex]::Match($achievementSource, 'ACH\.STUDENT_OF_HISSSTORY_CONFIG\s*=\s*\{([\s\S]*?)\n\}\nACH\.STUDENT_OF_HISSSTORY_CONFIG\.available').Groups[1].Value
if (-not $studentLoreBlock) { $failures += 'Student of Hissstory definition is missing.' }
if ($studentLoreBlock -notmatch 'id\s*=\s*63662' -or $studentLoreBlock -notmatch 'minInterface\s*=\s*120100') { $failures += 'Student of Hissstory ID or interface gate is incorrect.' }
if ($studentLoreBlock -notmatch 'itemID\s*=\s*280419\s*,\s*label\s*=\s*"Toy: Cursed Badge of the Soulcoilers"') { $failures += 'Student of Hissstory reward is incorrect.' }
if ([regex]::Matches($studentLoreBlock, '\bname\s*=').Count -ne 11) { $failures += 'Student of Hissstory does not contain exactly 10 lore objects.' }
$expectedLoreObjects = @(
    @("Head Mason's Tablet",'42.5','65.0'), @('Worn Tablet','70.0','65.9'), @('Message in a Bottle','31.6','83.7'),
    @('Forum Rules','25.0','67.8'), @('Zandalari Logbook','71.9','44.9'), @("Amani Exile's Words",'57.4','80.3'),
    @('Abandoned Tablet','50.7','68.4'), @('Oily Black Stone','45.8','47.9'), @('Survival Journals','34.1','36.5'),
    @('Profaned Plaque','32.5','63.7')
)
foreach ($lore in $expectedLoreObjects) {
    $pattern = 'mapID\s*=\s*2512\s*,\s*x\s*=\s*' + [regex]::Escape($lore[1]) + '\s*,\s*y\s*=\s*' + [regex]::Escape($lore[2]) + '\s*,\s*name\s*=\s*"' + [regex]::Escape($lore[0]) + '"'
    if ($studentLoreBlock -notmatch $pattern) { $failures += "Student of Hissstory object '$($lore[0])' is missing or has incorrect coordinates." }
}
if ([regex]::Matches($studentLoreBlock, 'rep\s*=\s*"250 Zul''jarra''s Forces rep"').Count -ne 10) { $failures += 'Every lore object must display 250 Zul''jarra''s Forces reputation.' }
if ($studentLoreBlock -notmatch 'Head Mason''s Tablet[\s\S]*45\.72, 64\.94[\s\S]*map 2512') { $failures += 'Head Mason''s Tablet entrance route is missing.' }
if ($studentLoreBlock -notmatch 'Profaned Plaque[\s\S]*31\.80, 64\.91[\s\S]*map 2512') { $failures += 'Profaned Plaque entrance route is missing.' }
if ($studentLoreBlock -notmatch 'Oily Black Stone[\s\S]*not required for achievement credit') { $failures += 'Oily Black Stone does not clarify that Voidform is optional.' }
if ($studentLoreBlock -match '\bquestID\s*=|\bobjectID\s*=') { $failures += 'Hidden quest/object completion tracking was added for Student of Hissstory.' }
if ($achievementSource -match 'loreObjects\s*=|coiledLore\s*=|loreFlags\s*=') { $failures += 'Student of Hissstory SavedVariables were introduced.' }
if ($achievementSource -notmatch 'local function RenderLoreObjectTracker\(config\)[\s\S]*GetAchievementCriteriaRows\(config\.id\)[\s\S]*NormalizeAchievementTreasureName[\s\S]*RenderLoreObjectTracker\(ACH\.STUDENT_OF_HISSSTORY_CONFIG\)') { $failures += 'Student of Hissstory does not use the shared Blizzard-criteria lore renderer.' }
if ($achievementSource -notmatch 'ACH\.STUDENT_OF_HISSSTORY_CONFIG\.available\s*=\s*lv\.GetClientInterfaceVersion\(\)\s*>=\s*ACH\.STUDENT_OF_HISSSTORY_CONFIG\.minInterface') { $failures += 'Student of Hissstory does not reuse the canonical interface helper.' }
if ($achievementSource -match '^local STUDENT_OF_HISSSTORY(?:_AVAILABLE)?\b') { $failures += 'Student of Hissstory reintroduced independent initializer upvalues.' }
if ($achievementSource -notmatch 'local function SetAchievementSubviewVisibility\(active\)') { $failures += 'Achievement view visibility was not extracted from the oversized router.' }
if ($achievementSource -notmatch 'SetRareDetailButton\(btn, info,[\s\S]*SetAchievementTreasureWaypoint') { $failures += 'Student of Hissstory does not reuse the existing achievement detail/waypoint architecture.' }
$meta121Block = [regex]::Match($achievementSource, 'ACH\.META_12_1\s*=\s*\{([\s\S]*?)\n\}\nACH\.META_12_1\.available').Groups[1].Value
if (-not $meta121Block -or $meta121Block -notmatch 'minInterface\s*=\s*120100') { $failures += 'Consolidated 12.1 meta configuration or gate is missing.' }
$ulatekBlock = [regex]::Match($meta121Block, 'id\s*=\s*63639([\s\S]*?)id\s*=\s*63630').Groups[1].Value
$assaultBlock = [regex]::Match($meta121Block, 'id\s*=\s*63630([\s\S]*)').Groups[1].Value
if ([regex]::Matches($ulatekBlock, '\{ id\s*=\s*').Count -ne 4) { $failures += 'Ula''tek Uncoiled does not contain exactly four children.' }
foreach ($pair in @(@(62297,"The Curse of Ula'tek"),@(63359,'Treasures of the Coiled Isle'),@(63358,'Coiled to Strike'),@(63640,'Explore the Coiled Isle'))) {
    if ($ulatekBlock -notmatch ('\{ id\s*=\s*' + $pair[0] + '\s*,\s*name\s*=\s*"' + [regex]::Escape($pair[1]) + '"')) { $failures += "Ula'tek child $($pair[0]) is missing or incorrect." }
}
if ($achievementSource -match '\b62413\b') { $failures += 'Stale The Curse of Ula''tek achievement 62413 is present.' }
foreach ($story in @('Legacy of the Amani','Ghosts of the Past','The Battle for Atal''Utek','An Island of Fangs','Original Sin','The Call of the Void')) { if ($ulatekBlock -notmatch [regex]::Escape($story)) { $failures += "The Curse of Ula'tek criterion is missing: $story" } }
foreach ($region in @('Blistering Terrace','Gate of the Serpent''s Eye','Mlurkkr Mire','The Serpent''s Tail','Tokka''s Landing','Gate of the Eastern Fang','Gnarldor Isle','The Forum','The Whispering Marsh','Wreck of Paku''s Talon')) { if ($ulatekBlock -notmatch [regex]::Escape($region)) { $failures += "Explore the Coiled Isle region is missing: $region" } }
if ($ulatekBlock -notmatch 'subView\s*=\s*"treasures"\s*,\s*selectedID\s*=\s*63359' -or $ulatekBlock -notmatch 'subView\s*=\s*"rares"\s*,\s*selectedID\s*=\s*63358') { $failures += 'Ula''tek children do not route to the existing Treasure/Rare trackers.' }
if ([regex]::Matches($assaultBlock, '\{ id\s*=\s*').Count -ne 10) { $failures += 'Assault the Vault does not contain exactly ten children.' }
foreach ($pair in @(@(63598,'Roll the Patrol'),@(63599,'Submerge the Incursion'),@(62649,'A Lone Wanderer'),@(62600,'Ritual Behavior'),@(63610,'The Honored Dead'),@(63600,'Spike the Strike'),@(63601,'Oppose the Foes'),@(62604,'Dance While Everyone Watches'),@(62601,'Soft Underbelly'),@(63636,'Fully Corroded'))) {
    if ($assaultBlock -notmatch ('\{ id\s*=\s*' + $pair[0] + '\s*,\s*name\s*=\s*"' + [regex]::Escape($pair[1]) + '"')) { $failures += "Assault the Vault child $($pair[0]) is missing or incorrect." }
}
if ($assaultBlock -notmatch 'itemID\s*=\s*276801\s*,\s*label\s*=\s*"Mount: Venomous Coiler"') { $failures += 'Venomous Coiler reward is incorrect.' }
foreach ($criterionCount in @(@(63598,12),@(63599,3),@(62600,3),@(63600,6),@(63601,3),@(62604,3),@(62601,5))) {
    $childSegment = [regex]::Match($assaultBlock, ('\{ id\s*=\s*' + $criterionCount[0] + '[\s\S]*?criteria\s*=\s*\{([^}]*)\}')).Groups[1].Value
    if ([regex]::Matches($childSegment, '"[^\"]+"').Count -ne $criterionCount[1]) { $failures += "Achievement $($criterionCount[0]) has an incorrect configured criterion count." }
}
foreach ($singleCriterion in @(@(62649,'Soul Globe'),@(63636,'Talents Unlocked'))) {
    if ($assaultBlock -notmatch ('id\s*=\s*' + $singleCriterion[0] + '[\s\S]*?criteria\s*=\s*\{\s*"' + [regex]::Escape($singleCriterion[1]) + '"\s*\}')) { $failures += "Achievement $($singleCriterion[0]) is missing its Blizzard criterion." }
}
$ritualBlock = [regex]::Match($assaultBlock, 'id\s*=\s*62600([\s\S]*?)id\s*=\s*63610').Groups[1].Value
if ($ritualBlock -notmatch 'ritualWaypoint\s*=\s*\{\s*mapID\s*=\s*2509\s*,\s*x\s*=\s*47\.22\s*,\s*y\s*=\s*54\.42\s*,\s*name\s*=\s*"Ritual Altar"') { $failures += 'Ritual Behavior is missing the verified general Ritual Altar waypoint.' }
if ($ritualBlock -notmatch 'x\s*=\s*42\.00\s*,\s*y\s*=\s*47\.00\s*,\s*name\s*=\s*"Petrified Egg"') { $failures += 'Ritual Behavior Petrified Egg pickup waypoint is incorrect.' }
if ($ritualBlock -notmatch 'x\s*=\s*54\.00\s*,\s*y\s*=\s*49\.00\s*,\s*name\s*=\s*"Spirit Urn"') { $failures += 'Ritual Behavior Spirit Urn pickup waypoint is incorrect.' }
if ($ritualBlock -notmatch '\{\s*name\s*=\s*"Venomous Ooze"\s*,\s*note\s*=\s*"NOTE_RITUAL_BEHAVIOR_VENOMOUS_OOZE"\s*\}') { $failures += 'Ritual Behavior Venomous Ooze does not use localized guidance without a fabricated waypoint.' }
if ([regex]::Matches($ritualBlock, 'x\s*=\s*47\.22\s*,\s*y\s*=\s*54\.42').Count -ne 1) { $failures += 'Ritual Altar coordinates are reused by a Ritual Behavior criterion.' }
if ($assaultBlock -notmatch 'id\s*=\s*63636[\s\S]*?mapID\s*=\s*2509\s*,\s*x\s*=\s*51\.2\s*,\s*y\s*=\s*62\.6') { $failures += 'Fully Corroded is missing the verified Altar of Corrosion waypoint.' }
if ($assaultBlock -notmatch 'MIDNIGHT_RARES_DETAILS\[63358\]\[9\]') { $failures += 'Soft Underbelly does not reuse the existing Szarith route record.' }
if ($assaultBlock -match 'requiredQuantity\s*=\s*21|21\s*(?:talents|unlocked)') { $failures += 'Fully Corroded incorrectly uses 21 as its achievement denominator.' }
foreach ($detailID in @(63598,63599,62649,62600,63600,63601,62604,62601,63636)) {
    if ($assaultBlock -notmatch ('id\s*=\s*' + $detailID + '[\s\S]*?(?:criteria|details)\s*=\s*\{')) { $failures += "Assault child $detailID lacks generic detail configuration." }
}
if ($achievementSource -notmatch 'elseif not child then meta121\.childIndex = i[\s\S]*achievementSubView == "meta121" and meta121\.childIndex[\s\S]*meta121\.childIndex = nil') { $failures += 'Generic Assault child detail navigation or Back-to-Assault behavior is missing.' }
foreach ($forbiddenHomeButton in @('rollPatrol','submergeIncursion','loneWanderer','ritualBehavior','spikeStrike','opposeFoes','danceEveryone','softUnderbelly','fullyCorroded')) {
    if ($achievementSource -match ('home\.' + $forbiddenHomeButton + 'LaunchBtn')) { $failures += "Assault child $forbiddenHomeButton was incorrectly added to Trackers home." }
}
if ($assaultBlock -match 'Requires 10 out of 5') { $failures += 'Soft Underbelly contains the public-data count artifact.' }
foreach ($softName in @('Champion of the Scale','Priest of the First Rattle','Vserix the Sneaky','Guardian of the Sacrifice','Szarith the Fanged')) { if ($assaultBlock -notmatch [regex]::Escape($softName)) { $failures += "Soft Underbelly criterion missing: $softName" } }
$honoredDeadBlock = [regex]::Match($achievementSource, 'ACH\.HONORED_DEAD_CONFIG\s*=\s*\{([\s\S]*?)\n\}\nACH\.HONORED_DEAD_CONFIG\.available').Groups[1].Value
if (-not $honoredDeadBlock -or $honoredDeadBlock -notmatch 'id\s*=\s*63610[\s\S]*minInterface\s*=\s*120100') { $failures += 'The Honored Dead achievement or 12.1 gate is incorrect.' }
if ([regex]::Matches($honoredDeadBlock, '\bname\s*=\s*"To [^"]+"').Count -ne 14) { $failures += 'The Honored Dead does not contain exactly 12 inscriptions plus two route-step inscription labels.' }
$expectedHonoredDead = @(
    @('To a daughter.',2509,'49.46','56.65'), @('To parents.',2638,'14.55','63.93'), @('To a captain.',2509,'52.93','33.92'),
    @('To failure.',2509,'45.84','61.86'), @('To a sister.',2509,'46.78','7.74'), @('To a stranger.',2509,'42.65','32.92'),
    @('To a lover.',2509,'52.16','45.30'), @('To a dream.',2509,'55.63','40.47'), @('To sons.',2509,'42.83','39.93'),
    @('To a father.',2509,'47.24','28.92'), @('To comrades.',2636,'77.01','36.87'), @('To a shield-bearer.',2509,'56.44','23.02')
)
foreach ($inscription in $expectedHonoredDead) {
    $pattern = 'mapID\s*=\s*' + $inscription[1] + '\s*,\s*x\s*=\s*' + [regex]::Escape($inscription[2]) + '\s*,\s*y\s*=\s*' + [regex]::Escape($inscription[3]) + '\s*,\s*name\s*=\s*"' + [regex]::Escape($inscription[0]) + '"'
    if ($honoredDeadBlock -notmatch $pattern) { $failures += "The Honored Dead inscription '$($inscription[0])' is missing or incorrect." }
}
if ($honoredDeadBlock -notmatch 'steps\s*=\s*\{\s*\{ mapID = 2509, x = 54\.83, y = 48\.11, name = "Profaned Mausoleum Entrance" \},\s*\{ mapID = 2638, x = 14\.55, y = 63\.93, name = "To parents\." \}') { $failures += 'To parents does not use the verified generic multi-map route.' }
if ($honoredDeadBlock -notmatch 'steps\s*=\s*\{\s*\{ mapID = 2509, x = 39\.70, y = 48\.19, name = "Vault of Restless Bones Entrance" \},\s*\{ mapID = 2636, x = 77\.01, y = 36\.87, name = "To comrades\." \}') { $failures += 'To comrades does not use the verified generic multi-map route.' }
if ($honoredDeadBlock -match '\bquestID\s*=|\bobjectID\s*=|\bspellID\s*=') { $failures += 'The Honored Dead uses non-achievement completion tracking.' }
if ($achievementSource -notmatch 'ACH\.HONORED_DEAD_CONFIG\.available\s*=\s*lv\.GetClientInterfaceVersion\(\)\s*>=\s*ACH\.HONORED_DEAD_CONFIG\.minInterface') { $failures += 'The Honored Dead does not reuse canonical interface gating.' }
if ($assaultBlock -notmatch '\{ id\s*=\s*63610, name\s*=\s*"The Honored Dead", subView\s*=\s*"honoreddead" \}') { $failures += 'Assault the Vault child 63610 does not route to the shared tracker.' }
if ($achievementSource -notmatch 'info\.subView == "honoreddead"[\s\S]*meta121\.honoredDeadReturn = true[\s\S]*achievementSubView = "honoreddead"') { $failures += 'Assault does not record transient origin when opening The Honored Dead.' }
if ($achievementSource -notmatch 'achievementSubView == "honoreddead" and meta121\.honoredDeadReturn[\s\S]*achievementSubView = "meta121"') { $failures += 'Back from Assault-origin Honored Dead does not return to Assault.' }
if ($achievementSource -match 'LiteVaultDB[^\n]*honoredDead|honoredDead[^\n]*LiteVaultDB') { $failures += 'The Honored Dead added SavedVariable navigation or completion state.' }
if ($assaultBlock -notmatch 'id\s*=\s*63636[\s\S]*requiredQuantity\s*=\s*20' -or $achievementSource -notmatch 'criteriaRows\[1\]\.quantity') { $failures += 'Fully Corroded does not use Blizzard quantity progress out of 20.' }
if ($achievementSource -match 'assaultVault\s*=|ulatekMeta\s*=|vaultAchievements\s*=|altarTalents\s*=') { $failures += 'New 12.1 meta SavedVariables were introduced.' }
if ($achievementSource -notmatch 'ACH\.META_12_1\.available\s*=\s*lv\.GetClientInterfaceVersion\(\)\s*>=\s*ACH\.META_12_1\.minInterface') { $failures += '12.1 metas do not reuse the canonical interface helper.' }
if ($achievementSource -notmatch 'home\.ulatekLaunchMetaOverlay\s*=\s*CreateMetaAchievementHomeOverlay\(home\.metaContent, home\.ulatekLaunchBtn, home\.ulatekLaunchNote\)') { $failures += 'Ula''tek Uncoiled does not reuse the established home meta-card overlay inside Meta content.' }
if ($achievementSource -match 'CreateMetaAchievementHomeOverlay\([^,]+, home\.(?:lore|assaultVault)LaunchBtn') { $failures += 'A non-meta Student/Assault home card received meta-card artwork.' }
$achievementsThemeBlock = [regex]::Match($achievementSource, 'local function ApplyAchievementsTheme\(theme\)([\s\S]*?)\nend\n\nlocal function').Groups[1].Value
foreach ($newHomeCard in @('lore','ulatek','assaultVault','honoredDead')) {
    if ($achievementsThemeBlock -notmatch ('button\s*=\s*home\.' + $newHomeCard + 'LaunchBtn\s*,\s*note\s*=\s*home\.' + $newHomeCard + 'LaunchNote')) { $failures += "The $newHomeCard home card is not wired into live achievement theme refreshes." }
}
if ($achievementsThemeBlock -notmatch 'entry\.button:SetBackdropColor\(unpack\(theme\.buttonBgAlt or theme\.buttonBg\)\)[\s\S]*entry\.button:SetBackdropBorderColor\(unpack\(theme\.borderPrimary\)\)[\s\S]*entry\.button\.Text:SetTextColor\(unpack\(theme\.textPrimary\)\)[\s\S]*entry\.note:SetTextColor\(unpack\(theme\.textSecondary\)\)') { $failures += 'New achievement home cards do not use the canonical theme colors.' }
if ($achievementSource -match 'LayoutAchievementHomeTailWithinBounds|availableHeight - fixedHeight|blockGap\s*=\s*math\.') { $failures += 'Obsolete Achievements home spacing-compression logic remains.' }
if ($achievementSource -notmatch 'local function LayoutAchievementHomeBlocksWithinBounds\(\)[\s\S]*achievementHome:GetWidth\(\)[\s\S]*achievementHome:GetHeight\(\)') { $failures += 'Achievements home flow does not use the actual content-frame rectangle.' }
if ($achievementSource -notmatch 'blockGap, edgePadding\s*=\s*22, 8') { $failures += 'Achievements home flow does not preserve the canonical block spacing.' }
if ($achievementSource -notmatch 'blockTop - blockBottom[\s\S]*y \+ blockHeight > usableBottom[\s\S]*x \+ columnStep, startY') { $failures += 'Achievements home flow does not wrap complete visual blocks at the bottom boundary.' }
if ($achievementSource -notmatch 'local metaBlocks\s*=\s*\{[\s\S]*lightUpTheNightLaunchMetaOverlay|local metaBlocks\s*=\s*\{[\s\S]*lightUpTheNightMetaOverlay') { $failures += 'Meta Achievements layout does not come from a reusable block configuration.' }
if ($achievementSource -notmatch 'visual\s*=\s*home\.ulatekLaunchMetaOverlay and home\.ulatekLaunchMetaOverlay\.Overlay[\s\S]*visualTop - blockTop[\s\S]*blockTop, blockBottom = visualTop, visualBottom[\s\S]*-\(y \+ topOffset\)') { $failures += 'Ula''tek flow does not anchor its button below the full META banner while reserving the complete decorative frame.' }
if ($achievementSource -notmatch 'x \+ blockWidth <= usableRight') { $failures += 'Achievements home flow does not enforce the full visual block right boundary.' }
if ($achievementSource -notmatch 'achievementHomeSection\s*=\s*"trackers"[\s\S]*achievementReturnSection\s*=\s*"trackers"') { $failures += 'Achievements internal navigation does not default to Trackers.' }
if ($achievementSource -notmatch '\{ key = "trackers", label = "TAB_TRACKERS" \}[\s\S]*\{ key = "meta", label = "TAB_META_ACHIEVEMENTS" \}') { $failures += 'Achievements Trackers/Meta Achievements internal tabs are missing.' }
if ($achievementSource -notmatch 'local trackerBlocks\s*=\s*\{[\s\S]*treasureLaunchBtn[\s\S]*glyphHunterLaunchBtn[\s\S]*delverLaunchBtn[\s\S]*peaksLaunchBtn[\s\S]*raresLaunchBtn[\s\S]*loreLaunchBtn[\s\S]*assaultVaultLaunchBtn[\s\S]*honoredDeadLaunchBtn[\s\S]*\n\s*\}') { $failures += 'Trackers tab does not contain the eight expected launchers in order.' }
$metaLayoutBlock = [regex]::Match($achievementSource, 'local metaBlocks\s*=\s*\{([\s\S]*?)\n\s*\}').Groups[1].Value
if ($metaLayoutBlock -notmatch 'lightUpTheNightLaunchBtn[\s\S]*ulatekLaunchBtn' -or $metaLayoutBlock -match 'assaultVaultLaunchBtn') { $failures += 'Meta Achievements tab must contain only Light Up the Night and Ula''tek Uncoiled.' }
if ($achievementSource -notmatch 'block\.button:SetShown\(achievementHomeSection == "trackers"\)[\s\S]*block\.button:SetShown\(achievementHomeSection == "meta"\)') { $failures += 'Inactive Achievements internal-tab launchers are not hidden cleanly.' }
if ($achievementSource -notmatch 'home\.trackersContent:SetShown\(achievementHomeSection == "trackers"\)[\s\S]*home\.metaContent:SetShown\(achievementHomeSection == "meta"\)') { $failures += 'Achievements internal tabs do not hide their complete owned content containers.' }
foreach ($ownedTrackerRegion in @('glyphRewardIcon','glyphRewardText','glyphRewardNote','delverRewardIcon','delverRewardText','delverRewardNote')) {
    if ($achievementSource -notmatch ('home\.' + $ownedTrackerRegion + '\s*=\s*home\.trackersContent:Create')) { $failures += "Tracker-owned region $ownedTrackerRegion can leak outside its content container." }
}
if ($achievementSource -notmatch 'home\.assaultVaultLaunchBtn\s*=\s*CreateAchievementLaunchButton\(home\.trackersContent') { $failures += 'Assault the Vault is not owned by Trackers content.' }
if ($achievementSource -notmatch 'achievementHomeSection\s*=\s*achievementReturnSection') { $failures += 'Achievement Back navigation does not restore its originating internal tab.' }
if ($achievementsThemeBlock -notmatch 'btn\.sectionKey == achievementHomeSection[\s\S]*theme\.buttonBgHover[\s\S]*theme\.borderHover') { $failures += 'Achievements internal tabs do not use theme-aware selected/unselected styling.' }
if ($achievementSource -match 'LiteVaultDB[^\n]*(?:achievementHomeSection|achievementReturnSection)|(?:achievementHomeSection|achievementReturnSection)[^\n]*LiteVaultDB') { $failures += 'Achievements internal-tab state was persisted to SavedVariables.' }
if ($achievementSource -notmatch 'LayoutAchievementHomeBlocksWithinBounds\(\)[\s\S]*achievementsEmpty:Hide\(\)') { $failures += 'Achievements home block flow is not applied during home rendering.' }
if ($achievementSource -match 'CreateFrame\("ScrollFrame"[^\n]*achievementHome|achievementHome:SetSize|AchievementView:SetSize') { $failures += 'Achievements home boundary fix redesigned/resized the page.' }
if($achievementSource -match '63333'){$failures += 'Let Me Solo Him: Azta''rec was incorrectly added to the four-part Delver meta.'}
$delverBlock = [regex]::Match($achievementSource, 'local MIDNIGHT_DELVER_CRITERIA\s*=\s*\{([\s\S]*?)\n\}').Groups[1].Value
$regularDelverCriteria = [regex]::Matches($delverBlock, '^\s{4}\{ id = ', [Text.RegularExpressions.RegexOptions]::Multiline).Count
$seasonalDelverCriteria = [regex]::Matches($delverBlock, '^\s{8}key = "seasonalNemesis"', [Text.RegularExpressions.RegexOptions]::Multiline).Count
if(($regularDelverCriteria + $seasonalDelverCriteria) -ne 4){$failures += 'Delver logical denominator is not four.'}
$factionCardBlock = [regex]::Match($uiSource, 'local FACTION_CARD_CONFIG\s*=\s*\{([\s\S]*?)\n\}').Groups[1].Value
if ([regex]::Matches($factionCardBlock, '\{ key = ').Count -ne 9) { $failures += 'Faction-card configuration does not contain the seven existing cards plus Valeera and Slayer''s Duellum.' }

# Interface-gated seasonal upgrade/teleport model; intentionally contains no date input.
function Get-UpgradeSeasonFixture([int]$interfaceVersion) { if($interfaceVersion -ge 120100){'midnight_s2'}else{'midnight_s1'} }
if((Get-UpgradeSeasonFixture 120007) -ne 'midnight_s1' -or (Get-UpgradeSeasonFixture 120100) -ne 'midnight_s2' -or (Get-UpgradeSeasonFixture 120105) -ne 'midnight_s2'){$failures += 'Interface seasonal activation boundary is incorrect.'}
$capturedInterfaceFixture = [int]'120007'
if($capturedInterfaceFixture -isnot [int]){$failures += 'Client interface helper fixture did not return a number.'}
$missingEventConfigFixture = $null
$safeEventConfigFixture = if($null -eq $missingEventConfigFixture){@{}}else{$missingEventConfigFixture}
if($safeEventConfigFixture.Count -ne 0){$failures += 'Nil Calendar EVENT_CONFIG fixture did not process as an empty table.'}
$upgradeFixture=@{
    midnight_s1=@{spark=232875;catalyst=3378;crests=@(3383,3341,3343,3345,3347)}
    midnight_s2=@{spark=274476;catalyst=3465;preferred=@(3442,3443,3444,3445,3446);alternate=@(3437,3438,3439,3440,3441)}
}
if($upgradeFixture.midnight_s1.crests.Count -ne 5 -or $upgradeFixture.midnight_s2.preferred.Count -ne 5 -or $upgradeFixture.midnight_s2.alternate.Count -ne 5){$failures += 'Seasonal crest family fixture is incomplete.'}
function Resolve-CrestCandidateFixture($preferred, $alternate, [hashtable]$usable) { if($usable[$preferred]){return $preferred}; if($usable[$alternate]){return $alternate}; return $null }
$chosenFixture=Resolve-CrestCandidateFixture 3442 3437 @{3442=$true;3437=$true}
if($chosenFixture -ne 3442){$failures += 'Mistcrest resolver did not prefer exactly one current candidate.'}
$quantityFixture=@{3442=12;3437=99}
if($quantityFixture[$chosenFixture] -ne 12){$failures += 'Mistcrest candidate quantities were double counted.'}
$factionCardPositions = for($index=1; $index -le 9; $index++) {
    [pscustomobject]@{ column=(($index - 1) % 2); row=[math]::Floor(($index - 1) / 2) }
}
if (@($factionCardPositions | Where-Object row -eq 4).Count -ne 1 -or @($factionCardPositions | Select-Object -ExpandProperty column -Unique).Count -ne 2) {
    $failures += 'Nine faction cards do not resolve to the established two-column layout.'
}
foreach($obsolete in @('currentViewMode','UpdateRaidViewToggleText','viewToggleBtn','raidViewToggleBtn','getRaidViewMode','GetBossStateForDifficulty')) {
    if($raidSource.Contains($obsolete) -or $uiSource.Contains($obsolete)){$failures += "Obsolete raid mode reference remains: $obsolete"}
}
if($raidSource -notmatch 'local maxRows\s*=\s*3' -or $raidSource -notmatch '"character"[\s\S]*"weekly"[\s\S]*"warband"'){$failures += 'Unified Character/This Week/Warband rows are incomplete.'}
if($raidSource -notmatch 'rowIndex == 3[\s\S]*GetWarbandRaidBossState' -or $raidSource -notmatch 'rowIndex == 2[\s\S]*GetCharacterRaidWeeklyBossState' -or $raidSource -notmatch 'else[\s\S]*GetCharacterRaidBossState'){$failures += 'Unified row data sources are not explicit.'}
$weeklyAccessor = [regex]::Match($raidSource, 'function lv\.GetCharacterRaidWeeklyBossState[\s\S]*?\nend').Value
if(-not $weeklyAccessor -or $weeklyAccessor -match 'raidData|RecordSeasonRaidKill'){$failures += 'This Week accessor can mutate/read historical progression.'}
$characterAccessor = [regex]::Match($raidSource, 'function lv\.GetCharacterRaidBossState[\s\S]*?\nend').Value
if(-not $characterAccessor -or $characterAccessor -match 'raidLockouts|_liveRaidState'){$failures += 'Character progression accessor reads weekly lockout state.'}
foreach ($raidKey in @('midnight_s1_voidspire','midnight_s1_dreamrift','midnight_s1_sporefall','midnight_s1_march','midnight_s2_venomous_abyss','midnight_s2_tidebound_grotto')) {
    if ($raidSource -notmatch [regex]::Escape($raidKey)) { $failures += "Configured raid key missing: $raidKey" }
}
$configuredRaidKeys = [Collections.Generic.HashSet[string]]::new()
foreach($match in [regex]::Matches($raidSource, '(?m)^\s{12}(midnight_s[12]_[a-z0-9_]+)\s*=\s*\{')) { [void]$configuredRaidKeys.Add($match.Groups[1].Value) }
foreach($orderMatch in [regex]::Matches($raidSource, 'raidOrder\s*=\s*\{([^}]+)\}')) {
    foreach($keyMatch in [regex]::Matches($orderMatch.Groups[1].Value, '"([^"]+)"')) {
        if (-not $configuredRaidKeys.Contains($keyMatch.Groups[1].Value)) { $failures += "raidOrder entry does not resolve: $($keyMatch.Groups[1].Value)" }
    }
}
$s2Bosses = @("Nek'zali the Soulcoiler",'Entombed Sentinels','Vashnik the Malignant','The Lost Explorers','Sszorak','The Twin Fangs','The Coiled Altar',"Ula'tek")
foreach ($boss in $s2Bosses) { if (-not $raidSource.Contains('"' + $boss + '"')) { $failures += "Season 2 boss missing: $boss" } }
Assert-Source 'RaidLockouts.lua' 'midnight_s2_tidebound_grotto\s*=\s*\{[\s\S]*?displayKey\s*=\s*"The Tidebound Grotto"[\s\S]*?bossCount\s*=\s*1[\s\S]*?identifiersPending\s*=\s*true[\s\S]*?"Nymrissa Wavecaller"' 'Pending Tidebound Grotto configuration is incomplete.'
Assert-Source 'RaidLockouts.lua' '(?m)^\s{12}midnight_s2_lair_boss\s*=\s*\{' 'Temporary Lair Boss remains configured as a raid.' -Absent
Assert-Source 'RaidLockouts.lua' '\["midnight_s2_lair_boss"\]\s*=\s*"midnight_s2_tidebound_grotto"' 'Temporary raidData key migration is missing.'
Assert-Source 'RaidLockouts.lua' 'temporaryLair[\s\S]*midnight_s2_tidebound_grotto' 'Temporary lockout-key migration is missing.'
Assert-Source 'RaidLockouts.lua' 'storageKey="world"[\s\S]*difficultyID=nil[\s\S]*tag="W"[\s\S]*labelKey="DIFFICULTY_WORLD"[\s\S]*identifiersPending=true' 'Tidebound World difficulty is not safely configured.'
Assert-Source 'RaidLockouts.lua' 'GetRaidDifficultyOrder\(seasonKey, raidKey\)' 'Raid grid does not use per-raid difficulty configuration.'
Assert-Source 'RaidLockouts.lua' 'SizeRaidTabButtonToLabel[\s\S]*GetStringWidth\(\)[\s\S]*labelWidth\s*\+\s*32' 'Raid selector buttons are not content-aware.'
Assert-Source 'RaidLockouts.lua' 'row\.nameText:SetText\(characterName\)' 'Selected character name is not used for the unified character row.'
Assert-Source 'RaidLockouts.lua' 'rowIndex == 1 and L\["LABEL_CHARACTER"\]' 'Generic Character label remains in the unified character row.' -Absent
Assert-Source 'RaidLockouts.lua' 'targetKey\s*=\s*currentRaidCharKey or lv\.PLAYER_KEY[\s\S]*characterName\s*=\s*targetKey:match' 'Unified row identity is not derived from the selected LiteVault character key.'
Assert-Source 'RaidLockouts.lua' 'characterData\.classFile or characterData\.class' 'Selected-character class data is not used for row presentation.'
Assert-Source 'RaidLockouts.lua' 'C_ClassColor[\s\S]*RAID_CLASS_COLORS' 'Existing Blizzard class-color infrastructure is not used with a fallback.'
Assert-Source 'RaidLockouts.lua' 'SetCharacterNameColor\(row\.nameText, characterClassColor\)' 'Selected character row is not class-colored.'
Assert-Source 'RaidLockouts.lua' 'row\.characterClassColor\s*=\s*nil[\s\S]*row\.nameText:SetTextColor' 'This Week and Warband row labels are not explicitly neutral.'
Assert-Source 'RaidLockouts.lua' 'hit\.characterClassColor\s*=\s*characterClassColor' 'Raid indicator tooltips do not receive the selected character class color.'
Assert-Source 'RaidLockouts.lua' 'AddCharacterNameTooltipLine\(button\.characterName or L\["LABEL_CHARACTER"\], button\.characterClassColor\)' 'Character and This Week tooltips do not class-color the selected identity.'
Assert-Source 'RaidLockouts.lua' 'row\.nameText:SetWidth\(100\)[\s\S]*row\.nameText:SetWordWrap\(false\)[\s\S]*row\.nameHit:SetSize\(110, 32\)' 'Long-name clipping and full-name tooltip bounds are not fixed inside the label area.'
Assert-Source 'RaidLockouts.lua' 'currentRaidCharKey\s*=\s*targetKey[\s\S]*UpdateRaidLockoutGrid\(\)' 'Character switching does not refresh the selected-character raid presentation.'
Assert-Source 'RaidLockouts.lua' 'WrapTextInColorCode\(killer\.name\)' 'Existing Warband killer class coloring regressed.'
Assert-Source 'RaidLockouts.lua' 'midnight_s1\s*=\s*\{[\s\S]*?progressionTrackingActive\s*=\s*false[\s\S]*?firstKillTrackingActive\s*=\s*false' 'Season 1 historical progression is not configuration-frozen.'
Assert-Source 'RaidLockouts.lua' 'midnight_s2\s*=\s*\{[\s\S]*?progressionTrackingActive\s*=\s*true[\s\S]*?firstKillTrackingActive\s*=\s*true' 'Season 2 progression/first-kill tracking is not active.'
Assert-Source 'RaidLockouts.lua' 'not seasonInfo\.progressionTrackingActive and not metadata\.migration' 'Live progression writes are not gated by season configuration.'
Assert-Source 'RaidLockouts.lua' 'observedAt[\s\S]*earliestFirstKillAt, earliestFirstKillSource\s*=\s*observedAt, "observed"' 'Directly observed first-kill provenance is missing.'
Assert-Source 'RaidLockouts.lua' 'hadUndatedKill[\s\S]*merged\.firstKillAt, merged\.firstKillSource\s*=\s*nil, nil' 'Undated historical kills do not suppress false first-kill dates.'
Assert-Source 'RaidLockouts.lua' 'GetCharacterRaidBossHistory' 'Character first-kill history accessor is missing.'
Assert-Source 'RaidLockouts.lua' 'definitive\s*=\s*#killers > 0 and not hasUndated' 'Warband first-kill certainty does not account for undated history.'
Assert-Source 'RaidLockouts.lua' 'date\("%x", timestamp\)' 'First-kill dates are not locale-aware date-only values.'
Assert-Source 'RaidLockouts.lua' 'warbandFirstKills|warbandRaidHistory' 'Persisted Warband first-kill aggregate was introduced.' -Absent
Assert-Source 'Core.lua' 'MIDNIGHT_FACTION_IDS\s*=\s*\{[\s\S]*zuljarra\s*=\s*2772' 'Zul''jarra faction ID 2772 is missing from the existing faction configuration.'
Assert-Source 'Core.lua' 'WEEKLY_ZULJARRA_QUESTS\s*=\s*lv\.WEEKLY_ZULJARRA_QUESTS or\s*\{\s*\{name="Turn Back the Surge", id=96995\},\s*\{name="Purging the Vaults", id=95520\},?\s*\}' 'Zul''jarra independent weekly quest definitions are incomplete.'
Assert-Source 'Core.lua' 'ACCOUNT_WIDE_FACTION_CHOICES\s*=\s*\{[\s\S]*(96995|95520)' 'Zul''jarra quests were routed through account-wide faction choices.' -Absent
Assert-Source 'Core.lua' 'lv\.WEEKLY_ZULJARRA_QUESTS or \{\}' 'Zul''jarra quests are not registered with the generic tracked-weekly resolver.'
Assert-Source 'UI.lua' 'key = "zuljarra", labelKey = "BUTTON_ZULJARRA_FORCES", quests = function\(\) return lv\.WEEKLY_ZULJARRA_QUESTS' 'Zul''jarra is missing from factionWeeklyTabDefs.'
Assert-Source 'UI.lua' 'key = "zuljarra"[\s\S]*short = "ZF"[\s\S]*dynamicMajorFactionAtlas = true' 'Zul''jarra is missing from the existing faction-card configuration or fallback emblem.'
Assert-Source 'UI.lua' 'GetMajorFactionData\(factionID\)[\s\S]*factionData and factionData\.textureKit' 'Zul''jarra dynamic emblem resolution is not nil-safe.'
Assert-Source 'UI.lua' 'C_Texture and C_Texture\.GetAtlasInfo and C_Texture\.GetAtlasInfo\(atlas\)' 'Dynamic Major Faction atlas existence is not validated.'
Assert-Source 'UI.lua' 'majorfactions_icons_origin512[\s\S]*majorfactions_icons_root512[\s\S]*majorfactions_icons_sky512[\s\S]*majorfactions_icons_light512[\s\S]*majorfactions_icons_RitualSites512' 'An existing configured faction atlas regressed.'
Assert-Source 'UI.lua' 'if not majorFactionData and not renownInfo and not standardFactionData then return nil end' 'Missing faction reputation data is not handled safely.'
Assert-Source 'UI.lua' 'if not info then[\s\S]*card\.levelText:SetText\(string\.format\("\|cffcccccc%s\|r", progressText\)\)' 'Unavailable Zul''jarra Renown does not render the existing neutral fallback text.'
Assert-Source 'UI.lua' 'Season 2 Reputation|SEASON_2_REPUTATION' 'A separate Season 2 reputation block was introduced.' -Absent
Assert-Source 'UI.lua' 'if index == 1 then\s*btn:SetPoint\("TOPLEFT", factionTitle, "BOTTOMLEFT", 0, -10\)\s*elseif index <= 5 then\s*btn:SetPoint\("LEFT", factionTabButtons\[index - 1\], "RIGHT", 7, 0\)\s*else\s*btn:SetPoint\("TOPLEFT", factionTabButtons\[1\], "BOTTOMLEFT", 0, -7\)' 'Faction-weekly selectors do not preserve the original six-faction layout.'
Assert-Source 'UI.lua' 'key = "amani"[\s\S]*key = "harati"[\s\S]*key = "singularity"[\s\S]*key = "silvermoon"[\s\S]*key = "ritualsites"[\s\S]*key = "zuljarra"' 'Faction-weekly selector ordering changed.'
Assert-Source 'Core.lua' 'tokka\s*=\s*2773' 'Captain Tokka faction ID 2773 is missing.'
Assert-Source 'UI.lua' 'CreateFactionSectionTab\("weeklies", "BUTTON_FACTION_WEEKLIES"\)[\s\S]*CreateFactionSectionTab\("tokka", "BUTTON_CAPTAIN_TOKKA"' 'Factions secondary navigation is incomplete.'
$factionTabBlock = [regex]::Match($uiSource, 'local factionWeeklyTabDefs\s*=\s*\{([\s\S]*?)\n\}').Groups[1].Value
if ($factionTabBlock -match 'key = "tokka"') { $failures += 'Captain Tokka remains in the weekly faction selector.' }
Assert-Source 'UI.lua' 'key = "tokka"[\s\S]*short = "CT"[\s\S]*dynamicMajorFactionAtlas = true' 'Captain Tokka faction card is missing.'
Assert-Source 'Core.lua' 'valeera\s*=\s*2744[\s\S]*slayersduellum\s*=\s*2770' 'Valeera or Slayer''s Duellum faction ID is missing.'
Assert-Source 'UI.lua' 'key = "valeera".*allowTextFallback = false' 'Valeera card does not require Blizzard artwork.'
Assert-Source 'UI.lua' 'key = "slayersduellum".*allowTextFallback = false' 'Slayer''s Duellum card does not require Blizzard artwork.'
if ($factionTabBlock -match 'valeera|slayersduellum') { $failures += 'A new reputation card was incorrectly added to the weekly selector.' }
Assert-Source 'UI.lua' 'CreateFactionSectionTab\("(valeera|slayersduellum)"' 'A new reputation card was incorrectly added as a Factions subtab.' -Absent
Assert-Source 'UI.lua' 'GetFriendshipReputation\(factionID\)[\s\S]*maxLevel=80' 'Valeera friendship progression or Level 80 cap handling is missing.'
Assert-Source 'UI.lua' 'kind="standard"[\s\S]*FACTION_STANDING_LABEL' 'Standard reputation standing labels are missing.'
Assert-Source 'UI.lua' '\[2744\]\s*=\s*\{ kind = "creatureDisplay", id = 26365 \}' 'Valeera portrait does not use the Midnight landing-page creature display.'
Assert-Source 'UI.lua' '\[2770\]\s*=\s*\{ kind = "texture", id = 7448209 \}' 'Slayer''s Duellum does not use the Midnight landing-page crest.'
Assert-Source 'UI.lua' '\[2773\]\s*=\s*\{ kind = "creatureDisplay", id = 145432, creatureID = 253515 \}' 'Captain Tokka portrait does not use the verified live creature display.'
Assert-Source 'UI.lua' 'SetPortraitTextureFromCreatureDisplayID\(card\.emblemIcon, artwork\.id\)[\s\S]*card\.emblemIcon:SetTexture\(artwork\.id\)' 'Faction artwork resolver does not support both portrait and texture sources.'
Assert-Source 'UI.lua' 'local function ApplyFactionCardVisual\(card, theme, hovered\)[\s\S]*card\.innerBorder:SetBackdropBorderColor[\s\S]*card\.topAccent:SetColorTexture[\s\S]*card\.bottomAccent:SetColorTexture[\s\S]*for _, line in ipairs\(card\.emblemAccentLines\)[\s\S]*line:SetColorTexture\(ar, ag, ab, 0\.88\)' 'Shared faction-card border styling is incomplete.'
Assert-Source 'UI.lua' 'cornerSegments[\s\S]*\{"TOPLEFT", 4, -4, 8, 2\}[\s\S]*\{"TOPLEFT", 4, -4, 2, 8\}[\s\S]*\{"BOTTOMRIGHT", -4, 4, 2, 8\}' 'Faction-card L-shaped corner brackets are missing or incomplete.'
Assert-Source 'UI.lua' 'cornerAccents|SetRotation\(math\.rad\(45\)\)' 'Obsolete diamond faction-card corner caps remain.' -Absent
Assert-Source 'UI.lua' 'local scale = 0\.86[\s\S]*card\.innerBorder:SetBackdropBorderColor\(inner\[1\], inner\[2\], inner\[3\], 0\.62\)' 'Faction-card accents and inner borders do not use the unified palette treatment.'
Assert-Source 'Theme.lua' 'local LITEVAULT_PALETTE = \{[\s\S]*background = \{0\.208, 0\.251, 0\.294[\s\S]*backgroundAlt = \{0\.251, 0\.298, 0\.341[\s\S]*borderPrimary = \{0\.110, 0\.133, 0\.161[\s\S]*borderSecondary = \{0\.376, 0\.424, 0\.475[\s\S]*buttonBg = \{0\.251, 0\.298, 0\.341[\s\S]*buttonBgHover = \{0\.290, 0\.341, 0\.388[\s\S]*buttonBgActive = \{0\.208, 0\.251, 0\.294[\s\S]*textPrimary = \{0\.925, 0\.937, 0\.949[\s\S]*textSecondary = \{0\.710, 0\.741, 0\.776' 'Canonical steel-slate palette or an expected palette key is incomplete.'
Assert-Source 'Theme.lua' 'function lv\.GetTheme\(\)\s*return LITEVAULT_PALETTE\s*end' 'GetTheme does not always return the canonical LiteVault palette.'
Assert-Source 'Theme.lua' 'function lv\.RegisterThemedElement\(element, updateFunc\)[\s\S]*table\.insert\(lv\.ThemedElements' 'Centralized themed-element registration was removed.'
Assert-Source 'Theme.lua' 'function lv\.ApplyTheme\(\)[\s\S]*for _, entry in ipairs\(lv\.ThemedElements\)[\s\S]*pcall\(entry\.updateFunc, entry\.element, theme\)[\s\S]*lv\.UpdateUI\(\)' 'Centralized theme repaint behavior regressed.'
Assert-Source 'Theme.lua' 'lv\.Themes|lv\.currentTheme|lv\.SetTheme|lv\.ToggleTheme|LITEVAULTTHEME|/lvtheme' 'Obsolete theme-selection machinery remains in Theme.lua.' -Absent
Assert-Source 'Core.lua' 'LiteVaultDB\.theme|lv\.currentTheme|lv\.Themes' 'Core still reads or writes obsolete theme selection.' -Absent
Assert-Source 'List.lua' 'darkModeCB|darkModeDesc|OPTION_DARK_MODE|currentTheme|SetTheme\(' 'The obsolete Light/Dark Options control remains.' -Absent
Assert-Source 'UI.lua' 'darkModeCB|darkModeDesc|OPTION_DARK_MODE' 'UI localization refresh still references the removed theme control.' -Absent
Assert-Source 'Achievements.lua' 'darkModeCB|darkModeDesc|currentTheme' 'Achievements still synchronizes obsolete theme selection.' -Absent
Assert-Source 'RaidLockouts.lua' 'LiteVaultDB\.theme|lv\.currentTheme|lv\.Themes' 'Raid Lockouts still reloads obsolete theme selection.' -Absent
$obsoleteThemeLocalePattern = 'OPTION_DARK_MODE|OPTION_DARK_MODE_DESC|HELP_THEME_(?:DARK|LIGHT|TOGGLE|CURRENT_FMT|TITLE)|MSG_THEME_(?:SET_DARK|SET_LIGHT|SWITCHED_FMT)'
foreach ($localeFile in @('enUS','deDE','frFR','esES','ptBR','ruRU','zhCN','zhTW','koKR')) {
    Assert-Source ("Locales\$localeFile.lua") $obsoleteThemeLocalePattern "Obsolete theme-selection localization remains in $localeFile." -Absent
}
Assert-Source 'Theme.lua' 'Sage Green|0\.40, 0\.47, 0\.40|0\.30, 0\.35, 0\.30' 'Legacy Sage Green palette values remain in Theme.lua.' -Absent
Assert-Source 'UI.lua' 'theme\.buttonBgAlt or theme\.dataBoxBgAlt or theme\.backgroundAlt or theme\.background' 'Faction cards do not use a theme-aware background distinct from the page.'
Assert-Source 'UI.lua' 'card:SetBackdropBorderColor\(ar|card:SetBackdropBorderColor\(card\.cfg\.color' 'Faction color still runs around the full card perimeter.' -Absent
Assert-Source 'UI.lua' 'RegisterThemedElement\(card,[\s\S]*ApplyFactionCardVisual\(element, theme, element\.factionCardHovered\)' 'Existing faction cards do not refresh through the centralized theme path.'
Assert-Source 'UI.lua' 'local selected = \(card\.cfg\.selectable ~= false\) and \(card\.cfg\.key == factionWeeklyMode\)|ApplyFactionCardVisual\([^\n]*selected' 'Faction reputation cards retain selected-state visual styling.' -Absent
Assert-Source 'UI.lua' 'local function StyleWeeklyTab\(btn, visualState\)[\s\S]*visualState == "hover"[\s\S]*visualState == "pressed"' 'Faction-weekly buttons do not use transient visual states.'
Assert-Source 'UI.lua' 'StyleWeeklyTab\(btn, btn\.mode == factionWeeklyMode\)' 'Faction-weekly buttons retain persistent selected-state styling.' -Absent
Assert-Source 'UI.lua' 'SetScript\("OnMouseDown"[\s\S]*StyleWeeklyTab\(self, "pressed"\)[\s\S]*SetScript\("OnMouseUp"[\s\S]{0,300}IsMouseOver\(\) and "hover" or "idle"' 'Faction-weekly pressed and release styling is incomplete.'
Assert-Source 'UI.lua' 'SetScript\("OnMouseUp"[\s\S]{0,300}SetButtonState\("NORMAL"\)' 'Faction-weekly OnMouseUp restores NORMAL before WoW dispatches OnClick.' -Absent
Assert-Source 'UI.lua' 'btn\.visualState|suppressHoverUntilLeave' 'Faction-weekly buttons retain stored visual state across refreshes.' -Absent
Assert-Source 'UI.lua' 'RegisterThemedElement\(btn, function\(b\) StyleWeeklyTab\(b, "idle"\) end\)[\s\S]*StyleWeeklyTab\(btn, "idle"\)' 'Faction-weekly refresh or theme styling can reapply a non-idle state.'
Assert-Source 'UI.lua' 'bottomAccent:SetPoint\("BOTTOMLEFT", 20, 4\)[\s\S]*bottomAccent:SetPoint\("BOTTOMRIGHT", -20, 4\)[\s\S]*bottomAccent:SetHeight\(1\)' 'Faction-card bottom accent rail is missing or misaligned.'
Assert-Source 'UI.lua' 'edgeFile = "Interface\\\\Buttons\\\\WHITE8X8",\s*edgeSize = 3,\s*insets = \{ left = 3, right = 3, top = 3, bottom = 3 \}' 'Faction-card neutral outer border is not the intended 3px structural edge.'
Assert-Source 'UI.lua' 'allowTextFallback == false[\s\S]*allowTextFallback ~= false' 'New faction cards can regress to placeholder initials.'
Assert-Source 'Core.lua' 'RegisterEvent\("UPDATE_FACTION"\)[\s\S]*event == "UPDATE_FACTION"[\s\S]*lv\.QueueRefresh' 'Standard/friendship reputation changes do not use centralized refresh.'
$tokkaBlock = [regex]::Match($coreSource, 'lv\.TOKKA_TREASURES_OF_THE_DAMNED\s*=\s*\{([\s\S]*?)\n\}').Groups[1].Value
$tokkaIDs = @([regex]::Matches($tokkaBlock, 'questID\s*=\s*(\d+)') | ForEach-Object { [int]$_.Groups[1].Value })
$expectedTokkaIDs = @(97455,97457,97458,97459,97460,97461,97462,97463,97464,97465)
if ($tokkaIDs.Count -ne 10 -or (Compare-Object $tokkaIDs $expectedTokkaIDs)) { $failures += 'Captain Tokka artifact quest IDs are incomplete or incorrect.' }
if ($tokkaBlock -match '97456') { $failures += 'Quest 97456 was incorrectly added to Treasures of the Damned.' }
Assert-Source 'UI.lua' 'IsQuestFlaggedCompletedOnAccount\(questID\)[\s\S]*IsQuestFlaggedCompleted\(questID\)' 'Tokka completion does not prefer account-wide quest state with a safe fallback.'
Assert-Source 'UI.lua' 'GetTokkaTreasureProgress\(\)[\s\S]*for _, artifact in ipairs\(artifacts\)[\s\S]*completed = completed \+ 1' 'Tokka progress calculation is missing.'
Assert-Source 'UI.lua' 'FactionTokkaWindow:SetPoint\("TOPLEFT"[\s\S]*FactionTokkaWindow:SetPoint\("BOTTOMRIGHT"' 'Captain Tokka does not use the full Factions content area.'
Assert-Source 'UI.lua' 'SetFactionSectionMode\(mode\)[\s\S]*FactionWeeklyWindow:SetShown\(showWeeklies\)[\s\S]*FactionTokkaWindow:SetShown\(not showWeeklies\)' 'Factions secondary views are not switched exclusively.'
Assert-Source 'UI.lua' 'function lv\.UpdateCaptainTokkaWindow\(\)[\s\S]*RenderTokkaTracker\(\)' 'Tokka dedicated view does not render the tracker.'
Assert-Source 'UI.lua' 'tokkaWarning:SetPoint\("TOPLEFT", tokkaReputation, "BOTTOMLEFT"[\s\S]*tokkaScrollFrame:SetPoint\("TOPLEFT", 20, -112\)' 'Captain Tokka warning is not positioned above the tracker.'
Assert-Source 'UI.lua' 'tokkaWarning:SetText\(L\["WARNING_TOKKA_ONE_TIME_ARTIFACTS"\]\)' 'Captain Tokka warning text is not refreshed with its dedicated view.'
if ($tokkaBlock -match 'LiteVaultDB') { $failures += 'Tokka permanent progression was added to SavedVariables.' }
Assert-Source 'UI.lua' 'factionUI\.warning:SetPoint\("TOPLEFT", 20, -120\)[\s\S]*factionUI\.scrollFrame:SetPoint\("TOPLEFT", 20, -162\)[\s\S]*factionUI\.scrollFrame:SetPoint\("TOPLEFT", 20, -120\)' 'Faction-weekly warning/content anchors do not clear the appended selector row.'
Assert-Source 'UI.lua' 'key = "silvermoon"[^\r\n]*warningKey = "WARNING_WEEKLY_RUNESTONES"' 'Silvermoon Court warning metadata is missing.'
Assert-Source 'UI.lua' 'key = "(amani|harati|singularity|ritualsites|zuljarra)"[^\r\n]*warningKey' 'A non-Silvermoon faction still has warning metadata.' -Absent
Assert-Source 'UI.lua' 'if not def or def\.key ~= "silvermoon" then\s*return ""' 'Faction warning resolution is not explicitly Silvermoon-only.'
Assert-Source 'UI.lua' 'warningText = warningText or ""\s*factionUI\.warning:SetText\(warningText\)[\s\S]*if warningText ~= "" then[\s\S]*factionUI\.warning:Show\(\)[\s\S]*else[\s\S]*factionUI\.warning:Hide\(\)' 'Faction switching does not clear and hide stale warning text.'
Assert-Source 'UI.lua' 'WARNING_WEEKLY_AMANI_CHOICE|WARNING_WEEKLY_SINGULARITY_CHOICE' 'Removed non-Silvermoon warning localization remains referenced.' -Absent
Assert-Source 'Core.lua' 'GetActiveUpgradeSeasonKey\(interfaceVersion\)[\s\S]*>= 120100 and "midnight_s2" or "midnight_s1"' 'Upgrade-season selection is not interface-version gated.'
Assert-Source 'Core.lua' 'function lv\.GetClientInterfaceVersion\(\)\s*local interfaceVersion = select\(4, GetBuildInfo\(\)\)\s*return tonumber\(interfaceVersion\) or 0' 'Client interface helper does not capture exactly one GetBuildInfo return value.'
Assert-Source 'Core.lua' 'tonumber\(select\(4, GetBuildInfo\(\)\)\)' 'Unsafe multiple-return tonumber(select(...)) call remains.' -Absent
Assert-Source 'Calendar.lua' 'local eventConfig = lv\.EVENT_CONFIG or \{\}[\s\S]*pairs\(eventConfig\)[\s\S]*pairs\(eventConfig\)' 'Calendar EVENT_CONFIG loops are not nil-safe.'
Assert-Source 'Calendar.lua' 'pairs\(lv\.EVENT_CONFIG\)' 'Calendar still directly iterates a possibly nil EVENT_CONFIG.' -Absent
Assert-Source 'Core.lua' '\["Timewalking"\][\s\S]*key="timewalking"[\s\S]*\["Darkmoon"\][\s\S]*key="darkmoon"[\s\S]*\["Dungeon"\][\s\S]*key="dungeon"[\s\S]*\["Battleground"\][\s\S]*key="pvp"[\s\S]*\["Bonus Event"\][\s\S]*key="bonus"[\s\S]*\["Trial of Style"\]' 'Normal Calendar event configuration categories regressed.'
Assert-Source 'Core.lua' 'sparkItemID\s*=\s*232875[\s\S]*catalystCurrencyID\s*=\s*3378' 'Season 1 Spark/Catalyst configuration regressed.'
Assert-Source 'Core.lua' 'sparkItemID\s*=\s*274476[\s\S]*catalystCurrencyID\s*=\s*3465' 'Season 2 Spark/Catalyst configuration is missing.'
foreach($id in @(3383,3341,3343,3345,3347,3442,3443,3444,3445,3446,3437,3438,3439,3440,3441)) {
    if((Get-Content -LiteralPath (Join-Path $root 'Core.lua') -Raw -Encoding UTF8) -notmatch "(?<!\d)$id(?!\d)"){$failures += "Seasonal crest candidate ID missing: $id"}
}
Assert-Source 'Core.lua' 'ResolveActiveCrestCurrencyID[\s\S]*preferredCurrencyID[\s\S]*alternateCurrencyIDs' 'Mistcrest preferred/alternate resolver is missing.'
Assert-Source 'Core.lua' 'preferred.*quantity.*\+|alternate.*quantity.*\+' 'Mistcrest candidate quantities are summed.' -Absent
Assert-Source 'Currency.lua' 'CanonicalizeCrestKey[\s\S]*Mistcrest[\s\S]*Dawncrest' 'Currency canonicalization does not preserve distinct crest families.'
Assert-Source 'Currency.lua' 'MIDNIGHT_DIRECT_CURRENCY_IDS\["Corrosive Coin"\]\s*=\s*3448' 'Corrosive Coin direct-currency integration is missing.'
Assert-Source 'Core.lua' 'table\.insert\(MIDNIGHT_WEEKLY_QUESTS, \{name="Trailing Xal''atath", id=98172\}\)' 'Trailing Xal''atath is not an independent gated general weekly.'
Assert-Source 'Core.lua' 'name="Lady Liadrin Weekly"[\s\S]*93910[\s\S]*95843[\s\S]*98232' 'Lady Liadrin variant tracking regressed.'
Assert-Source 'Core.lua' 'name="A Nightmarish Task", id=94446' 'A Nightmarish Task regressed.'
Assert-Source 'Modules\InstanceTracker.lua' 'GetActiveCrestDefinitions\(\)[\s\S]*ResolveActiveCrestCurrencyID' 'New InstanceTracker runs do not use active crest definitions.'
Assert-Source 'UI\InstancePanel.lua' 'Adventurer Dawncrest[\s\S]*Myth Dawncrest[\s\S]*Adventurer Mistcrest[\s\S]*Myth Mistcrest' 'Historical Instance Panel does not understand both crest families.'
Assert-Source 'Modules\InstanceTracker.lua' 'CHALLENGE_MODE_START[\s\S]*mplusStarted\s*=\s*true[\s\S]*isCompleted\s*=\s*false[\s\S]*GetActiveKeystoneInfo[\s\S]*CopyArray\(affixIDs\)' 'Mythic+ start capture is incomplete or marks a run complete.'
Assert-Source 'Modules\InstanceTracker.lua' 'CHALLENGE_MODE_COMPLETED"[\s\S]*GetChallengeCompletionInfo[\s\S]*mplusTimeMS\s*=\s*tonumber\(info\.time\)[\s\S]*onTime\s*=\s*info\.onTime' 'Authoritative Mythic+ completion capture is incomplete.'
Assert-Source 'Modules\InstanceTracker.lua' 'CHALLENGE_MODE_COMPLETED_REWARDS[\s\S]*quantity=reward\.quantity[\s\S]*money=money[\s\S]*rewards=copiedRewards' 'Mythic+ reward payload is not copied exactly.'
Assert-Source 'Modules\InstanceTracker.lua' 'CHALLENGE_MODE_RESET[\s\S]*mplusReset\s*=\s*true[\s\S]*isCompleted\s*=\s*false' 'Mythic+ reset does not discard incomplete completion state.'
Assert-Source 'Modules\InstanceTracker.lua' 'practiceRun[\s\S]*mplusCompleted\s*=\s*false' 'Practice runs are not excluded from persistence.'
Assert-Source 'Modules\InstanceTracker.lua' 'C_Timer\.After\(1\.5[\s\S]*FinalizePendingMPlus' 'Bounded Mythic+ completion/reward reconciliation is missing.'
Assert-Source 'Modules\InstanceTracker.lua' 'if not run\.crestGains then[\s\S]*GetCrestCurrencyGains' 'Crest snapshot is not fallback-only for Mythic+ rewards.'
Assert-Source 'Modules\InstanceTracker.lua' 'IsSameAuthoritativeMPlusRun[\s\S]*challengeMapID[\s\S]*keystoneLevel[\s\S]*mplusTimeMS' 'Authoritative Mythic+ deduplication fingerprint is incomplete.'
Assert-Source 'UI\InstancePanel.lua' 'mplusTimeMS\) / 1000' 'Exact Mythic+ milliseconds are not converted for display.'
Assert-Source 'UI\InstancePanel.lua' 'GetFilteredMPlusRuns[\s\S]*filter == "all"[\s\S]*filter == "week"[\s\S]*filter == "season"' 'Mythic+ history filters are incomplete.'
Assert-Source 'UI\InstancePanel.lua' 'CreateFrame\("Button", nil, widgets\.mplusRecentContent' 'Mythic+ history does not use reusable interactive row frames.'
Assert-Source 'UI\InstancePanel.lua' 'local MPLUS_HISTORY_COLUMNS\s*=\s*\{[\s\S]*LABEL_DUNGEON[\s\S]*LABEL_KEY[\s\S]*LABEL_RESULT[\s\S]*LABEL_TIME[\s\S]*LABEL_CHARACTER[\s\S]*LABEL_DATE[\s\S]*LABEL_REWARDS' 'Shared Mythic+ column geometry is incomplete.'
Assert-Source 'UI\InstancePanel.lua' 'ApplyMPlusColumnGeometry\(header, column\)[\s\S]*ApplyMPlusColumnGeometry\(fs, column\)' 'Mythic+ headers and row cells do not share authoritative column geometry.'
Assert-Source 'UI\InstancePanel.lua' 'LABEL_DUNGEON.*\s{8,}.*LABEL_KEY' 'Mythic+ header still relies on spacing-based alignment.' -Absent
Assert-Source 'UI\InstancePanel.lua' 'GetOverallDungeonScore\(\)' 'Current Mythic+ score is not sourced from Blizzard.'
Assert-Source 'UI\InstancePanel.lua' 'mplusWeekStats[\s\S]*\{335,-50\}[\s\S]*\{500,-50\}[\s\S]*\{335,-78\}[\s\S]*\{500,-78\}' 'Warband weekly summary is not a structural 2x2 stat layout.'
Assert-Source 'UI\InstancePanel.lua' 'mplusCharacterLabel:SetText[\s\S]*mplusCharacter:SetText\(string\.format\("\|c%s%s\|r"' 'Current-character label/value hierarchy is missing.'
Assert-Source 'UI\InstancePanel.lua' 'mplusCurrentKeyLabel:SetText[\s\S]*mplusCurrentKey:SetTextColor' 'Current-key label/value hierarchy is missing.'
Assert-Source 'UI\InstancePanel.lua' 'weekLabels\s*=\s*\{[\s\S]*LABEL_RUNS[\s\S]*STATUS_TIMED[\s\S]*LABEL_BEST_TIMED[\s\S]*LABEL_CRESTS' 'Warband stat labels are incomplete.'
Assert-Source 'UI\InstancePanel.lua' 'mplusSeasonSubtitle:SetText\(string\.format\("\|c%s%s\|r"' 'Season Bests does not identify the character by class-colored name.'
Assert-Source 'UI\InstancePanel.lua' 'mplusSeasonSubtitle:SetText\(T\("LABEL_CURRENT_CHARACTER"' 'Disconnected Current Character Season Bests label remains.' -Absent
Assert-Source 'UI\InstancePanel.lua' 'mplusHeaders\[columnIndex\]:SetTextColor\(unpack\(t\.textSecondary\)\)' 'Mythic+ history headers are not visually subdued.'
Assert-Source 'UI\InstancePanel.lua' 'ApplyMPlusHistoryRowTheme[\s\S]*theme\.rowStripeEven[\s\S]*theme\.rowStripeOdd' 'Mythic+ history rows do not use theme-aware alternating backgrounds.'
Assert-Source 'UI\InstancePanel.lua' 'local function ApplyMPlusHistoryRowTheme[\s\S]*local function GetPanelContentWidth[\s\S]*function lv\.UpdateInstancePanel\(\)[\s\S]*ApplyMPlusHistoryRowTheme\(row, t, false\)' 'Mythic+ history row theme helper is not file-scoped for UpdateInstancePanel.'
Assert-Source 'UI\InstancePanel.lua' 'for _, row in ipairs\(widgets\.mplusRecentRows or \{\}\)[\s\S]*ApplyMPlusHistoryRowTheme\(row, t, false\)' 'Existing Mythic+ history rows are not restyled during live theme changes.'
Assert-Source 'UI\InstancePanel.lua' 'for _, column in ipairs\(row\.columns\) do column:SetTextColor\(unpack\(t\.textPrimary\)\) end' 'Recycled Mythic+ history row text colors are not reset.'
Assert-Source 'UI\InstancePanel.lua' 'row\.columns\[1\]:SetTextColor\(unpack\(t\.textMuted or t\.textSecondary\)\)' 'Mythic+ empty-history text is not theme-aware.'
Assert-Source 'UI\InstancePanel.lua' 'local active = self\.filterKey == mplusHistoryFilter[\s\S]*theme\.buttonBgActive[\s\S]*theme\.textSecondary' 'Mythic+ filter hover/selected styling is not theme-aware.'
Assert-Source 'UI\InstancePanel.lua' 'SetBackdropBorderColor\(border\[1\], border\[2\], border\[3\], 0\.12\)' 'Mythic+ history row borders remain visually heavy.'
Assert-Source 'Modules\MPlusPlannerDebug.lua' 'SLASH_LVMPLUSPLANNERDEBUG1\s*=\s*"/lvmplusplannerdebug"' '/lvmplusplannerdebug is missing.'
Assert-Source 'Modules\MPlusPlannerDebug.lua' 'Pack\(pcall\(method, \.\.\.\)\)[\s\S]*if not results\[1\] then return nil end[\s\S]*unpack\(results, 2, results\.n\)' 'Planner debug SafeCall does not strip pcall status while preserving nil-containing returns.'
Assert-Source 'Modules\MPlusPlannerDebug.lua' 'GetCurrentSeason[\s\S]*GetOverallDungeonScore[\s\S]*GetMapTable' 'Planner debug current-player/map inspection is incomplete.'
Assert-Source 'Modules\MPlusPlannerDebug.lua' 'GetSeasonBestForMap[\s\S]*INTIME[\s\S]*OVERTIME[\s\S]*DISPLAY BEST' 'Planner debug Season Best inspection is incomplete.'
Assert-Source 'Modules\MPlusPlannerDebug.lua' 'tonumber\(overtimeInfo\.dungeonScore\)[\s\S]*tonumber\(displayBest\.dungeonScore\)' 'Planner debug display-best selection does not compare Blizzard dungeon scores.'
Assert-Source 'Modules\MPlusPlannerDebug.lua' 'GetSeasonBestAffixScoreInfoForMap[\s\S]*bestOverAllScore[\s\S]*DumpPrimitiveTable' 'Planner debug affix score inspection is incomplete.'
Assert-Source 'Modules\MPlusPlannerDebug.lua' 'local affixScores, bestOverAllScore = SafeCall\(C_MythicPlus, "GetSeasonBestAffixScoreInfoForMap"' 'Planner debug affix-score return ordering is incorrect.'
Assert-Source 'Modules\MPlusPlannerDebug.lua' 'name=%s score=%s level=%s durationSec=%s overTime=%s' 'Planner debug documented affix-score fields are not printed.'
Assert-Source 'Modules\MPlusPlannerDebug.lua' 'GetMapScoreInfo[\s\S]*displayScores' 'Planner debug map score inspection is incomplete.'
Assert-Source 'Modules\MPlusPlannerDebug.lua' 'GetCurrentAffixes[\s\S]*GetAffixInfo' 'Planner debug current-affix inspection is incomplete.'
Assert-Source 'Modules\MPlusPlannerDebug.lua' 'GetRunHistory", true, false, true[\s\S]*printed >= 25' 'Planner debug run-history sample is incomplete or unbounded.'
Assert-Source 'Modules\MPlusPlannerDebug.lua' 'total history records returned=[\s\S]*season=%s currentSeasonMatch=%s' 'Planner debug history is filtered before season values are reported.'
Assert-Source 'Modules\MPlusPlannerDebug.lua' 'GetResearchCandidateScore[\s\S]*RESEARCH candidateEstimate=%s difference\(actual-candidate\)=%s' 'Planner debug research-only candidate comparison is missing.'
Assert-Source 'Modules\MPlusPlannerDebug.lua' 'LiteVaultDB|RaiderIO|https?://' 'Planner debug module introduced persistence or an external dependency.' -Absent
Assert-Source 'LiteVault.toc' 'Modules\\MPlusPlannerDebug\.lua' 'Planner debug module is not loaded.'
Assert-Source 'LiteVault.toc' 'Modules\\MPlusPlanner\.lua[\s\S]*Modules\\MPlusPlannerDebug\.lua' 'Shared planner helper does not load before planner debug.'
Assert-Source 'Modules\MPlusPlanner.lua' 'function Planner\.EstimateTimedScore[\s\S]*durationSec > timeLimit then return nil' 'Production estimator is not timed-only.'
Assert-Source 'Modules\MPlusPlanner.lua' 'function Planner\.NormalizeProjectedScore[\s\S]*math\.floor\(score \+ 0\.000001\)' 'Projected score normalization is not conservative.'
Assert-Source 'Modules\MPlusPlannerDebug.lua' 'lv\.MPlusPlanner\.EstimateTimedScore' 'Planner debug does not use the shared production estimator.'
Assert-Source 'Modules\MPlusPlannerDebug.lua' 'CANDIDATE_BASE_SCORE|timePercent \* 37\.5' 'Planner debug retains a duplicate scoring formula.' -Absent
Assert-Source 'Modules\MPlusPlanner.lua' 'GetMapScoreInfo[\s\S]*dungeonScore=tonumber\(scoreInfo\.dungeonScore\) or 0[\s\S]*GetOverallDungeonScore' 'Planner Blizzard baseline acquisition is incomplete.'
Assert-Source 'Modules\MPlusPlanner.lua' 'EstimateTimedScore\(level, dungeon\.timeLimit, dungeon\.timeLimit\)' 'Planner hypothetical runs do not use the conservative timer threshold.'
Assert-Source 'Modules\MPlusPlanner.lua' 'math\.max\(0, projected - dungeon\.dungeonScore\)[\s\S]*if gain > 0' 'Planner gain does not compare against Blizzard dungeon score or retain only positive candidates.'
Assert-Source 'Modules\MPlusPlanner.lua' 'for _, group in ipairs\(groups\)[\s\S]*local route=CopyRoute' 'Planner is not a bounded multiple-choice dynamic program.'
Assert-Source 'Modules\MPlusPlanner.lua' 'strategy == "fastest"[\s\S]*"runCount","maxKey","sumKeys","overshoot"' 'Fastest optimization priorities are incorrect.'
Assert-Source 'Modules\MPlusPlanner.lua' 'strategy == "easiest"[\s\S]*"maxKey","sumKeys","runCount","overshoot"' 'Easiest optimization priorities are incorrect.'
Assert-Source 'Modules\MPlusPlanner.lua' 'balanceCost=a\.maxKey\+\(a\.runCount\*2\)' 'Balanced optimization cost is incorrect.'
Assert-Source 'Modules\MPlusPlanner.lua' 'maximumGain < required[\s\S]*status="unreachable"[\s\S]*maximumProjected=current\+maximumGain' 'Unreachable target handling is incomplete.'
Assert-Source 'Modules\MPlusPlanner.lua' 'targetRating <= current[\s\S]*status="alreadyReached"' 'Already-at-target handling is missing.'
Assert-Source 'Modules\MPlusPlanner.lua' 'not targetRating or targetRating % 1 ~= 0[\s\S]*status="invalidTarget"' 'Invalid Planner target is not rejected.'
Assert-Source 'Modules\MPlusPlanner.lua' 'minimumKey % 1 ~= 0 or minimumKey < 2[\s\S]*status="invalidMinimum"' 'Planner minimum-key validation is incomplete.'
Assert-Source 'Modules\MPlusPlanner.lua' 'maximumKey < minimumKey or maximumKey > 20[\s\S]*status="invalidMaximum"' 'Planner maximum-key validation is incomplete.'
Assert-Source 'Modules\MPlusPlanner.lua' 'if not avoided\[dungeon\.mapChallengeModeID\][\s\S]*for level=minimumKey,maximumKey' 'Planner avoidance or key-range candidate constraints are incomplete.'
Assert-Source 'Modules\MPlusPlanner.lua' 'projectedOverall|current\+.*gain' 'Planner overall projection does not begin from Blizzard current score.'
Assert-Source 'Modules\MPlusPlanner.lua' 'LiteVaultDB|GetRunHistory|RaiderIO|https?://' 'Production planner uses persistence, run history, or an external service.' -Absent
Assert-Source 'Modules\MPlusPlanner.lua' 'run\.season|GetCurrentSeason' 'Production planner compares incompatible season namespaces.' -Absent
Assert-Source 'UI\InstancePanel.lua' 'mplusPlanButton:SetScript[\s\S]*mplusPlannerMode=true[\s\S]*BUTTON_PLAN_RATING' 'Plan Rating entry flow is missing.'
Assert-Source 'UI\InstancePanel.lua' 'plannerBack:SetScript[\s\S]*mplusPlannerMode=false[\s\S]*BUTTON_BACK_TO_DASHBOARD' 'Planner dashboard return flow is missing.'
Assert-Source 'UI\InstancePanel.lua' 'mplusSeasonBox:SetShown\(not showInstances and not mplusPlannerMode\)[\s\S]*mplusPlannerBox:SetShown\(not showInstances and mplusPlannerMode\)' 'Planner lower-panel replacement is incorrect.'
Assert-Source 'UI\InstancePanel.lua' 'mplusPlannerAvoided\[self\.mapID\][\s\S]*MPlusPlanner\.Calculate' 'Avoid-dungeon transient state is not passed to calculation.'
Assert-Source 'UI\InstancePanel.lua' 'RouteSignature[\s\S]*table\.concat\(group\.labels," / "\)' 'Duplicate strategy routes are not combined.'
Assert-Source 'UI\InstancePanel.lua' 'plannerResultsScroll:SetPoint\("TOPLEFT"[\s\S]*SetScrollChild\(widgets\.plannerResultsContent\)[\s\S]*SetScript\("OnMouseWheel"' 'Planner results do not scroll inside the existing panel.'
Assert-Source 'UI\InstancePanel.lua' 'tonumber\(C_ChallengeMode\.GetOverallDungeonScore\(\)\) or 0' 'Mythic+ score badge does not safely handle zero/nil score.'
Assert-Source 'UI\InstancePanel.lua' 'GetDungeonScoreRarityColor and C_ChallengeMode\.GetDungeonScoreRarityColor' 'Score rarity color lookup is not nil-safe.'
Assert-Source 'UI\InstancePanel.lua' 'key\.name and key\.level[\s\S]*key\.mapChallengeModeID[\s\S]*GetMapUIInfo' 'Current-key name/level compatibility or safe texture lookup regressed.'
Assert-Source 'UI\InstancePanel.lua' 'GetCurrentSeasonBestRows[\s\S]*MPlusPlanner\.GetCurrentMapPool[\s\S]*GetSeasonBestForMap\(challengeMapID\)' 'Season Best map discovery is not shared with the Blizzard-runtime planner pool.'
Assert-Source 'UI\InstancePanel.lua' 'local best, onTime = intimeInfo, true[\s\S]*if not best and overtimeInfo then best, onTime = overtimeInfo, false end' 'Season Best timed/overtime selection semantics regressed.'
Assert-Source 'UI\InstancePanel.lua' 'dungeonScore=best and tonumber\(best\.dungeonScore\)' 'Season Best score is not read directly from Blizzard record data.'
Assert-Source 'UI\InstancePanel.lua' 'LiteVaultDB[^\n]*(seasonBest|SeasonBest)' 'Transient Season Best model was persisted.' -Absent
Assert-Source 'UI\InstancePanel.lua' 'RaiderIO|Raider\.IO|MythicPlanner|targetScore|scoreGain' 'External/custom Mythic+ scoring dependency was introduced.' -Absent
Assert-Source 'UI\InstancePanel.lua' 'row\.SetBackdropColor|row:SetBackdropColor' 'Mythic+ row striping is missing.'
Assert-Source 'UI\InstancePanel.lua' 'FILTER_THIS_WEEK[\s\S]*FILTER_SEASON[\s\S]*FILTER_ALL_HISTORY' 'Mythic+ history filters regressed.'
Assert-Source 'UI\InstancePanel.lua' 'mplusToday|LABEL_RUNS_TODAY' 'Obsolete Runs Today Mythic+ summary remains.' -Absent
Assert-Source 'Core.lua' 'currentKey[\s\S]*mapChallengeModeID[\s\S]*timeLimit[\s\S]*texture' 'Current keystone metadata is not preserved.'
Assert-Source 'Teleports.lua' 'TELEPORT_SEASONS[\s\S]*midnight_s1[\s\S]*midnight_s2[\s\S]*GetActiveTeleportSeasonKey' 'Season-aware teleport pools are missing.'
Assert-Source 'Teleports.lua' 'local known = db\.teleports or \{\}' 'Active teleport scanning deletes inactive historical spell flags.'
foreach($id in @(1286812,1286809,1286807,1286801,1286804,393256,1286831,1286828)) {
    if((Get-Content -LiteralPath (Join-Path $root 'Teleports.lua') -Raw -Encoding UTF8) -notmatch "spellID\s*=\s*$id"){$failures += "Season 2 teleport spell missing: $id"}
}
Assert-Source 'Achievements.lua' 'key = "seasonalNemesis"[\s\S]*id=61797[\s\S]*id=63326' 'Delver Seasonal Nemesis variants are incomplete.'
Assert-Source 'Achievements.lua' 'if info\.variants then[\s\S]*for _, variant in ipairs\(info\.variants\)[\s\S]*HasAchievement\(variant\.id\)' 'Delver Seasonal Nemesis is not OR logic.'
Assert-Source 'LiteVault.toc' '## Interface: 120001, 120005, 120007, 120100, 120105' 'TOC interface 120105 is missing.'
Assert-Source 'Core.lua' 'SLASH_LVS2DEBUG1\s*=\s*"/lvs2debug"' '/lvs2debug is missing.'
Assert-Source 'Core.lua' '268650[\s\S]*268552' 'Season 1 Ascendant item IDs changed.'
Assert-Source 'Core.lua' 'Venomstone|NEBULOUS_VOIDCORE' 'Unverified Venomstone/Nebulous Voidcore behavior was added.' -Absent

# Behavioral model of the canonical merge contract: either write order leaves one boss.
function Add-Encounter([hashtable]$encounters, [int]$bossIndex, $encounterID) {
    $numeric = if ($encounterID) { [int]$encounterID } else { $null }
    $existingNumeric = @($encounters.Keys | Where-Object { $_ -is [int] -and $encounters[$_].bossIndex -eq $bossIndex }) | Select-Object -First 1
    $key = if ($numeric) { $numeric } elseif ($null -ne $existingNumeric) { $existingNumeric } else { "index:$bossIndex" }
    foreach ($old in @($encounters.Keys)) { if ($old -ne $key -and $encounters[$old].bossIndex -eq $bossIndex) { $encounters.Remove($old) } }
    $encounters[$key] = @{ bossIndex=$bossIndex; killed=$true; encounterID=$numeric }
}
foreach ($order in @(@($null,12345), @(12345,$null))) {
    $fixture=@{}; Add-Encounter $fixture 1 $order[0]; Add-Encounter $fixture 1 $order[1]
    if ($fixture.Count -ne 1 -or @($fixture.Values | Where-Object bossIndex -eq 1).Count -ne 1) { $failures += 'Encounter deduplication regression.' }
}

# Character migration fixture: account/global containers and Warband Bank are excluded.
$classTokens = @('WARRIOR','PALADIN','HUNTER','ROGUE','PRIEST','DEATHKNIGHT','SHAMAN','MAGE','WARLOCK','MONK','DRUID','DEMONHUNTER','EVOKER')
function Is-CharacterFixture([string]$key, [hashtable]$data, [string[]]$order) {
    if (-not $data -or $classTokens -notcontains $data.class) { return $false }
    return $order -contains $key -or ($key.Contains('-') -and ($data.ContainsKey('level') -or $data.ContainsKey('race') -or $data.ContainsKey('played') -or $data.ContainsKey('lastLogin')))
}
$orderFixture=@('Alyx-Realm')
if (-not (Is-CharacterFixture 'Alyx-Realm' @{class='MAGE';level=80} $orderFixture)) { $failures += 'Tracked character fixture was rejected.' }
if (Is-CharacterFixture 'Warband Bank' @{class='Bank';gold=1} $orderFixture) { $failures += 'Warband Bank fixture was treated as a character.' }
if (Is-CharacterFixture 'goldHistory' @{entries=@()} $orderFixture) { $failures += 'Global DB fixture was treated as a character.' }

# Schema-v4 migration model: copy to the internal key, retain the old key, and
# merge by boss index so repeated runs remain idempotent.
$seasonFixture = @{ raids = @{ 'The Voidspire' = @{ difficulties = @{ 16 = @{ encounters = @{ 'index:1' = @{killed=$true;bossIndex=1} } } } } } }
function Invoke-V4FixtureMigration([hashtable]$season) {
    $old = $season.raids['The Voidspire']
    if (-not $old) { return }
    if (-not $season.raids.ContainsKey('midnight_s1_voidspire')) { $season.raids['midnight_s1_voidspire'] = @{ difficulties=@{} } }
    $target = $season.raids['midnight_s1_voidspire']
    foreach($diffID in $old.difficulties.Keys) {
        if (-not $target.difficulties.ContainsKey($diffID)) { $target.difficulties[$diffID]=@{encounters=@{}} }
        foreach($entry in $old.difficulties[$diffID].encounters.Values) { $target.difficulties[$diffID].encounters["index:$($entry.bossIndex)"]=$entry.Clone() }
    }
}
Invoke-V4FixtureMigration $seasonFixture; Invoke-V4FixtureMigration $seasonFixture
if (-not $seasonFixture.raids.ContainsKey('The Voidspire')) { $failures += 'Schema-v4 migration removed rollback data.' }
if ($seasonFixture.raids.midnight_s1_voidspire.difficulties[16].encounters.Count -ne 1) { $failures += 'Schema-v4 migration is not idempotent.' }

$temporaryLairFixture = @{ raids = @{ midnight_s2_lair_boss = @{ difficulties = @{ world = @{ encounters = @{ 'index:1'=@{killed=$true;bossIndex=1} } } } } } }
function Invoke-TideboundFixtureMigration([hashtable]$season) {
    $old=$season.raids.midnight_s2_lair_boss
    if(-not $old){return}
    if(-not $season.raids.midnight_s2_tidebound_grotto){$season.raids.midnight_s2_tidebound_grotto=@{difficulties=@{}}}
    $target=$season.raids.midnight_s2_tidebound_grotto
    foreach($difficultyKey in $old.difficulties.Keys){
        if(-not $target.difficulties[$difficultyKey]){$target.difficulties[$difficultyKey]=@{encounters=@{}}}
        foreach($entry in $old.difficulties[$difficultyKey].encounters.Values){$target.difficulties[$difficultyKey].encounters["index:$($entry.bossIndex)"]=$entry.Clone()}
    }
}
Invoke-TideboundFixtureMigration $temporaryLairFixture; Invoke-TideboundFixtureMigration $temporaryLairFixture
if(-not $temporaryLairFixture.raids.midnight_s2_lair_boss){$failures += 'Temporary Lair migration deleted rollback data.'}
if($temporaryLairFixture.raids.midnight_s2_tidebound_grotto.difficulties.world.encounters.Count -ne 1){$failures += 'Temporary Lair migration is not idempotent.'}

# Schema-v5 first-kill behavioral contract. Only a directly observed new kill
# in an active season may establish a timestamp.
function Observe-FirstKillFixture($record, [bool]$progressionActive, [bool]$firstKillActive, [long]$observedAt) {
    if (-not $progressionActive) { return $record }
    if ($null -eq $record) {
        $record = @{ killed=$true; bossIndex=1 }
        if ($firstKillActive) { $record.firstKillAt=$observedAt; $record.firstKillSource='observed' }
    }
    return $record
}
$newS2 = Observe-FirstKillFixture $null $true $true 1787072400
if (-not $newS2.killed -or $newS2.firstKillAt -ne 1787072400 -or $newS2.firstKillSource -ne 'observed') { $failures += 'New observed Season 2 kill did not establish trustworthy history.' }
$repeatS2 = Observe-FirstKillFixture $newS2 $true $true 1787677200
if ($repeatS2.firstKillAt -ne 1787072400) { $failures += 'Repeat Season 2 kill replaced its first-kill date.' }
$undatedS2 = @{ killed=$true; bossIndex=1 }
$undatedRepeat = Observe-FirstKillFixture $undatedS2 $true $true 1787677200
if ($undatedRepeat.ContainsKey('firstKillAt')) { $failures += 'Undated historical Season 2 kill acquired a fake repeat-kill date.' }
$legacyBefore = @{ killed=$false; bossIndex=1 }
$legacyAfter = Observe-FirstKillFixture $legacyBefore $false $false 1787677200
if ($legacyAfter.killed -or $legacyAfter.ContainsKey('firstKillAt')) { $failures += 'Season 1 historical progression was not frozen.' }
$legacyWeekly = @{ bosses=@{} }; $legacyWeekly.bosses[1]=$true
if (-not $legacyWeekly.bosses[1]) { $failures += 'Legacy weekly lockout fixture did not remain writable.' }
$migratedS1 = @{ killed=$true; bossIndex=1 }
if ($migratedS1.ContainsKey('firstKillAt')) { $failures += 'Season 1 migration fabricated a first-kill timestamp.' }

function Get-WarbandFirstKillFixture([object[]]$kills) {
    $dated=@($kills | Where-Object { $_.firstKillSource -eq 'observed' -and $_.firstKillAt })
    $undated=@($kills | Where-Object { $_.firstKillSource -ne 'observed' -or -not $_.firstKillAt })
    $earliest=$null
    foreach($entry in $dated){if($null -eq $earliest -or $entry.firstKillAt -lt $earliest.firstKillAt){$earliest=$entry}}
    return @{ definitive=($kills.Count -gt 0 -and $undated.Count -eq 0 -and $dated.Count -gt 0); earliest=$earliest; hasUndated=($undated.Count -gt 0) }
}
$twoDated = Get-WarbandFirstKillFixture @(
    @{name='Dragon';firstKillAt=1787245200;firstKillSource='observed'},
    @{name='Gigalockqt';firstKillAt=1787072400;firstKillSource='observed'})
if (-not $twoDated.definitive -or $twoDated.earliest.name -ne 'Gigalockqt') { $failures += 'Two-character earliest first kill was derived incorrectly.' }
$threeDated = Get-WarbandFirstKillFixture @(
    @{name='Dragon';firstKillAt=30;firstKillSource='observed'},
    @{name='Gigalockqt';firstKillAt=10;firstKillSource='observed'},
    @{name='Dragonlock';firstKillAt=40;firstKillSource='observed'})
if (-not $threeDated.definitive -or $threeDated.earliest.name -ne 'Gigalockqt') { $failures += 'Three-character first-killer selection is incorrect.' }
$mixedHistory = Get-WarbandFirstKillFixture @(
    @{name='Dragon'}, @{name='Gigalockqt';firstKillAt=10;firstKillSource='observed'})
if ($mixedHistory.definitive -or -not $mixedHistory.hasUndated) { $failures += 'Mixed dated/undated history made a false definitive claim.' }
$allUndated = Get-WarbandFirstKillFixture @(@{name='Dragon'},@{name='Gigalockqt'})
if ($allUndated.definitive -or -not $allUndated.hasUndated -or $null -ne $allUndated.earliest) { $failures += 'All-undated history was not reported as unavailable.' }

function Merge-EncounterHistoryFixture($first, $second) {
    $records=@($first,$second)
    $hasUndated=@($records | Where-Object { -not $_.firstKillAt -or $_.firstKillSource -ne 'observed' }).Count -gt 0
    $earliest=$null
    foreach($entry in $records){if($entry.firstKillAt -and $entry.firstKillSource -eq 'observed' -and ($null -eq $earliest -or $entry.firstKillAt -lt $earliest.firstKillAt)){$earliest=$entry}}
    $merged=@{killed=$true;bossIndex=1}
    if(-not $hasUndated -and $null -ne $earliest){$merged.firstKillAt=$earliest.firstKillAt;$merged.firstKillSource='observed'}
    return $merged
}
$indexToNumeric=Merge-EncounterHistoryFixture @{killed=$true;bossIndex=1;firstKillAt=20;firstKillSource='observed'} @{killed=$true;bossIndex=1;firstKillAt=10;firstKillSource='observed'}
$numericToIndex=Merge-EncounterHistoryFixture @{killed=$true;bossIndex=1;firstKillAt=10;firstKillSource='observed'} @{killed=$true;bossIndex=1;firstKillAt=20;firstKillSource='observed'}
if($indexToNumeric.firstKillAt -ne 10 -or $numericToIndex.firstKillAt -ne 10){$failures += 'Encounter identity merge did not preserve the earliest trustworthy timestamp.'}
$uncertainMerge=Merge-EncounterHistoryFixture @{killed=$true;bossIndex=1} @{killed=$true;bossIndex=1;firstKillAt=10;firstKillSource='observed'}
if($uncertainMerge.ContainsKey('firstKillAt')){$failures += 'Undated encounter merge made a false first-kill claim.'}

$difficultyFixture=@{ normal=@{firstKillAt=10}; heroic=@{firstKillAt=20}; world=@{firstKillAt=30} }
if($difficultyFixture.normal.firstKillAt -eq $difficultyFixture.heroic.firstKillAt -or $difficultyFixture.world.firstKillAt -ne 30){$failures += 'Difficulty-specific or semantic world history isolation failed.'}
$immutableCharacters=@(@{name='A';firstKillAt=20;firstKillSource='observed'},@{name='B';firstKillAt=10;firstKillSource='observed'})
$immutableSnapshot=($immutableCharacters | ConvertTo-Json -Compress); $null=Get-WarbandFirstKillFixture $immutableCharacters
if(($immutableCharacters | ConvertTo-Json -Compress) -ne $immutableSnapshot){$failures += 'Warband history aggregation mutated character records.'}

# Mythic+ lifecycle fixtures: only authoritative, non-practice completions persist.
function Complete-MPlusFixture([hashtable]$run, [hashtable]$completion, [hashtable]$rewards) {
    if ($completion.practiceRun) { return $null }
    $run.mplusCompleted=$true; $run.map=$completion.map; $run.level=$completion.level
    $run.timeMS=$completion.time; $run.onTime=$completion.onTime
    if ($null -ne $rewards) { $run.money=$rewards.money; $run.crests=$rewards.crests; $run.rewardSource='challengeRewards' }
    elseif ($run.ContainsKey('snapshotCrests')) { $run.crests=$run.snapshotCrests; $run.rewardSource='currencySnapshot' }
    return $run
}
$timedFixture=Complete-MPlusFixture @{started=$true;snapshotCrests=9} @{map=101;level=12;time=1234567;onTime=$true;practiceRun=$false} @{money=50000;crests=12}
if(-not $timedFixture.mplusCompleted -or -not $timedFixture.onTime -or $timedFixture.timeMS -ne 1234567 -or $timedFixture.crests -ne 12 -or $timedFixture.rewardSource -ne 'challengeRewards'){$failures += 'Timed authoritative Mythic+ fixture failed.'}
$depletedFixture=Complete-MPlusFixture @{started=$true;snapshotCrests=7} @{map=101;level=12;time=2234567;onTime=$false;practiceRun=$false} $null
if($depletedFixture.onTime -ne $false -or $depletedFixture.crests -ne 7 -or $depletedFixture.rewardSource -ne 'currencySnapshot'){$failures += 'Depleted fallback Mythic+ fixture failed.'}
$practiceFixture=Complete-MPlusFixture @{started=$true} @{map=101;level=2;time=1000;onTime=$true;practiceRun=$true} $null
if($null -ne $practiceFixture){$failures += 'Practice Mythic+ fixture was persisted.'}
$resetFixture=@{started=$true;isCompleted=$false;reset=$true}
if($resetFixture.isCompleted){$failures += 'Reset Mythic+ fixture became completed.'}
$fingerprints=@('A|101|12|1234567','A|101|12|1234567','B|101|12|1234567')
if(@($fingerprints | Select-Object -Unique).Count -ne 2){$failures += 'Mythic+ deduplication fixture failed.'}
$filterRuns=@(@{end=90;season=1},@{end=110;season=1},@{end=120;season=2})
if(@($filterRuns | Where-Object end -ge 100).Count -ne 2 -or @($filterRuns | Where-Object season -eq 1).Count -ne 2 -or $filterRuns.Count -ne 3){$failures += 'Mythic+ week/season/all filter fixture failed.'}

# Planner v1 live-baseline and timed-only estimator fixtures.
$plannerBase=@{2=155;3=170;4=200;5=215;6=230;7=260;8=275;9=290;10=320;11=335;12=365;13=380;14=395;15=410;16=425;17=440;18=455;19=470;20=485}
function Estimate-PlannerTimedFixture([int]$level,[double]$duration,[double]$limit){if($duration -gt $limit -or -not $plannerBase.ContainsKey($level)){return $null};$pct=[math]::Min(($limit-$duration)/$limit,0.40);return [double]$plannerBase[$level]+($pct*37.5)}
function Normalize-PlannerFixture([double]$score){return [math]::Floor($score+0.000001)}
if([math]::Abs((Estimate-PlannerTimedFixture 13 1232 1680)-390)-gt 0.01){$failures += 'Skyreach timed estimator fixture regressed.'}
if([math]::Abs((Estimate-PlannerTimedFixture 12 1802 1860)-366.169)-gt 0.02){$failures += 'Algethar timed estimator fixture regressed.'}
if([math]::Abs((Estimate-PlannerTimedFixture 12 1599 2040)-373.107)-gt 0.02){$failures += 'Magisters Terrace timed estimator fixture regressed.'}
if((Normalize-PlannerFixture 366.17)-ne 366 -or (Normalize-PlannerFixture 373.11)-ne 373){$failures += 'Planner conservative normalization fixture regressed.'}
if($null -ne (Estimate-PlannerTimedFixture 15 2157 1980)){$failures += 'Planner fixture estimated a depleted run.'}
$livePlannerScores=@(0,0,390,366,0,373,0,317)
if(($livePlannerScores|Measure-Object -Sum).Sum -ne 1446){$failures += 'Planner live Blizzard dungeon baselines do not sum to 1446.'}
$zeroGain=(Normalize-PlannerFixture (Estimate-PlannerTimedFixture 10 1800 1800))-0
$depletedBaselineGain=[math]::Max(0,(Normalize-PlannerFixture (Estimate-PlannerTimedFixture 15 1800 1800))-317)
if($zeroGain -le 0 -or $depletedBaselineGain -ne 93){$failures += 'Zero/depleted Blizzard baseline gain fixture failed.'}
$strategyRoutes=@(
    [pscustomobject]@{name='hard3';runCount=3;maxKey=15;sumKeys=45;overshoot=46;balanceCost=21},
    [pscustomobject]@{name='mid4';runCount=4;maxKey=12;sumKeys=48;overshoot=46;balanceCost=20},
    [pscustomobject]@{name='easy4';runCount=4;maxKey=10;sumKeys=40;overshoot=0;balanceCost=18})
$fastest=$strategyRoutes|Sort-Object runCount,maxKey,sumKeys,overshoot|Select-Object -First 1
$easiest=$strategyRoutes|Sort-Object maxKey,sumKeys,runCount,overshoot|Select-Object -First 1
$balanced=$strategyRoutes|Sort-Object balanceCost,sumKeys,overshoot|Select-Object -First 1
if($fastest.name-ne'hard3'-or$easiest.name-ne'easy4'-or$balanced.name-ne'easy4'){$failures += 'Planner strategy-priority fixtures failed.'}
$onePerDungeon=@('239:14','556:13')
if(@($onePerDungeon|ForEach-Object{($_-split ':')[0]}|Group-Object|Where-Object Count -gt 1).Count -ne 0){$failures += 'Planner stacked more than one final run per dungeon.'}
$avoided=@{239=$true};$candidateMaps=@(239,556,161)|Where-Object{-not $avoided[$_]}
if($candidateMaps -contains 239 -or $candidateMaps.Count-ne 2){$failures += 'Planner avoidance fixture failed.'}

# Three character-owned kills aggregate to one Warband boss without mutating
# the selected character or accepting account/global fixtures.
$selectedCharacter = @{ class='MAGE'; level=80; kills=@{} }
$warbandFixtures = @(
    @{key='A-Realm';data=@{class='MAGE';level=80;kills=@{boss1=$true}}},
    @{key='B-Realm';data=@{class='WARRIOR';level=80;kills=@{boss1=$true}}},
    @{key='C-Realm';data=@{class='PRIEST';level=80;kills=@{boss1=$true}}},
    @{key='Warband Bank';data=@{class='Bank';kills=@{boss1=$true}}},
    @{key='filters';data=@{kills=@{boss1=$true}}}
)
$killers=@($warbandFixtures | Where-Object { Is-CharacterFixture $_.key $_.data @('A-Realm','B-Realm','C-Realm') } | Where-Object { $_.data.kills.boss1 })
$warbandBossCount = if ($killers.Count -gt 0) { 1 } else { 0 }
if ($killers.Count -ne 3 -or $warbandBossCount -ne 1) { $failures += 'Warband aggregation fixture is incorrect.' }
if ($selectedCharacter.kills.Count -ne 0) { $failures += 'Warband aggregation mutated selected-character progression.' }

# Representative runtime-validator contract (Unicode is accepted; known corruption is rejected).
$validLocaleSamples = @('Überblick','Équipement','Персонаж','角色进度','角色進度','캐릭터')
if (@($validLocaleSamples | Where-Object { $_ -match '\p{L}\?\p{L}|�|Ã|Â|â€' }).Count) { $failures += 'Valid multilingual locale sample rejected.' }
$badLocaleSamples = @('Grande C?mara','Abund?ncia','FranÃ§ais','bad�text')
if (@($badLocaleSamples | Where-Object { $_ -notmatch '\p{L}\?\p{L}|�|Ã|Â|â€' }).Count) { $failures += 'Known locale corruption sample was accepted.' }

if ($failures.Count -gt 0) {
    $failures | ForEach-Object { Write-Error $_ }
    throw 'Stabilization validation failed.'
}
Write-Output 'Stabilization validation passed.'
