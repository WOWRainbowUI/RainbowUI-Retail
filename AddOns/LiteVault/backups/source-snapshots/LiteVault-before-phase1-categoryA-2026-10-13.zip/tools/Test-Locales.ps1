﻿[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$localeDir = Join-Path $root 'Locales'
$utf8Strict = New-Object Text.UTF8Encoding($false, $true)

function Get-LocaleAssignments {
    param([Parameter(Mandatory)][string]$Path)
    $results = @()
    $lines = Get-Content -LiteralPath $Path -Encoding UTF8
    $inPhase2 = $false
    for ($index = 0; $index -lt $lines.Count; $index++) {
        $line = $lines[$index]
        if ($line -match '^local phase2\s*=\s*\{') { $inPhase2 = $true; continue }
        if ($inPhase2 -and $line -match '^\}') { $inPhase2 = $false; continue }
        if ($inPhase2) {
            foreach ($match in [regex]::Matches($line, '([A-Z][A-Z0-9_]*)\s*=\s*"((?:\\.|[^"\\])*)"')) {
                $results += [pscustomobject]@{ Key = $match.Groups[1].Value; Value = $match.Groups[2].Value; Line = $index + 1; Overlay = $true }
            }
            continue
        }
        if ($line -match '^\s*(?:L\.)?([A-Z][A-Z0-9_]*)\s*=\s*"((?:\\.|[^"\\])*)"') {
            $results += [pscustomobject]@{ Key = $matches[1]; Value = $matches[2]; Line = $index + 1; Overlay = $false }
        } elseif ($line -match '^\s*(?:L)?\["((?:\\.|[^"\\])+)"\]\s*=\s*"((?:\\.|[^"\\])*)"') {
            $results += [pscustomobject]@{ Key = $matches[1]; Value = $matches[2]; Line = $index + 1; Overlay = $false }
        }
    }
    return $results
}

function Get-FormatSignature {
    param([Parameter(Mandatory)][AllowEmptyString()][string]$Value)
    # Lua string.format conversions plus localized strftime tokens in TIME_* values.
    $pattern = '%(?:(?<position>\d+)\$)?(?<flags>[-+ #0]*)(?<width>\d+|\*)?(?<precision>\.(?:\d+|\*))?(?<length>hh|h|ll|l|L)?(?<type>[cdeEfgGiouqsxXHM])'
    $tokens = @(); $malformed = @(); $literalPercents = 0
    for ($i = 0; $i -lt $Value.Length;) {
        if ($Value[$i] -ne '%') { $i++; continue }
        if ($i + 1 -lt $Value.Length -and $Value[$i + 1] -eq '%') { $literalPercents++; $i += 2; continue }
        $match = [regex]::Match($Value.Substring($i), "^$pattern")
        if (-not $match.Success) { $malformed += $i; $i++; continue }
        $tokens += [pscustomobject]@{
            Position = if ($match.Groups['position'].Success) { [int]$match.Groups['position'].Value } else { $null }
            Spec = $match.Groups['flags'].Value + $match.Groups['width'].Value + $match.Groups['precision'].Value + $match.Groups['length'].Value + $match.Groups['type'].Value
        }
        $i += $match.Length
    }
    $usesPositions = @($tokens | Where-Object { $null -ne $_.Position }).Count -gt 0
    $mixedPositions = $usesPositions -and @($tokens | Where-Object { $null -eq $_.Position }).Count -gt 0
    $signature = if ($usesPositions) { @($tokens | Sort-Object Position | ForEach-Object { "$($_.Position):$($_.Spec)" }) -join ',' } else { @($tokens | ForEach-Object Spec) -join ',' }
    [pscustomobject]@{ Signature=$signature; LiteralPercents=$literalPercents; Malformed=$malformed; MixedPositions=$mixedPositions }
}

function Get-WowMarkupSignature {
    param([Parameter(Mandatory)][AllowEmptyString()][string]$Value)
    @((([regex]::Matches($Value, '\|c[0-9a-fA-F]{8}')).Count), (([regex]::Matches($Value, '\|r')).Count), (([regex]::Matches($Value, '\|T')).Count), (([regex]::Matches($Value, '\|t')).Count), (([regex]::Matches($Value, '\|A')).Count), (([regex]::Matches($Value, '\|a')).Count), (([regex]::Matches($Value, '\|H')).Count), (([regex]::Matches($Value, '\|h')).Count), (([regex]::Matches($Value, '\\n')).Count)) -join ','
}

$locales = @('enUS','deDE','frFR','esES','ptBR','ruRU','zhCN','zhTW','koKR')
$assignments = @{}
$maps = @{}
$failures = @()
$encodingFiles = @($locales | ForEach-Object { Join-Path $localeDir "$_.lua" }) + @(Join-Path $localeDir 'Repair.lua')
foreach ($path in $encodingFiles) {
    $label = Split-Path $path -Leaf
    $bytes = [IO.File]::ReadAllBytes($path)
    try { $text = $utf8Strict.GetString($bytes) } catch { $failures += "${label}: invalid UTF-8"; continue }
    if ($text -match '[\u0080-\u009F]') { $failures += "${label}: C1 control character" }
    if ($text.Contains([char]0xFFFD)) { $failures += "${label}: replacement character" }
    if ($text -cmatch 'Ã.|Â.|â€|â€™') { $failures += "${label}: mojibake signature" }
    if ($text -match '\p{L}\?\p{L}') { $failures += "${label}: question mark embedded in word" }
}
foreach ($locale in $locales) {
    $path = Join-Path $localeDir "$locale.lua"
    $bytes = [IO.File]::ReadAllBytes($path)
    try { $text = $utf8Strict.GetString($bytes) } catch { $failures += "${locale}: invalid UTF-8"; continue }
    if ($text -match '[\u0080-\u009F]') { $failures += "${locale}: C1 control character" }
    if ($text.Contains([char]0xFFFD)) { $failures += "${locale}: replacement character" }
    if ($text.Contains([char]0x00C3) -or $text.Contains([char]0x00C2)) { $failures += "${locale}: mojibake signature" }
    if ($text -match '\p{L}\?\p{L}') { $failures += "${locale}: question mark embedded in word" }

    $assignments[$locale] = @(Get-LocaleAssignments $path)
    $maps[$locale] = @{}
    foreach ($entry in $assignments[$locale]) { $maps[$locale][$entry.Key] = $entry.Value }
    foreach ($duplicate in @($assignments[$locale] | Where-Object { -not $_.Overlay } | Group-Object Key | Where-Object Count -gt 1)) {
        $failures += "${locale}: duplicate key $($duplicate.Name)"
    }
}

# Merge the compact stabilization overlay used at runtime.
$repairLines = Get-Content -LiteralPath (Join-Path $localeDir 'Repair.lua') -Encoding UTF8
$repairLocale = $null
foreach ($line in $repairLines) {
    if ($line -match '^\s{4}(enUS|deDE|frFR|esES|ptBR|ruRU|zhCN|zhTW|koKR)\s*=\s*\{') {
        $repairLocale = $matches[1]
    }
    if ($repairLocale -and $line -match '^\s{4}\},') { $repairLocale = $null; continue }
    if (-not $repairLocale) { continue }
    foreach ($match in [regex]::Matches($line, '(?:\["((?:\\.|[^"\\])+)"\]|([A-Z][A-Z0-9_]*))\s*=\s*"((?:\\.|[^"\\])*)"')) {
        $key = if ($match.Groups[1].Success) { $match.Groups[1].Value } else { $match.Groups[2].Value }
        $maps[$repairLocale][$key] = $match.Groups[3].Value
    }
}
$sharedFallbackKeys = @(
    'TEXT_PROFIT_FALLBACK_WOW_TOKEN_PURCHASE','TEXT_PROFIT_SOURCE_WOW_TOKEN','Title: \"Dustlord\"','Title: \"Chronicler of the Haranir\"','MSG_RAID_HISTORY_PRESERVED',
    'MSG_NO_FACTION_WEEKLY_COMPLETIONS','TOOLTIP_QUEST_ID_FMT','CALENDAR_MONTH_YEAR_FMT','LABEL_RENOWN_LEVEL_MAXIMUM_FMT','LABEL_RENOWN_LEVEL_PROGRESS_FMT','LABEL_RENOWN_LEVEL_FMT','LABEL_RENOWN_VALUE_FMT',
    'TEXT_CRESTS_WITH_VALUES_FMT','TOOLTIP_REWARDS_FMT','TOOLTIP_MOUNT_COLLECTED_FMT','TOOLTIP_MOUNT_UNCOLLECTED_FMT','LABEL_REWARD','LABEL_NOTE','STATUS_ACTIVE','TOOLTIP_ENTRANCE_COORDINATES_FMT',
    'TOOLTIP_INSCRIPTION_COORDINATES_FMT','TOOLTIP_ENTRANCE_INSCRIPTION_CLICK_INSTRUCTIONS','LABEL_100_RENOWN_FMT','TOOLTIP_ACHIEVEMENT_CREDIT_FROM_FMT',
    'NOTE_HARANDAR_TREASURE_REQUIREMENTS','NOTE_FORGOTTEN_MASK_LOCATION','NOTE_HEAD_MASONS_TABLET_LOCATION','NOTE_PROFANED_PLAQUE_LOCATION'
)
foreach ($locale in $locales) {
    foreach ($key in $sharedFallbackKeys) {
        if (-not $maps[$locale].ContainsKey($key)) { $maps[$locale][$key] = $maps['enUS'][$key] }
    }
}

$canonical = $maps['enUS']
foreach ($locale in $locales | Where-Object { $_ -ne 'enUS' }) {
    foreach ($key in $canonical.Keys) {
        if (-not $maps[$locale].ContainsKey($key)) { $failures += "${locale}: missing key $key"; continue }
        $expected = Get-FormatSignature $canonical[$key]
        $actual = Get-FormatSignature $maps[$locale][$key]
        if ($expected.Malformed.Count -gt 0) { $failures += "enUS: malformed percent sequence $key at $($expected.Malformed -join ',')" }
        if ($actual.Malformed.Count -gt 0) { $failures += "${locale}: malformed percent sequence $key at $($actual.Malformed -join ',')" }
        if ($expected.MixedPositions) { $failures += "enUS: mixed positional and sequential placeholders $key" }
        if ($actual.MixedPositions) { $failures += "${locale}: mixed positional and sequential placeholders $key" }
        if ($expected.Signature -ne $actual.Signature -or $expected.LiteralPercents -ne $actual.LiteralPercents) { $failures += "${locale}: placeholder mismatch $key expected=[$($expected.Signature)] actual=[$($actual.Signature)]" }
        if ((Get-WowMarkupSignature $canonical[$key]) -ne (Get-WowMarkupSignature $maps[$locale][$key])) { $failures += "${locale}: WoW markup mismatch $key" }
    }
}

foreach ($locale in $locales) {
    $missingCount = @($canonical.Keys | Where-Object { -not $maps[$locale].ContainsKey($_) }).Count
    $extraCount = @($maps[$locale].Keys | Where-Object { -not $canonical.ContainsKey($_) }).Count
    $exactEnglish = if ($locale -eq 'enUS') { 0 } else { @($canonical.Keys | Where-Object { $maps[$locale].ContainsKey($_) -and $maps[$locale][$_] -ceq $canonical[$_] }).Count }
    Write-Output ("{0}: unique={1} missing={2} extra={3} exactEnglish={4}" -f $locale, $maps[$locale].Count, $missingCount, $extraCount, $exactEnglish)
}

# Only active code-referenced UI keys are subject to exact-English policy.
$activeKeys = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$toc = Get-Content -LiteralPath (Join-Path $root 'LiteVault.toc') -Encoding UTF8
foreach ($relative in $toc | Where-Object { $_ -match '\.lua$' -and $_ -notmatch '^Locales\\' }) {
    $path = Join-Path $root $relative
    if (-not (Test-Path -LiteralPath $path)) { continue }
    $source = Get-Content -LiteralPath $path -Raw -Encoding UTF8
    foreach ($match in [regex]::Matches($source, '(?:L\s*\[|LText\s*\(|UIText\s*\(|(?<![A-Za-z0-9_])Text\s*\(|LT\s*\()\s*\[?\s*"((?:\\.|[^"\\])*)"')) {
        [void]$activeKeys.Add($match.Groups[1].Value)
    }
    foreach ($match in [regex]::Matches($source, "(?:L\s*\[|LText\s*\(|UIText\s*\(|(?<![A-Za-z0-9_])Text\s*\(|LT\s*\()\s*\[?\s*'((?:\\.|[^'\\])*)'")) {
        [void]$activeKeys.Add($match.Groups[1].Value)
    }
}
$validEqualityCategories = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach ($category in @('TRANSLATION_REQUIRED','BLIZZARD_IDENTITY','BRANDING','NATURAL_EQUIVALENT','LOANWORD_OR_ESTABLISHED_TERM','LANGUAGE_NEUTRAL_FORMAT','ABBREVIATION_OR_IDENTIFIER','COMPATIBILITY_REQUIRED')) {
    [void]$validEqualityCategories.Add($category)
}
$equalityClassifications = @{}
foreach ($line in Get-Content -LiteralPath (Join-Path $root 'tools\Locale-English-Allowlist.txt') -Encoding UTF8) {
    $entry = $line.Trim()
    if (-not $entry -or $entry.StartsWith('#')) { continue }
    $parts = $entry.Split('|', 3)
    if ($parts.Count -ne 3) { $failures += "malformed equality classification: $entry"; continue }
    $category, $scope, $key = @($parts | ForEach-Object Trim)
    if (-not $validEqualityCategories.Contains($category)) { $failures += "unknown equality classification category: $category"; continue }
    if ($scope -ne '*' -and $scope -notin $locales) { $failures += "unknown equality classification locale: $scope"; continue }
    if (-not $equalityClassifications.ContainsKey($key)) { $equalityClassifications[$key] = @{} }
    if ($equalityClassifications[$key].ContainsKey($scope)) { $failures += "duplicate equality classification: $scope/$key"; continue }
    $equalityClassifications[$key][$scope] = $category
}
if ($activeKeys.Count -lt 50) { $failures += "active localization extraction unexpectedly found only $($activeKeys.Count) keys" }
foreach ($key in $equalityClassifications.Keys) {
    if (-not $canonical.ContainsKey($key)) { $failures += "allowlist key is not canonical: $key" }
}
function Get-EqualityClassification {
    param([Parameter(Mandatory)][string]$Locale, [Parameter(Mandatory)][string]$Key)
    if (-not $equalityClassifications.ContainsKey($Key)) { return $null }
    if ($equalityClassifications[$Key].ContainsKey($Locale)) { return $equalityClassifications[$Key][$Locale] }
    if ($equalityClassifications[$Key].ContainsKey('*')) { return $equalityClassifications[$Key]['*'] }
    return $null
}

# Small synthetic regression fixtures keep the classification policy and strict
# structural checks honest without modifying source locale data.
if ((Get-EqualityClassification -Locale 'deDE' -Key 'BUTTON_FILTER') -ne 'NATURAL_EQUIVALENT') { $failures += 'regression: intentional English-equivalent value was not classified' }
if ((Get-EqualityClassification -Locale 'deDE' -Key 'A Singular Problem') -ne 'BLIZZARD_IDENTITY') { $failures += 'regression: Blizzard identity was not classified' }
$missingFixtureCanonical = @{ REQUIRED_FIXTURE_KEY = 'Required' }
$missingFixtureLocale = @{}
if (@($missingFixtureCanonical.Keys | Where-Object { -not $missingFixtureLocale.ContainsKey($_) }).Count -ne 1) { $failures += 'regression: missing symbolic key was not detected' }
$placeholderFixtureExpected = Get-FormatSignature 'Value: %s / %d'
$placeholderFixtureActual = Get-FormatSignature 'Value: %s / %s'
if ($placeholderFixtureExpected.Signature -eq $placeholderFixtureActual.Signature) { $failures += 'regression: placeholder mismatch was not detected' }
if (-not ('bad' + [char]0xFFFD + 'text').Contains([char]0xFFFD)) { $failures += 'regression: replacement-character corruption was not detected' }
if ('FranÃ§ais' -cnotmatch 'Ã.|Â.|â€|â€™') { $failures += 'regression: mojibake corruption was not detected' }
$translationRequiredFixture = @{ Value = 'English'; Canonical = 'English'; Classification = 'TRANSLATION_REQUIRED' }
if ($translationRequiredFixture.Value -cne $translationRequiredFixture.Canonical -or $translationRequiredFixture.Classification -ne 'TRANSLATION_REQUIRED') { $failures += 'regression: untranslated authored key was not detected' }
$activeExactCounts = @{}
$reviewedExactCounts = @{}
foreach ($locale in $locales | Where-Object { $_ -ne 'enUS' }) { $activeExactCounts[$locale] = 0; $reviewedExactCounts[$locale] = 0 }
$untranslatedSymbolicExact = 0
$untranslatedPhraseExact = 0
$reviewedCategoryCounts = @{}
foreach ($key in $activeKeys) {
    if ($key -eq 'ADDON_VERSION' -or $key.EndsWith('_')) { continue }
    if (-not $canonical.ContainsKey($key)) { $failures += "active key missing from enUS: $key"; continue }
    foreach ($locale in $locales | Where-Object { $_ -ne 'enUS' }) {
        if ($maps[$locale][$key] -ceq $canonical[$key]) {
            $classification = Get-EqualityClassification -Locale $locale -Key $key
            if ($classification -and $classification -ne 'TRANSLATION_REQUIRED') {
                $reviewedExactCounts[$locale]++
                if (-not $reviewedCategoryCounts.ContainsKey($classification)) { $reviewedCategoryCounts[$classification] = 0 }
                $reviewedCategoryCounts[$classification]++
            }
            else {
                $activeExactCounts[$locale]++
                if ($key -match '^[A-Z][A-Z0-9_]*$') { $untranslatedSymbolicExact++ } else { $untranslatedPhraseExact++ }
                $reason = if ($classification -eq 'TRANSLATION_REQUIRED') { 'classified as TRANSLATION_REQUIRED' } else { 'unclassified' }
                $failures += "${locale}: active exact-English key ${reason}: $key"
            }
        }
    }
}
foreach ($locale in $locales | Where-Object { $_ -ne 'enUS' }) {
    Write-Output ("{0}: untranslatedActiveExact={1} reviewedActiveExact={2}" -f $locale, $activeExactCounts[$locale], $reviewedExactCounts[$locale])
}
$commonActiveExact = @($activeKeys | Where-Object {
    $key = $_
    $canonical.ContainsKey($key) -and
    (@($locales | Where-Object { $_ -ne 'enUS' -and $maps[$_][$key] -ceq $canonical[$key] }).Count -eq ($locales.Count - 1))
}).Count
$activePhraseKeys = @($activeKeys | Where-Object { $canonical.ContainsKey($_) -and $_ -notmatch '^[A-Z][A-Z0-9_]*$' }).Count
$activeSymbolicKeys = @($activeKeys | Where-Object { $canonical.ContainsKey($_) -and $_ -match '^[A-Z][A-Z0-9_]*$' }).Count
Write-Output ("activeKeys={0} commonActiveExactEnglish={1} activePhraseKeys={2} classifiedKeys={3}" -f $activeKeys.Count, $commonActiveExact, $activePhraseKeys, $equalityClassifications.Count)
Write-Output ("activeSymbolicKeys={0} genuineUntranslatedSymbolicPairs={1} genuineUntranslatedActivePhrasePairs={2}" -f $activeSymbolicKeys, $untranslatedSymbolicExact, $untranslatedPhraseExact)
foreach ($category in $reviewedCategoryCounts.Keys | Sort-Object) {
    Write-Output ("reviewedEqualityCategory[{0}]={1}" -f $category, $reviewedCategoryCounts[$category])
}
if ($failures.Count -gt 0) {
    $failures | Sort-Object -Unique | ForEach-Object { Write-Output "ERROR: $_" }
    throw 'Locale validation failed.'
}
Write-Output 'Locale validation passed.'
