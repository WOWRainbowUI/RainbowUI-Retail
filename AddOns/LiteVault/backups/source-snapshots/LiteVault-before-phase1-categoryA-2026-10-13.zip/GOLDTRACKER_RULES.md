# GoldTracker Rules

* Warband Gold Tracker `12.0.7.0003` is the baseline reference for event handling and source detection.
* Compare future GoldTracker changes against WGT before implementation, but preserve documented LiteVault corrections for proven WGT misclassification cases.
* Source selection must be evidence-first:

  1. exact amount-backed claim
  2. explicit one-time action or event
  3. active UI context
  4. recent timer fallback
  5. loot fallback
* Source classification and transaction detail must use the same winning claim.
* Consume a winning claim once so it cannot label a later transaction.
* Direct gold from a normal or weekly quest is `quest`.
* Direct gold from a confirmed World Quest is `worldQuest`.
* Weekly status alone must never change a quest reward to `weeklyCache`.
* Gold from an actually opened named container is `cache`.
* Opened named Cache evidence may beat stale Quest or World Quest fallback state, but must not override an exact direct reward claim.
* Weak Cache signals, item-name patterns or bag changes alone must not classify a transaction.
* Every non-zero `PLAYER_MONEY` delta must create one primary transaction unless intentionally suppressed for a Warband Bank transfer.
* Generic dedupe must never remove primary transactions.
* Advance `lastKnownMoney` only after successful primary insertion or intentional Warband Bank suppression.
* Generated split rows must sum exactly to the original raw money delta.
* Preserve LiteVault's Upgrade source, named Cache support, Warband Bank suppression and generated split rows.
* Do not restore WGT's `0.1` second `PLAYER_MONEY` throttle.
* Diagnostics must never interrupt the active money-processing path.
* Keep `GoldTracker.lua` below Lua's 200-local limit. Reuse state tables or existing locals instead of adding unnecessary top-level locals.
* Do not change GoldTracker behavior from screenshots or assumptions alone. Inspect the current file and identify the exact winning claim and branch first.
