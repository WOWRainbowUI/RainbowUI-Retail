# LiteVault 12.0.7.4 stability checklist

Use a copied WTF folder. Test once with `LiteVaultDB`, `LiteVaultOrder`, and `LiteVaultMinimapDB` absent, then repeat with an existing 12.0.7.3 database.

## Fresh install

- [ ] First login and first `/reload` produce no Lua errors.
- [ ] First character scan records gold, currencies, professions, vault, and lockouts.
- [ ] Profession scan before opening the profession UI uses Midnight child skill lines (2906–2918 as applicable), including concentration and knowledge.
- [ ] First Warband Bank open displays the authoritative account-bank balance.
- [ ] A 1g deposit creates one Warband history row and no Profit row.
- [ ] A 1g withdrawal creates one Warband history row and no Profit row.
- [ ] A bank-tab purchase creates a normal Profit expense and no Warband history row.
- [ ] Normal gains and expenses outside the account bank create one Profit row each.
- [ ] Zoning and `/reload` do not erase a valid Profit comparison baseline.
- [ ] Hara'ti base IDs 88994, 88996, and 88997 complete their children.
- [ ] Hara'ti variant IDs 92719, 92721, and 92722 complete the same children.

## Existing install

- [ ] Existing Warband/Profit history remains readable; legacy weekly/monthly gold fields are unnecessary.
- [ ] Current-week weekly state survives reload/update and expires after reset.
- [ ] Permanent faction choices survive weekly resets.
- [ ] `/lvreset weekly` clears weekly quests, faction parents/dailies, vault state, and planner checks.

## Money/source matrix

- [ ] Repeat bank cases with Bagnon enabled and disabled and with personal/account bank tabs.
- [ ] Exercise AH, mail, vendor buy/sell, repair, quest/world quest, cache, trade, crafting, upgrade, guild bank, loot, training, transmog, flight path, Black Market, and fallback sources.
- [ ] Compare raw `goldHistory.transactions` sums with weekly/monthly character and account views.
- [ ] Confirm source filters default on, fit onscreen, affect list visibility only, and omit WoW Token.
- [ ] Confirm weekly graphs begin at the current Blizzard weekly reset.

## Other live checks

- [ ] Account-transferable currency totals populate after Blizzard account-character data becomes ready.
- [ ] Token affordability excludes declined/wrong-region/special records and counts Warband Bank once.
- [ ] Repeated identical token refreshes preserve the last distinct price.
- [ ] Opening Group Finder late in a session still attaches the Teleports panel.
- [ ] Saved raid lockouts resolve from the Retail `instanceID` return and display correct bosses.
