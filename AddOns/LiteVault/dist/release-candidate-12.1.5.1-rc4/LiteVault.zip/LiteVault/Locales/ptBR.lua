-- ptBR.lua - Brazilian Portuguese locale for LiteVault
local addonName, lv = ...

local L = {
    -- ==========================================================================
    -- ADDON INFO
    -- ==========================================================================
    ADDON_NAME = "LiteVault",

    -- ==========================================================================
    -- COMMON UI ELEMENTS
    -- ==========================================================================
    BUTTON_CLOSE = "Fechar",
    BUTTON_YES = "Sim",
    BUTTON_NO = "Não",
    BUTTON_MANAGE = "Gerenciar",
    BUTTON_BACK = "Voltar",
    BUTTON_ALL = "Todos",
    BUTTON_NONE = "Nenhum",
    BUTTON_FILTER = "Filtrar",
    TAB_TRACKERS = "Rastreadores",
    TAB_META_ACHIEVEMENTS = "Meta-conquistas",
    TEXT_FOLIO_NODE_FMT = "Nó %d",
    TEXT_GEAR_TITLE_FMT = "%s — %s",
    LABEL_GEAR_CRIT = "Crítico",
    LABEL_GEAR_HASTE = "Aceleração",
    LABEL_GEAR_MASTERY = "Maestria",
    LABEL_GEAR_VERS = "Versatilidade",
    TEXT_GEAR_ILVL_COLORED_FMT = "Nível do item |c%s%d|r",
    STATUS_LIVE = "[AO VIVO]",
    STATUS_CACHED = "[EM CACHE]",
    STATUS_STALE = "[DESATUALIZADO]",
    TAB_OVERVIEW = "Visão geral",
    DIALOG_DELETE_CHAR = "Excluir %s do LiteVault?",
    LABEL_MYTHIC_PLUS = "M+",

    -- ==========================================================================
    -- MAIN WINDOW
    -- ==========================================================================
    TITLE_LITEVAULT = "LiteVault",
    TITLE_MAP_FILTERS = "Filtros do mapa",

    BUTTON_RAID_LOCKOUTS = "Bloqueios de raide",
    BUTTON_WORLD_EVENTS = "Eventos mundiais",

    TOOLTIP_RAID_LOCKOUTS_TITLE = "Bloqueios de raide",
    TOOLTIP_RAID_LOCKOUTS_DESC = "Ver chefes derrotados de todos os personagens",
    TOOLTIP_THEME_TITLE = "Alternar tema",
    TOOLTIP_THEME_DESC = "Alternar entre modo escuro e claro",
    TOOLTIP_FILTER_TITLE = "Filtro do mapa",
    TOOLTIP_FILTER_DESC = "Clique para ver lista completa",
    TOOLTIP_WORLD_EVENTS_TITLE = "Eventos mundiais",
    TOOLTIP_WORLD_EVENTS_DESC = "Ver eventos mundiais",

    -- Sort controls
    LABEL_SORT_BY = "Ordenar:",
    SORT_GOLD = "Ouro",
    SORT_ILVL = "iLvl",
    SORT_MPLUS = "M+",
    SORT_LAST_ACTIVE = "Atividade",

    -- ==========================================================================
    -- TRACKING DISPLAYS
    -- ==========================================================================
    LABEL_WEEKLY_QUESTS = "Missões semanais de %s",
    LABEL_WEEKLY_COMPLETION_SUMMARY = "%d / %d concluídas",
    BUTTON_WEEKLIES = "Semanais",
    BUTTON_EVENTS = "Eventos",
    BUTTON_FACTIONS = "Facções",
    BUTTON_AMANI_TRIBE = "Tribo Amani",
    BUTTON_HARATI = "Hara'ti",
    BUTTON_SINGULARITY = "A Singularidade",
    BUTTON_SILVERMOON_COURT = "Corte de Luaprata",
    TITLE_FACTION_WEEKLIES = "Semanais de facção de %s",
    WARNING_EVENT_QUESTS = "Alguns desses eventos estão bugados ou bloqueados no jogo.",

    WARNING_WEEKLY_HARATI_CHOICE = "Aviso! Depois de escolher uma missão de Lendas dos Haranir, ela fica bloqueada para sua conta.",
    WARNING_WEEKLY_RUNESTONES = "Aviso! Escolha a missão das Pedras Rúnicas com cuidado. Depois de escolher uma na semana, essa escolha vale para toda a conta.",
    LABEL_WEEKLY_PROFIT = "Lucro semanal:",
    LABEL_WARBAND_PROFIT = "Lucro da banda:",
    LABEL_WARBAND_BANK = "Banco da banda:",
    LABEL_TOP_EARNERS = "Maiores ganhos (Semanal):",
    LABEL_TOTAL_GOLD = "Ouro total: %s",
    LABEL_TOTAL_TIME = "Tempo total: %s",
    LABEL_COMBINED_TIME = "Tempo combinado: %dd %dh",

    TOOLTIP_TOTAL_TIME_TITLE = "Tempo total",
    TOOLTIP_TOTAL_TIME_DESC = "Tempo de jogo total de todos os personagens rastreados.",
    TOOLTIP_TOTAL_TIME_CLICK = "Clique para mudar formato.",

    -- Quest status
    STATUS_DONE = "[Concluído]",
    STATUS_IN_PROGRESS = "[Em andamento]",
    STATUS_NOT_STARTED = "[Não iniciado]",

    -- ==========================================================================
    -- CHARACTER LIST
    -- ==========================================================================
    TOOLTIP_MANAGE_TITLE = "Gerenciar personagens",
    TOOLTIP_MANAGE_BACK = "Voltar à aba principal.",
    TOOLTIP_MANAGE_VIEW = "Ver personagens ignorados.",

    TOOLTIP_CATALYST_TITLE = "Cargas de catalisador",
    TOOLTIP_SPARKS_TITLE = "Faíscas de criação",
    TOOLTIP_VOIDSHARDS_TITLE = "Fragmentos do Caos Ascendentes",
    TOOLTIP_VOIDCORES_TITLE = "Núcleos do Caos Ascendentes",

    TOOLTIP_VAULT_TITLE = "Grande Câmara",
    TOOLTIP_VAULT_DESC = "Pressione para abrir a Grande Câmara",
    TOOLTIP_VAULT_ACTIVE_ONLY = "Abrir a Grande Câmara.",
    TOOLTIP_VAULT_ALT_ONLY = "A Grande Câmara só pode ser aberta para o personagem ativo.",

    TOOLTIP_CURRENCY_TITLE = "Moedas do personagem",
    TOOLTIP_CURRENCY_DESC = "Clique para ver lista completa.",

    TOOLTIP_BAGS_TITLE = "Ver bolsas",
    TOOLTIP_BAGS_DESC = "Ver o conteúdo salvo das bolsas e bolsa de reagentes.",

    TOOLTIP_LEDGER_DESC = "Rastrear receitas e despesas de ouro por fonte.",

    TOOLTIP_WARBAND_BANK_TITLE = "Livro do banco da banda",
    TOOLTIP_WARBAND_BANK_DESC = "Clique para ver transações.",

    TOOLTIP_RESTORE_TITLE = "Restaurar",
    TOOLTIP_RESTORE_DESC = "Restaurar este personagem à página principal",

    TOOLTIP_IGNORE_TITLE = "Ignorar",
    TOOLTIP_IGNORE_DESC = "Remover este personagem da página principal",

    TOOLTIP_DELETE_TITLE = "Excluir",
    TOOLTIP_DELETE_DESC = "Excluir permanentemente os dados deste personagem",
    TOOLTIP_DELETE_WARNING = "Aviso: Esta ação não pode ser desfeita!",

    TOOLTIP_FAVORITE_TITLE = "Favorito",
    TOOLTIP_FAVORITE_DESC = "Fixar este personagem no topo da lista",

    -- Character data displays
    LABEL_ILVL = "iLvl: %d",
    LABEL_MPLUS_SCORE = "Pontuação M+: %d",
    LABEL_NO_KEY = "Sem chave M+",
    LABEL_NO_PROFESSIONS = "Sem profissões",
    LABEL_UNKNOWN = "Desconhecido",
    LABEL_SKILL_LEVEL = "Habilidade: %d/%d",
    LABEL_CONCENTRATION = "Concentração: %d/%d",
    LABEL_CONC_DAILY_RESET = "Diário: %dh %dm",
    LABEL_CONC_WEEKLY_RESET = "Reset completo: %dd %dh",
    LABEL_CONC_FULL = "(Cheio)",
    LABEL_KNOWLEDGE_AVAILABLE = "%d Conhecimento disponível",
    LABEL_NO_KNOWLEDGE = "Sem conhecimento disponível",
    LABEL_VAULT_PROGRESS = "R: %d/3    M+: %d/3    M: %d/3",
    BUTTON_PROFS = "Ofícios",

    TOOLTIP_PROFS_TITLE = "Profissões",
    TOOLTIP_PROFS_DESC = "Ver concentração e conhecimento",
    TITLE_PROFESSIONS = "Profissões de %s",
    TITLE_KNOWLEDGE_SOURCES = "Fontes de Conhecimento",
    TAB_TREASURES = "Tesouros",
    LABEL_UNIQUE_TREASURES = "Tesouros únicos",
    LABEL_WEEKLY_TREASURES = "Tesouros semanais",
    LABEL_HOVER_TREASURE_CHECKLIST = "Passe o mouse para ver a lista de tesouros",
    TITLE_PROF_TREASURES_FMT = "Tesouros de %s",
    LABEL_PROFESSION = "Profissão",
    LABEL_UNIQUE_TREASURE_FMT = "Tesouro único de %s %d",
    LABEL_WEEKLY_TREASURE_FMT = "Tesouro semanal de %s %d",

    -- ==========================================================================
    -- CALENDAR
    -- ==========================================================================
    DAY_SUN = "Dom",
    DAY_MON = "Seg",
    DAY_TUE = "Ter",
    DAY_WED = "Qua",
    DAY_THU = "Qui",
    DAY_FRI = "Sex",
    DAY_SAT = "Sáb",

    TOOLTIP_ACTIVITY_FOR = "Atividade para %d/%d/%d",
    MSG_NO_WORLD_EVENTS = "Sem eventos mundiais neste mês",

    -- Filter categories
    FILTER_TIMEWALKING = "Caminhada Temporal",
    FILTER_DARKMOON = "Lua Negra",
    FILTER_DUNGEONS = "Masmorras",
    FILTER_PVP = "JxJ",
    FILTER_BONUS = "Bônus",

    -- World events
    WORLD_EVENT_LOVE = "O Amor Está no Ar",
    WORLD_EVENT_LUNAR = "Festival da Lua",
    WORLD_EVENT_NOBLEGARDEN = "Jardinova",
    WORLD_EVENT_CHILDREN = "Semana das Crianças",
    WORLD_EVENT_MIDSUMMER = "Festival do Fogo do Solstício",
    WORLD_EVENT_BREWFEST = "CervaFest",
    WORLD_EVENT_HALLOWS = "Noturnália",
    WORLD_EVENT_WINTERVEIL = "Festa do Véu de Inverno",
    WORLD_EVENT_DEAD = "Dia dos Mortos",
    WORLD_EVENT_PIRATES = "Dia dos Piratas",
    WORLD_EVENT_STYLE = "Prova de Estilo",
    WORLD_EVENT_OUTLAND = "Copa de Terralém",
    WORLD_EVENT_NORTHREND = "Copa de Nortúndria",
    WORLD_EVENT_KALIMDOR = "Copa de Kalimdor",
    WORLD_EVENT_EASTERN = "Copa dos Reinos do Leste",
    WORLD_EVENT_WINDS = "Ventos da Fortuna Misteriosa",

    -- ==========================================================================
    -- CURRENCY WINDOW
    -- ==========================================================================
    TITLE_CURRENCIES = "Moedas de %s",

    -- ==========================================================================
    -- RAID LOCKOUTS WINDOW
    -- ==========================================================================
    TITLE_RAID_FORMAT = "%s %s %s - Forja de Mana Ômega",

    DIFFICULTY_NORMAL = "Normal",
    DIFFICULTY_HEROIC = "Heroico",
    DIFFICULTY_MYTHIC = "Mítico",

    MSG_NO_CHAR_DATA = "Nenhum dado de personagem encontrado",
    MSG_NO_PROGRESSION = "Nenhuma progressão %s registrada",
    MSG_NO_LOCKOUT = "Sem bloqueio %s esta semana",

    LABEL_BOSS = "Chefe %d",
    LABEL_PROGRESS_COUNT = "%d/8",

    -- ==========================================================================
    -- WARBAND BANK LEDGER
    -- ==========================================================================
    TITLE_WARBAND_LEDGER = "Livro do banco da banda",
    LABEL_CURRENT_BALANCE = "Saldo atual:",
    LABEL_RECENT_TRANSACTIONS = "Transações recentes:",
    MSG_NO_TRANSACTIONS = "(Nenhuma transação registrada ainda)",
    TIP_RELOAD_SAVE = "Dica: /reload antes de trocar de personagem para salvar",
    ACTION_DEPOSITED = "depositou",
    ACTION_WITHDREW = "sacou",

    -- ==========================================================================
    -- CHARACTER LEDGER
    -- ==========================================================================
    LABEL_RESETS_IN = "Reinicia em %dd %dh",

    TAB_SUMMARY = "Resumo",
    TAB_HISTORY = "Histórico",
    TAB_WARBAND = "Warband",
    HEADER_SOURCE = "Fonte",
    HEADER_INCOME = "Receita",
    HEADER_EXPENSE = "Despesa",

    LABEL_TOTAL = "Total",
    LABEL_NET_PROFIT = "Lucro líquido",
    MSG_NO_GOLD_ACTIVITY = "Sem atividade de ouro esta semana",
    MSG_NO_TRANSACTIONS_WEEK = "Sem transações esta semana",

    -- Ledger source categories
    LEDGER_QUESTS = "Missões",
    LEDGER_AUCTION = "Casa de Leilões",
    LEDGER_TRADE = "Comércio",
    LEDGER_VENDOR = "Vendedor",
    LEDGER_REPAIRS = "Reparos",
    LEDGER_TRANSMOG = "Transmogrificação",
    LEDGER_FLIGHT = "Rotas de voo",
    LEDGER_CRAFTING = "Criação",
    LEDGER_CACHE = "Baú/Tesouro",
    LEDGER_MAIL = "Correio",
    LEDGER_LOOT = "Saque",
    LEDGER_WARBAND_BANK = "Banco da banda",
    LEDGER_OTHER = "Outro",

    -- ==========================================================================
    -- FRESHNESS INDICATORS
    -- ==========================================================================
    FRESH_NEVER = "Nunca",
    FRESH_TODAY = "Ativo hoje",
    FRESH_1_DAY = "Há 1 dia",
    FRESH_DAYS = "Há %d dias",

    -- Time format styles
    TIME_YEARS_DAYS = "%da %dd",
    TIME_DAYS_HOURS = "%dd %dh",
    TIME_DAYS = "%s Dias",
    TIME_HOURS = "%s Horas",

    -- ==========================================================================
    -- TRACKING PROMPT
    -- ==========================================================================
    PROMPT_GREETINGS = "Saudações %s,\nvocê gostaria que o LiteVault rastreie este personagem?",

    -- ==========================================================================
    -- CHAT MESSAGES
    -- ==========================================================================
    MSG_PREFIX = "LiteVault:",
    MSG_WEEKLY_RESET = "Reinício semanal detectado! Bloqueios de raide apagados.",
    MSG_ALREADY_TRACKED = "Este personagem já está sendo rastreado.",
    MSG_CHAR_ADDED = "%s foi adicionado ao rastreamento.",
    MSG_RAID_RESET_SEASON = "A progressão de raide foi reiniciada para Midnight Temporada 1!",
    MSG_CLEARED_PROGRESSION = "Dados de progressão apagados para %d personagens.",
    MSG_WEEKLY_PROFIT_RESET = "Rastreamento de lucro semanal reiniciado para %d personagens.",
    MSG_WARBAND_BALANCE = "Banda: %s",
    MSG_WARBAND_BANK_BALANCE = "Banco da banda: %s",
    MSG_WEEKLY_DATA_RESET = "Dados semanais reiniciados para %d personagens.",
    MSG_RAID_MANUAL_RESET = "Progressão de raide reiniciada manualmente!",
    MSG_CLEARED_DATA = "Dados apagados para %d personagens.",
    MSG_TIMEPLAYED_INITIAL_UNSUPPRESSABLE = "A mensagem inicial de tempo jogado da Blizzard não pode ser suprimida.",

    -- Slash command help
    HELP_RESET_TITLE = "Comandos de reinício do LiteVault",
    HELP_REGION = "Região: %s (reinício %s)",
    HELP_LAST_SEASON = "Último reinício de temporada: %s",
    HELP_RESET_WEEKLY = "/lvreset weekly - Reiniciar rastreamento de lucro semanal",
    HELP_RESET_SEASON = "/lvreset season - Reiniciar progressão de raide (novo nível)",
    HELP_NEVER = "Nunca",

    -- ==========================================================================
    -- LANGUAGE SELECTION
    -- ==========================================================================
    BUTTON_LANGUAGE = "Idioma",
    TOOLTIP_LANGUAGE_TITLE = "Idioma",
    TOOLTIP_LANGUAGE_DESC = "Alterar o idioma da interface",
    TITLE_LANGUAGE_SELECT = "Selecionar idioma",
    LANG_AUTO = "Auto (detectar)",
    MSG_LANGUAGE_CHANGED = "Idioma alterado. Recarregue a interface para aplicar todas as alterações.",

    -- ==========================================================================
    -- OPTIONS
    -- ==========================================================================
    BUTTON_OPTIONS = "Opções",
    TOOLTIP_OPTIONS_TITLE = "Opções",
    TOOLTIP_OPTIONS_DESC = "Configurar as opções do LiteVault",
    TITLE_OPTIONS = "Opções do LiteVault",
    OPTION_DISABLE_TIMEPLAYED = "Desativar rastreamento de tempo jogado",
    OPTION_DISABLE_TIMEPLAYED_DESC = "Impede que mensagens /played apareçam no chat",
    OPTION_DISABLE_BAG_VIEWING = "Desativar visualizador de bolsas/banco",
    OPTION_DISABLE_BAG_VIEWING_DESC = "Oculta o botão de Bolsas e desativa a visualização de bolsas, banco e banco da banda de guerra salvos.",
    OPTION_DISABLE_CHARACTER_OVERLAY = "Desativar sistema de sobreposição",
    OPTION_DISABLE_CHARACTER_OVERLAY_DESC = "Oculta as sobreposições de nível de item e bloqueio do LiteVault no equipamento do personagem e de inspeção.",
    OPTION_DISABLE_MPLUS_TELEPORTS = "Desativar teletransportes M+",
    OPTION_DISABLE_MPLUS_TELEPORTS_DESC = "Oculta o emblema de teletransporte M+ e desativa o painel de teletransporte do LiteVault.",

    -- Month names
    MONTH_1 = "Janeiro",
    MONTH_2 = "Fevereiro",
    MONTH_3 = "Março",
    MONTH_4 = "Abril",
    MONTH_5 = "Maio",
    MONTH_6 = "Junho",
    MONTH_7 = "Julho",
    MONTH_8 = "Agosto",
    MONTH_9 = "Setembro",
    MONTH_10 = "Outubro",
    MONTH_11 = "Novembro",
    MONTH_12 = "Dezembro",

    -- ==========================================================================
    -- CURRENCIES
    -- ==========================================================================
    ["Dawnlight Manaflux"] = "Fluxo de Mana do Alvorecer",

    -- ==========================================================================
    -- WEEKLY QUESTS (Midnight)
    -- ==========================================================================
    ["Community Engagement"] = "Community Engagement",
    WARNING_ACCOUNT_BOUND = "Vinculado à conta",
    ["Midnight: Prey"] = "Midnight: Prey",
    ["Saltheril's Soiree"] = "Sarau de Saltheril",
    ["Legends of the Haranir"] = "Lendas dos Haranir",
    ["Escuridão Desfeita"] = "Escuridão Desfeita",
    ["Colhendo o Vácuo"] = "Colhendo o Vácuo",
    ["Midnight: Saltheril's Soiree"] = "Meia-noite: sarau de Saltheril",
    ["Fortificar as pedras rúnicas: Cavaleiros Sangrentos"] = "Fortificar as pedras rúnicas: Cavaleiros Sangrentos",
    ["Fortificar as pedras rúnicas: Sombras da Rua"] = "Fortificar as pedras rúnicas: Sombras da Rua",
    ["Fortificar as pedras rúnicas: Magísteres"] = "Fortificar as pedras rúnicas: Magísteres",
    ["Fortificar as pedras rúnicas: Andarilhos"] = "Fortificar as pedras rúnicas: Andarilhos",
    ["Dê mais impulso ao passo deles"] = "Dê mais impulso ao passo deles",
    ["Light Snacks"] = "Lanches leves",
    ["Less Lawless"] = "Menos desordem",
    ["The Subtle Game"] = "O jogo sutil",
    ["Courting Success"] = "Conquistando o sucesso",

    -- ==========================================================================
    -- PROFESSION NAMES
    -- ==========================================================================
    ["Alchemy"] = "Alquimia",
    ["Blacksmithing"] = "Ferraria",
    ["Enchanting"] = "Encantamento",
    ["Engineering"] = "Engenharia",
    ["Inscription"] = "Escrivania",
    ["Jewelcrafting"] = "Joalheria",
    ["Leatherworking"] = "Couraria",
    ["Tailoring"] = "Alfaiataria",
    ["Herbalism"] = "Herborismo",
    ["Mineração"] = "Mineração",
    ["Skinning"] = "Esfolamento",

    ["Remanescente da Angústia"] = "Remanescente da Angústia",
    ["Estilhaço de Dundun"] = "Estilhaço de Dundun",
    ["Brasão da Aurora de aventureiro"] = "Brasão da Aurora de aventureiro",
    ["Brasão da Aurora de veterano"] = "Brasão da Aurora de veterano",
    ["Brasão da Aurora de campeão"] = "Brasão da Aurora de campeão",
    ["Brasão da Aurora de herói"] = "Brasão da Aurora de herói",
    ["Brasão da Aurora mítico"] = "Brasão da Aurora mítico",
    ["Brimming Arcana"] = "Arcana transbordante",
    ["Voidlight Marl"] = "Marga da Luz do Vazio",
    ["Undercoin"] = "Submoeda",
    ["Throw the Dice"] = "Jogue os dados",
    ["We Need a Refill"] = "Precisamos reabastecer",
    ["Plumagem adorável"] = "Plumagem adorável",
    ["O caldeirão dos ecos"] = "O caldeirão dos ecos",
    ["The Echoless Flame"] = "A chama sem eco",
    ["Hidey-Hole"] = "Esconderijo",
    ["Reserva do Pináculo de Stormarion Vitoriosa"] = "Reserva do Pináculo de Stormarion Vitoriosa",
    ["Pacote de suprimentos do aprendiz ávido"] = "Pacote de suprimentos do aprendiz ávido",
    ["Surplus Bag of Party Favors"] = "Bolsa excedente de lembrancinhas de festa",
    OPTION_ENABLE_24HR_CLOCK = "Ativar relógio de 24 horas",
    OPTION_ENABLE_24HR_CLOCK_DESC = "Alternar entre os formatos de 24h e 12h",
    TELEPORT_PANEL_TITLE = "Teletransportes M+",
    TELEPORT_CAST_BTN = "Teleporte",
    TELEPORT_ERR_COMBAT = "Não é possível se teletransportar em combate.",
    BUTTON_VAULT = "Cofre",
    BUTTON_ACTIONS = "Ações",
    BUTTON_RAIDS = "Raides",
    BUTTON_FAVORITE = "Favorito",
    BUTTON_UNFAVORITE = "Remover favorito",
    BUTTON_IGNORE = "Ignorar",
    BUTTON_RESTORE = "Restaurar",
    BUTTON_DELETE = "Excluir",
    TOOLTIP_ACTIONS_TITLE = "Ações do personagem",
    TOOLTIP_ACTIONS_DESC = "Abrir menu de ações",
    BUTTON_INSTANCES = "Instâncias",
    TOOLTIP_INSTANCE_TRACKER_TITLE = "Rastreador de instâncias",
    TOOLTIP_INSTANCE_TRACKER_DESC = "Acompanhar masmorras e raides",
    LABEL_RENOWN_PROGRESS = "Renome %d (%d/%d)",

    LABEL_RENOWN = "Renome",
    LABEL_RENOWN_LEVEL = "Nível",
    LABEL_RENOWN_UNAVAILABLE = "Renome indisponível",
    MSG_NO_WEEKLY_QUESTS_CONFIGURED = "Nenhuma missão de facção configurada ainda.",
    BUTTON_KNOWLEDGE = "Conhecimento",
    WORLD_EVENT_SALTHERIL = "Sarau de Saltheril",
    WORLD_EVENT_ABUNDANCE = "Abundância",
    WORLD_EVENT_HARANIR = "Lendas dos Haranir",
    WORLD_EVENT_STORMARION = "Assalto de Stormarion",
    TITLE_KNOWLEDGE_TRACKER = "Rastreador de conhecimento",
    TOOLTIP_KNOWLEDGE_DESC = "Ver conhecimento gasto, não gasto e máximo",
    LABEL_SPENT = "Gasto",
    LABEL_UNSPENT = "Não gasto",
    LABEL_MAX = "Máximo",
    LABEL_EARNED = "Obtido",
    LABEL_TREATISE = "Tratado",
    LABEL_ARTISAN_QUEST = "Artífice",
    LABEL_CATCHUP = "Atualização",
    LABEL_WEEKLY = "Semanal",
    LABEL_UNLOCKED = "Desbloqueado",
    LABEL_UNLOCK_REQUIREMENTS = "Requisitos de desbloqueio",
    LABEL_SOURCE_NOTE = "Fontes semanais e panorama de recuperação",
    LABEL_TREASURE_CLICK_HINT = "Clique em um tesouro único para definir um ponto de rota",
    LABEL_ZONE = "Zona",
    LABEL_QUEST = "Missão",
    LABEL_COORDINATES = "Coordenadas",
    TOOLTIP_TREASURE_SET_WAYPOINT = "Clique para colocar um ponto de rota do TomTom",
    TOOLTIP_TREASURE_SET_BLIZZ_WAYPOINT = "Clique para colocar um ponto de rota no mapa",
    TOOLTIP_TREASURE_NO_FIXED_LOCATION = "Este tesouro não tem localização fixa",
    MSG_TREASURE_NO_WAYPOINT = "Este tesouro não tem um ponto de rota fixo.",
    MSG_TOMTOM_NOT_DETECTED = "TomTom não detectado.",
    MSG_TREASURE_WAYPOINT_SET = "Ponto de rota definido: %s (%.1f, %.1f)",
    MSG_TREASURE_BLIZZ_WAYPOINT_SET = "Ponto no mapa definido: %s (%.1f, %.1f)",
    STATUS_DONE_WORD = "Concluído",
    STATUS_MISSING_WORD = "Faltando",
    LABEL_MIDNIGHT_SEASON_1 = "Temporada 1 de Midnight",
    TAB_SOURCES = "Fontes",
    TIME_TODAY = "Hoje %H:%M",
    MSG_CAP_WARNING = "Aviso de limite de instância! %d/10 instâncias nesta hora.",
    MSG_CAP_SLOT_OPEN = "Um espaço de instância está livre agora! (%d/10 usadas)",
    MSG_RELOAD_TIMEPLAYED = "Recarregue a interface para aplicar a supressão do tempo jogado.",
    MSG_RAID_DEBUG_ON = "Depuração de raide do LiteVault: LIGADA",
    MSG_RAID_DEBUG_OFF = "Depuração de raide do LiteVault: DESLIGADA",
    MSG_RAID_DEBUG_TIP = "Use /lvraiddbg novamente para desligar a saída de depuração",
    MSG_TRACKED_KILL = "Abate rastreado de %s: %s (%s)",
    LOCALE_DEBUG_ON = "Modo de depuração de idioma LIGADO - exibindo chaves de texto",
    LOCALE_DEBUG_OFF = "Modo de depuração de idioma DESLIGADO - exibindo traduções",
    LOCALE_BORDERS_ON = "Modo de bordas LIGADO - exibindo limites do texto",
    LOCALE_BORDERS_HINT = "Verde = cabe, Vermelho = pode ultrapassar",
    LOCALE_BORDERS_OFF = "Modo de bordas DESLIGADO",
    LOCALE_FORCED = "Idioma forçado para %s",
    LOCALE_RESET_TIP = "Use /lvlocale reset para voltar à detecção automática",
    LOCALE_INVALID = "Idioma inválido. Opções válidas:",
    LOCALE_RESET = "Idioma redefinido para detecção automática: %s",
    LOCALE_TITLE = "Localização do LiteVault",
    LOCALE_DETECTED = "Idioma detectado: %s",
    LOCALE_FORCED_TO = "Idioma forçado: %s",
    LOCALE_DEBUG_KEYS = "Chaves de depuração:",
    LOCALE_DEBUG_BORDERS = "Bordas de depuração:",
    LOCALE_ON = "LIGADO",
    LOCALE_OFF = "DESLIGADO",
    LOCALE_COMMANDS = "Comandos:",
    LOCALE_CMD_DEBUG = "/lvlocale debug - Alternar modo de exibição de chaves",
    LOCALE_CMD_BORDERS = "/lvlocale borders - Alternar visualização das bordas do texto",
    LOCALE_CMD_LANG = "/lvlocale lang XX - Forçar idioma (ex.: deDE, zhCN)",
    LOCALE_CMD_RESET = "/lvlocale reset - Voltar para detecção automática",
    TITLE_INSTANCE_TRACKER = "Rastreador de instâncias",
    SECTION_INSTANCE_CAP = "Limite de instâncias (10/hora)",
    LABEL_CAP_CURRENT = "Atual: %d/10",
    LABEL_CAP_STATUS = "Status: %s",
    LABEL_NEXT_SLOT = "Próximo espaço em: %s",
    STATUS_SAFE = "SEGURO",
    STATUS_WARNING = "AVISO",
    STATUS_LOCKED = "BLOQUEADO",
    SECTION_CURRENT_RUN = "Corrida atual",
    LABEL_DURATION = "Duração: %s",
    LABEL_NOT_IN_INSTANCE = "Não está em uma instância",
    SECTION_PERFORMANCE = "Desempenho de hoje",
    LABEL_DUNGEONS_TODAY = "Masmorras: %d",
    LABEL_RAIDS_TODAY = "Raides: %d",
    LABEL_AVG_TIME = "Média: %s",
    SECTION_LEGACY_RAIDS = "Raides legadas nesta semana",
    LABEL_LEGACY_RUNS = "Corridas: %d",
    LABEL_GOLD_EARNED = "Ouro: %s",
    SECTION_RECENT_RUNS = "Corridas recentes",
    LABEL_NO_RECENT_RUNS = "Nenhuma corrida recente",
    SECTION_MPLUS = "Mítica+",
    LABEL_MPLUS_CURRENT_KEY = "Chave atual:",
    LABEL_RUNS_TODAY = "Corridas hoje: %d",
    LABEL_RUNS_THIS_WEEK = "Corridas nesta semana: %d",
    SECTION_RECENT_MPLUS_RUNS = "Corridas M+ recentes",
    LABEL_NO_RECENT_MPLUS_RUNS = "Nenhuma corrida M+ recente",
    BUTTON_DASHBOARD = "Painel",
    BUTTON_PROFIT = "Lucro",
    LABEL_PROFIT_GOALS = "Metas do Bando de Guerra",
    LABEL_WEEKLY_GOAL = "Meta semanal",
    LABEL_MONTHLY_GOAL = "Meta mensal",
    BUTTON_EDIT = "Editar",
    TEXT_TOP_WEEKLY_EARNERS_SUBTITLE = "Maior lucro líquido desta redefinição.",
    TEXT_TOP_MONTHLY_EARNERS_SUBTITLE = "Melhor lucro líquido do mês atual.",
    BUTTON_ACHIEVEMENTS = "Conquistas",
    TITLE_ACHIEVEMENTS = "Conquistas",
    DESC_ACHIEVEMENTS = "Escolha um rastreador de conquistas para ver o progresso detalhado.",
    BUTTON_MIDNIGHT_GLYPH_HUNTER = "Caçador de Glifos da Meia-noite",
    TITLE_MIDNIGHT_GLYPH_HUNTER = "Caçador de Glifos da Meia-noite",
    LABEL_REWARD = "Recompensa",
    DESC_GLYPH_REWARD = "Complete Caçador de Glifos da Meia-noite para ganhar esta montaria.",
    MSG_NO_ACHIEVEMENT_DATA = "Nenhum dado de rastreamento de conquistas disponível.",
    LABEL_CRITERIA = "Critérios",
    LABEL_GLYPHS_COLLECTED = "Glifos Coletados",
    LABEL_ACHIEVEMENT = "Conquista",
    BUTTON_BAGS = "Bolsas",
    BUTTON_BANK = "Banco",
    BUTTON_WARBAND_BANK = "Banco da Banda de Guerra",
    BAGS_EMPTY_STATE = "Nenhum item de bolsa salvo para este personagem ainda.",
    BANK_EMPTY_STATE = "Nenhum item de banco salvo para este personagem ainda.",
    WARBANK_EMPTY_STATE = "Nenhum item do banco da banda de guerra salvo ainda.",
    LABEL_BAG_SLOTS = "Espaços: %d / %d usados",
    LABEL_SCANNED = "verificado",
    ["Coffer Key Shards"] = "Fragmentos de Chave de Cofre",
    BUTTON_WEEKLY_PLANNER = "Planejador",
    TITLE_WEEKLY_PLANNER = "Planejador semanal",
    TITLE_CHARACTER_WEEKLY_PLANNER_FMT = "%s's %s",
    TOOLTIP_WEEKLY_PLANNER_TITLE = "Planejador semanal",
    TOOLTIP_WEEKLY_PLANNER_DESC = "Lista semanal editável por personagem. Itens concluídos são reiniciados toda semana.",
    TOOLTIP_VAULT_STATUS = "Verificar status do cofre.",
    TITLE_GREAT_VAULT = "O Grande Cofre",
    TITLE_CHARACTER_GREAT_VAULT_FMT = "%s's %s",
    LABEL_VAULT_ROW_RAID = "Raide",
    LABEL_VAULT_ROW_DUNGEONS = "Masmorras",
    LABEL_VAULT_ROW_WORLD = "Mundo",
    LABEL_VAULT_SLOTS_UNLOCKED = "%d/9 espaços desbloqueados",
    LABEL_VAULT_OVERALL_PROGRESS = "Overall progress: %d/%d",
    MSG_VAULT_NO_THRESHOLD = "Ainda não há dados de limite salvos.",
    MSG_VAULT_LIVE_ACTIVE = "Progresso ao vivo do Grande Cofre para o personagem ativo.",
    MSG_VAULT_LIVE = "Progresso ao vivo do Grande Cofre.",
    MSG_VAULT_SAVED = "Instantâneo salvo do Grande Cofre do último login deste personagem.",
    SECTION_DELVE_CURRENCY = "Moeda de Imersão",
    SECTION_UPGRADE_CRESTS = "Brasões de aprimoramento",
    LABEL_CAP_SHORT = "limite %s",
    ["Glória do Escavador de Midnight"] = "Glória do Escavador de Midnight",
    ["Complete \"Glória do Escavador de Midnight\" para obter esta montaria."] = "Complete \"Glória do Escavador de Midnight\" para obter esta montaria.",
    ["Complete os cinco telescópios nesta zona."] = "Complete os cinco telescópios nesta zona.",
    ["Crimson Dragonhawk"] = "Falcodrago Carmesim",
    ["Giganto-Manis"] = "Giganto-Manis",
    ["Reward"] = "Recompensa",
    ["Critérios"] = "Critérios",
    ["Informações"] = "Informações",
    ["Unknown"] = "Desconhecido",
    ["Item"] = "Item",
    ["Click to set waypoint."] = "Clique para definir um waypoint.",
    ["Rastreador ainda não adicionado."] = "Rastreador ainda não adicionado.",
    ["Conclua a caverna aqui para receber crédito."] = "Conclua a caverna aqui para receber crédito.",
    ["Carregue a pedra rúnica com Arcana Latente para iniciar seu evento de defesa."] = "Carregue a pedra rúnica com Arcana Latente para iniciar seu evento de defesa.",
    ["Crédito de conquista obtido por:"] = "Crédito de conquista obtido por:",
    ["Ever-Painting"] = "Pintura Eterna",
    ["As entradas rastreadas de Ever-Painting ainda não foram adicionadas."] = "As entradas rastreadas de Ever-Painting ainda não foram adicionadas.",
    ["Corrida das Pedras Rúnicas"] = "Corrida das Pedras Rúnicas",
    ["As entradas rastreadas de Runestone Rush ainda não foram adicionadas."] = "As entradas rastreadas de Runestone Rush ainda não foram adicionadas.",
    ["Acompanhe os quatro convites de facção de A festa precisa continuar. x/y marcados."] = "Acompanhe os quatro convites de facção de A festa precisa continuar. x/y marcados.",
    ["As entradas rastreadas de A festa precisa continuar ainda não foram adicionadas."] = "As entradas rastreadas de A festa precisa continuar ainda não foram adicionadas.",
    ["Rastreadores de exploração"] = "Rastreadores de exploração",
    ["As entradas rastreadas de Explore Eversong Woods ainda não foram adicionadas."] = "As entradas rastreadas de Explore Eversong Woods ainda não foram adicionadas.",
    ["As entradas rastreadas de Explore Voidstorm ainda não foram adicionadas."] = "As entradas rastreadas de Explore Voidstorm ainda não foram adicionadas.",
    ["As entradas rastreadas de Explore Zul'Aman ainda não foram adicionadas."] = "As entradas rastreadas de Explore Zul'Aman ainda não foram adicionadas.",
    ["As entradas rastreadas de Explore Harandar ainda não foram adicionadas."] = "As entradas rastreadas de Explore Harandar ainda não foram adicionadas.",
    ["A emoção da perseguição"] = "A emoção da perseguição",
    ["Escape das garras da Presença Faminta em Voidstorm por pelo menos 60 segundos."] = "Escape das garras da Presença Faminta em Voidstorm por pelo menos 60 segundos.",
    ["Esta conquista não precisa de rastreamento de coordenadas no LiteVault. Sobreviva ao evento da Presença Faminta em Voidstorm por pelo menos 60 segundos."] = "Esta conquista não precisa de rastreamento de coordenadas no LiteVault. Sobreviva ao evento da Presença Faminta em Voidstorm por pelo menos 60 segundos.",
    ["As entradas rastreadas de A emoção da perseguição ainda não foram adicionadas."] = "As entradas rastreadas de A emoção da perseguição ainda não foram adicionadas.",
    ["Complete a missão mundial de Harandar 'Aplicação das Garras' com 15 ou mais acúmulos de Perseguição do Predador."] = "Complete a missão mundial de Harandar 'Aplicação das Garras' com 15 ou mais acúmulos de Perseguição do Predador.",
    ["Esta conquista não precisa de rastreamento de coordenadas no LiteVault. Complete a missão mundial de Harandar 'Aplicação das Garras' com 15 ou mais acúmulos de Perseguição do Predador."] = "Esta conquista não precisa de rastreamento de coordenadas no LiteVault. Complete a missão mundial de Harandar 'Aplicação das Garras' com 15 ou mais acúmulos de Perseguição do Predador.",
    ["As entradas rastreadas de Sem tempo para patas ainda não foram adicionadas."] = "As entradas rastreadas de Sem tempo para patas ainda não foram adicionadas.",
    ["Do berço ao túmulo"] = "Do berço ao túmulo",
    ["Tente voar até O Berço, bem alto no céu acima de Harandar."] = "Tente voar até O Berço, bem alto no céu acima de Harandar.",
    ["Voe até O Berço, bem alto no céu acima de Harandar, para completar esta conquista."] = "Voe até O Berço, bem alto no céu acima de Harandar, para completar esta conquista.",
    ["Esses diários só estão disponíveis durante a missão semanal 'Lendas dos Haranir'. Enquanto estiver em uma visão, procure o ícone de lupa no minimapa."] = "Esses diários só estão disponíveis durante a missão semanal 'Lendas dos Haranir'. Enquanto estiver em uma visão, procure o ícone de lupa no minimapa.",
    ["Recupere as entradas de diário dos Haranir listadas abaixo."] = "Recupere as entradas de diário dos Haranir listadas abaixo.",
    ["Recupere as entradas de diário dos Haranir listadas abaixo. x/y marcados."] = "Recupere as entradas de diário dos Haranir listadas abaixo. x/y marcados.",
    ["Isto está ligado à missão semanal 'Lendas dos Haranir'. Se você ainda não tiver progresso, estima-se que leve cerca de 7 semanas para concluir."] = "Isto está ligado à missão semanal 'Lendas dos Haranir'. Se você ainda não tiver progresso, estima-se que leve cerca de 7 semanas para concluir.",
    ["Os grupos de coordenadas ainda não foram adicionados."] = "Os grupos de coordenadas ainda não foram adicionados.",
    ["Este rastreador está dividido em 3 grupos de 40 coordenadas para manter as rotas das mariposas gerenciáveis."] = "Este rastreador está dividido em 3 grupos de 40 coordenadas para manter as rotas das mariposas gerenciáveis.",
    ["Moths 41-80 appear at Hara'ti Renown 4, tracking at Renown 6."] = "As mariposas 41-80 aparecem com Renome Hara'ti 4, rastreamento no Renome 6.",
    ["Moths 81-120 appear at Hara'ti Renown 9, tracking at Renown 11."] = "As mariposas 81-120 aparecem com Renome Hara'ti 9, rastreamento no Renome 11.",
    ["O roteamento do LiteVault assume que você já desbloqueou o Renome Hara'ti 11."] = "O roteamento do LiteVault assume que você já desbloqueou o Renome Hara'ti 11.",
    ["%s contém %d coordenadas de mariposas. Clique em uma mariposa para colocar um waypoint."] = "%s contém %d coordenadas de mariposas. Clique em uma mariposa para colocar um waypoint.",
    ["Group 1"] = "Grupo 1",
    ["Group 2"] = "Grupo 2",
    ["Group 3"] = "Grupo 3",
    ["Conclua as três ondas do Assalto a Stormarion. x/y marcados."] = "Conclua as três ondas do Assalto a Stormarion. x/y marcados.",
    ["As entradas rastreadas de Um problema singular ainda não foram adicionadas."] = "As entradas rastreadas de Um problema singular ainda não foram adicionadas.",
    ["Abundância: Plenitude próspera!"] = "Abundância: Plenitude próspera!",
    ["Você precisa concluir uma corrida de caverna Colheita Abundante em cada local para receber crédito. Apenas visitar a caverna não é suficiente."] = "Você precisa concluir uma corrida de caverna Colheita Abundante em cada local para receber crédito. Apenas visitar a caverna não é suficiente.",
    ["As entradas rastreadas de Abundância: Plenitude próspera! ainda não foram adicionadas."] = "As entradas rastreadas de Abundância: Plenitude próspera! ainda não foram adicionadas.",
    ["Altar das Bênçãos"] = "Altar das Bênçãos",
    ["Ative cada efeito de bênção listado para receber crédito."] = "Ative cada efeito de bênção listado para receber crédito.",
    ["Ative cada efeito de bênção listado. x/y marcados."] = "Ative cada efeito de bênção listado. x/y marcados.",
    ["Meta achievement summaries"] = "Resumos de meta-conquistas",
    ["Conclua as conquistas de Eversong Woods listadas abaixo. x/y concluídos."] = "Conclua as conquistas de Eversong Woods listadas abaixo. x/y concluídos.",
    ["Conclua todas as conquistas de Voidstorm listadas abaixo. x/y concluídos."] = "Conclua todas as conquistas de Voidstorm listadas abaixo. x/y concluídos.",
    ["Conclua todas as conquistas de Zul'Aman listadas abaixo. x/y concluídos."] = "Conclua todas as conquistas de Zul'Aman listadas abaixo. x/y concluídos.",
    ["Ajude os Hara'ti completando as conquistas abaixo. x/y concluídos."] = "Ajude os Hara'ti completando as conquistas abaixo. x/y concluídos.",
    ["Reúna suas forças contra Xal'atath completando as conquistas abaixo. x/y concluídos."] = "Reúna suas forças contra Xal'atath completando as conquistas abaixo. x/y concluídos.",
    ["As entradas rastreadas de Making an Amani Out of You ainda não foram adicionadas."] = "As entradas rastreadas de Making an Amani Out of You ainda não foram adicionadas.",
    ["As entradas rastreadas de That's Aln, Folks! ainda não foram adicionadas."] = "As entradas rastreadas de That's Aln, Folks! ainda não foram adicionadas.",
    ["As entradas rastreadas de Forever Song ainda não foram adicionadas."] = "As entradas rastreadas de Forever Song ainda não foram adicionadas.",
    ["As entradas rastreadas de Yelling into the Voidstorm ainda não foram adicionadas."] = "As entradas rastreadas de Yelling into the Voidstorm ainda não foram adicionadas.",
    ["As entradas rastreadas de Light Up the Night ainda não foram adicionadas."] = "As entradas rastreadas de Light Up the Night ainda não foram adicionadas.",
    ["Montaria: Asa-pétala brilhante"] = "Montaria: Asa-pétala brilhante",
    ["Decoração de Casa: Chamado de On'ohia"] = "Decoração de Casa: Chamado de On'ohia",
    ["Título: \"Senhor da Poeira\""] = "Título: \"Senhor da Poeira\"",
    ["Título: \"Cronista dos Haranir\""] = "Título: \"Cronista dos Haranir\"",
    ["Rótulos de recompensa da casa:"] = "Rótulos de recompensa da casa:",
}

L["Ressincronização da raide indisponível."] = "Ressincronização da raide indisponível."
L["As mensagens de tempo jogado serão ocultadas."] = "As mensagens de tempo jogado serão ocultadas."
L["Time played messages restored."] = "As mensagens de tempo jogado foram restauradas."
L["%dm %02ds"] = "%d min %02d s"
L["Brasões:"] = "Brasões:"
L["(Não coletada)"] = "(Não coletada)"
L["LABEL_MOUNTS_FMT"] = "Montarias: %d/%d"
L["The Voidspire"] = "A Agulha do Caos"
L["A Fenda Onírica"] = "A Fenda Onírica"
L["March of Quel'Danas"] = "A Marcha de Quel'Danas"
L["Raid Progression"] = "Progresso da raide"
L["Lady Liadrin Weekly"] = "Semanal da Lady Liadrin"
L["Registro de alterações"] = "Registro de alterações"
L["Back"] = "Voltar"
L["Warband Bank"] = "Banco do Bando de Guerra"
L["Treatise"] = "Tratado"
L["Artesão"] = "Artesão"
L["Recuperação"] = "Recuperação"
L["Resumo da atualização do LiteVault"] = "Resumo da atualização do LiteVault"
L["Vários elementos principais da interface foram atualizados, incluindo o ícone de moeda, o ícone de raide, a barra de profissões e o rastreador do Grande Cofre."] = "Vários elementos principais da interface foram atualizados, incluindo o ícone de moeda, o ícone de raide, a barra de profissões e o rastreador do Grande Cofre."
L["A exibição do nível de item do cofre foi atualizada para ficar mais próxima da apresentação padrão do Grande Cofre da Blizzard."] = "A exibição do nível de item do cofre foi atualizada para ficar mais próxima da apresentação padrão do Grande Cofre da Blizzard."
L["Um grande conjunto de novas traduções foi adicionado aos idiomas compatíveis."] = "Um grande conjunto de novas traduções foi adicionado aos idiomas compatíveis."
L["A exibição e a atualização do texto localizado foram melhoradas em todo o addon."] = "A exibição e a atualização do texto localizado foram melhoradas em todo o addon."
L["O suporte de localização para botões, abas de bolsas, texto semanal e outros rótulos da interface foi atualizado."] = "O suporte de localização para botões, abas de bolsas, texto semanal e outros rótulos da interface foi atualizado."
L["Vários problemas de layout relacionados à localização foram corrigidos."] = "Vários problemas de layout relacionados à localização foram corrigidos."
L["Vários problemas de travamento relacionados à localização foram corrigidos."] = "Vários problemas de travamento relacionados à localização foram corrigidos."

L["BUTTON_BREAKDOWN"] = "Detalhamento"
L["BUTTON_WARBAND_PROFIT_BREAKDOWN"] = "Detalhamento do Bando de Guerra"
L["BUTTON_RITUAL_SITES"] = "Locais de ritual"
L["Renome máximo"] = "Renome máximo"
L["LABEL_PARAGON"] = "Paragão"
L["LABEL_REWARD_FMT"] = "Recompensa: %s"
L["LABEL_REWARD_LOADING"] = "Carregando dados da recompensa..."
L["Clique para trocar para esta facção."] = "Clique para trocar para esta facção."
L["LABEL_GAINED"] = "Recebido"
L["LABEL_TOP_SOURCES"] = "Principais fontes"
L["LABEL_TOP_INCOME_SOURCE"] = "Principal fonte de renda"
L["LABEL_TOP_EXPENSE_SOURCE"] = "Principal fonte de gasto"
L["Composição das fontes de renda e gastos semanais do seu Bando de Guerra."] = "Composição das fontes de renda e gastos semanais do seu Bando de Guerra."
L["TEXT_PROFIT_WARBAND_BREAKDOWN_GAINS"] = "Onde seu Bando de Guerra ganhou mais ouro nesta semana."
L["TEXT_PROFIT_WARBAND_BREAKDOWN_SPEND"] = "Onde seu Bando de Guerra gastou mais ouro nesta semana."
L["MSG_PROFIT_NO_INCOME"] = "Nenhuma renda registrada ainda."
L["MSG_PROFIT_NO_SPENDING"] = "Nenhum gasto registrado ainda."
L["Nenhuma Missão Mundial de ouro ativa encontrada."] = "Nenhuma Missão Mundial de ouro ativa encontrada."
L["Missões Mundiais"] = "Missões Mundiais"
L["LEDGER_UPGRADE"] = "Aprimoramento"
L["Desativar marcadores de pedras rúnicas no mapa"] = "Desativar marcadores de pedras rúnicas no mapa"
L["Oculta os marcadores de pedras rúnicas do LiteVault no mapa da Floresta do Canto Eterno."] = "Oculta os marcadores de pedras rúnicas do LiteVault no mapa da Floresta do Canto Eterno."
L["Ativar destaques de lucro no calendário"] = "Ativar destaques de lucro no calendário"
L["Mostra destaques verdes e vermelhos para dias de lucro no calendário."] = "Mostra destaques verdes e vermelhos para dias de lucro no calendário."
L["Próxima semana: %s"] = "Próxima semana: %s"
L["LABEL_MONTHLY_PROFIT"] = "Lucro mensal"
L["LABEL_TOP_WEEKLY_EARNERS"] = "Maiores ganhos semanais"
L["LABEL_TOP_MONTHLY_EARNERS"] = "Maiores ganhos mensais"

L["BUTTON_CANCEL"] = "Cancel"
L["BUTTON_EDIT_MONTHLY_GOAL"] = "Edit Monthly Goal"
L["BUTTON_EDIT_WEEKLY_GOAL"] = "Edit Weekly Goal"
L["BUTTON_EXPORT_CSV"] = "Export CSV"
L["BUTTON_MONTHLY_PROFIT_EXPORT"] = "Monthly Profit CSV"
L["BUTTON_SAVE"] = "Save"
L["BUTTON_SELECT_ALL"] = "Select All"
L["BUTTON_SET"] = "Set"
L["BUTTON_WARBAND_BANK_HISTORY"] = "Warband Bank History"
L["BUTTON_WARBAND_PROFIT_EXPORT"] = "Warband Weekly Profit CSV"
L["BUTTON_WEEKLY_PROFIT_EXPORT"] = "Weekly Profit CSV"
L["LABEL_CHARACTER_TIME"] = "Character / Time"
L["LABEL_CURRENT"] = "Current"
L["LABEL_DEFENSE_FMT"] = "Defense: %s"
L["LABEL_DETAIL"] = "Detail"
L["LABEL_DETAILS"] = "Details"
L["LABEL_GOLD"] = "Gold"
L["LABEL_GOAL_AMOUNT"] = "Goal Amount (gold)"
L["LABEL_HISTORY_COUNT"] = "Quantidade no histórico"
L["LABEL_LAST_UPDATED"] = "Last Updated"
L["LABEL_NET"] = "Net"
L["LABEL_PREVIOUS"] = "Previous"
L["LABEL_RECENT_HISTORY"] = "Recent History"
L["LABEL_RUNESTONE"] = "Runestone"
L["LABEL_SHARE"] = "Share"
L["LABEL_SOURCE"] = "Source"
L["LABEL_STATUS"] = "Status"
L["LABEL_TOKEN_AFFORDABLE"] = "Acessível"
L["LABEL_TOKEN_DELTA"] = "Diferença"
L["LABEL_TOKEN_NOT_AFFORDABLE"] = "Cannot Afford"
L["LABEL_TOKEN_STALE"] = "Stale"
L["LABEL_WARBAND_WEEKLY_PROFIT"] = "Warband Weekly Profit"
L["LABEL_WOW_TOKEN"] = "WoW Token:"
L["MSG_NIT_TIMEPLAYED_WARNING"] = "NovaInstanceTracker detected. The /played message may be suppressed by NIT even when LiteVault's option is disabled."
L["MSG_PROFIT_GOAL_INVALID"] = "Enter a valid gold amount."
L["MSG_PROFIT_GOAL_NOT_SET"] = "No goal set"
L["MSG_RAID_RESYNC_COMPLETE"] = "Raid resync complete."
L["MSG_RAID_RESYNC_STARTED"] = "Raid resync started..."
L["MSG_RAID_RESYNC_UNAVAILABLE"] = "Raid resync unavailable."
L["MSG_TIMEPLAYED_RESTORED"] = "Time played messages restored."
L["MSG_TIMEPLAYED_SUPPRESSED"] = "Time played messages will be suppressed."
L["MSG_WOW_TOKEN_API_UNAVAILABLE"] = "WoW Token API is unavailable in this client."
L["MSG_WOW_TOKEN_DATA_UNAVAILABLE"] = "WoW Token data unavailable."
L["MSG_WOW_TOKEN_VISIT_AH"] = "Visit the Auction House to update WoW Token price."
L["MSG_WOW_TOKEN_VISIT_AH_SHORT"] = "Visit AH"
L["TAB_GLYPHS"] = "Glyphs"
L["TEXT_PROFIT_EXPORT_HINT"] = "Click in the box and press Ctrl+C to copy."
L["TEXT_PROFIT_EXPORT_SUBTITLE"] = "Copy the CSV text below."
L["TEXT_PROFIT_FALLBACK_APPEARANCE_COST"] = "Appearance cost"
L["TEXT_PROFIT_FALLBACK_AUCTION_DEPOSIT"] = "Auction deposit"
L["TEXT_PROFIT_FALLBACK_AUCTION_FEE"] = "Auction fee"
L["TEXT_PROFIT_FALLBACK_AUCTION_PURCHASE"] = "Auction purchase"
L["TEXT_PROFIT_FALLBACK_AUCTION_SALE"] = "Auction sale"
L["TEXT_PROFIT_FALLBACK_BARBER_COST"] = "Barber cost"
L["TEXT_PROFIT_FALLBACK_BLACK_MARKET_PURCHASE"] = "Black Market purchase"
L["TEXT_PROFIT_FALLBACK_CRAFTING_ORDER"] = "Crafting order"
L["TEXT_PROFIT_FALLBACK_GEAR_UPGRADE"] = "Gear upgrade"
L["TEXT_PROFIT_FALLBACK_GOLD_RECEIVED"] = "Gold received"
L["TEXT_PROFIT_FALLBACK_GOLD_REWARD"] = "Gold reward"
L["TEXT_PROFIT_FALLBACK_GOLD_SENT"] = "Gold sent"
L["TEXT_PROFIT_FALLBACK_GUILD_DEPOSIT"] = "Guild deposit"
L["TEXT_PROFIT_FALLBACK_GUILD_WITHDRAWAL"] = "Guild withdrawal"
L["TEXT_PROFIT_FALLBACK_RAW_GOLD"] = "Raw gold"
L["TEXT_PROFIT_FALLBACK_SERVICE_COST"] = "Service cost"
L["TEXT_PROFIT_FALLBACK_TRADE_GAIN"] = "Trade gain"
L["TEXT_PROFIT_FALLBACK_TRADE_PAYMENT"] = "Trade payment"
L["TEXT_PROFIT_FALLBACK_TRAINING_COST"] = "Training cost"
L["TEXT_PROFIT_FALLBACK_TRAVEL_COST"] = "Travel cost"
L["TEXT_PROFIT_FALLBACK_WOW_TOKEN_PURCHASE"] = "Compra de Ficha de WoW"
L["TEXT_PROFIT_ITEM_FALLBACK_FMT"] = "Item %d"
L["TEXT_PROFIT_GOALS_SUBTITLE"] = "Metas semanais e mensais de lucro líquido para o seu Bando de Guerra."
L["TEXT_PROFIT_GOAL_EDITOR_HINT"] = "Insira uma meta em ouro. Deixe em branco ou digite 0 para removê-la."
L["TEXT_PROFIT_GRAPH_EMPTY_MONTHLY"] = "No monthly profit history recorded yet."
L["TEXT_PROFIT_GRAPH_EMPTY_WARBAND"] = "No warband profit history recorded yet."
L["TEXT_PROFIT_GRAPH_EMPTY_WARBAND_MONTHLY"] = "No monthly warband profit history recorded yet."
L["TEXT_PROFIT_GRAPH_EMPTY_WEEKLY"] = "No weekly profit history recorded yet."
L["TEXT_PROFIT_GRAPH_PENDING_MONTHLY"] = "O histórico do gráfico mensal agora está sendo acompanhado e será preenchido conforme você ganhar ou gastar ouro."
L["TEXT_PROFIT_GRAPH_PENDING_WARBAND_MONTHLY"] = "O histórico mensal do Bando de Guerra agora está sendo acompanhado e será preenchido conforme as alterações de ouro forem registradas."
L["TEXT_PROFIT_LEDGER_EMPTY_MONTHLY"] = "No monthly ledger transactions recorded yet."
L["TEXT_PROFIT_LEDGER_EMPTY_WARBAND"] = "No warband ledger transactions recorded yet."
L["TEXT_PROFIT_LEDGER_EMPTY_WEEKLY"] = "No weekly ledger transactions recorded yet."
L["TEXT_PROFIT_MONTHLY_GRAPH_SUBTITLE"] = "Lucro líquido diário do personagem atual neste mês. Novos dados aparecerão conforme as alterações de ouro forem registradas."
L["TEXT_PROFIT_MONTHLY_LEDGER_SUBTITLE"] = "Transações mensais recentes do personagem atual."
L["TEXT_PROFIT_SUBTITLE"] = "Weekly and monthly profit across your tracked characters."
L["TEXT_PROFIT_WARBAND_GRAPH_SUBTITLE"] = "Lucro diário combinado dos personagens acompanhados nos últimos 7 dias."
L["TEXT_PROFIT_WARBAND_LEDGER_WEEKLY_SUBTITLE"] = "Transações semanais combinadas recentes dos personagens acompanhados."
L["TEXT_PROFIT_WARBAND_MONTHLY_GRAPH_SUBTITLE"] = "Lucro diário combinado dos personagens acompanhados neste mês."
L["TEXT_PROFIT_SOURCE_AH_FEE"] = "Taxa da Casa de Leilões"
L["TEXT_PROFIT_SOURCE_BLACK_MARKET"] = "Black Market"
L["TEXT_PROFIT_SOURCE_CHEST"] = "Chest"
L["TEXT_PROFIT_SOURCE_CRAFT"] = "Craft"
L["TEXT_PROFIT_SOURCE_FLIGHT_PATH"] = "Flight Path"
L["TEXT_PROFIT_SOURCE_GUILD_BANK"] = "Guild Bank"
L["TEXT_PROFIT_SOURCE_LOOTED"] = "Looted"
L["TEXT_PROFIT_SOURCE_REPAIR"] = "Repair"
L["TEXT_PROFIT_SOURCE_TRAINING"] = "Training"
L["TEXT_PROFIT_SOURCE_WORLD_QUEST"] = "World Quest"
L["TEXT_PROFIT_WEEKLY_GRAPH_SUBTITLE"] = "Lucro líquido diário do personagem atual nos últimos 7 dias."
L["TEXT_PROFIT_WEEKLY_LEDGER_SUBTITLE"] = "Transações semanais recentes do personagem atual."
L["TEXT_TRACKED_ACHIEVEMENT_ENTRIES_UNAVAILABLE_FMT"] = "Ainda não foram adicionadas entradas acompanhadas para %s."
L["TIME_DAYS_AGO_FMT"] = "há %d d"
L["TIME_HOURS_AGO_FMT"] = "há %d h"
L["TIME_JUST_NOW"] = "Just now"
L["TIME_MINUTES_AGO_FMT"] = "há %d min"
L["TIME_YESTERDAY"] = "Yesterday"
L["TITLE_GLYPH_HUNTER"] = "Glyph Hunter"
L["OPTION_ENABLE_MINI_OMNIUM_FOLIO"] = "Enable Mini Omnium Folio"
L["OPTION_ENABLE_MINI_OMNIUM_FOLIO_DESC"] = "Show a movable Omnium Folio panel outside the main LiteVault window for quick node access."
L["TEXT_FOLIO_AVAILABLE_POINTS_FMT"] = "Available Points: %d"
L["TEXT_OMNIUM_FOLIO_UNAVAILABLE"] = "Omnium Folio is unavailable."
L["TITLE_MINI_OMNIUM_FOLIO"] = "Omnium Folio"
L["TOOLTIP_HIDE_MINI_FOLIO"] = "Hide Mini Folio"
L["TOOLTIP_LOCK_MINI_FOLIO"] = "Lock Mini Folio"
L["TOOLTIP_UNLOCK_MINI_FOLIO"] = "Unlock Mini Folio"
L["TEXT_PROFIT_TOKENS_THIS_MONTH_FMT"] = "Fichas neste mês: %d"
L["TITLE_PROFIT_WOW_TOKENS_THIS_MONTH"] = "Fichas de WoW neste mês"
L["TITLE_WOW_TOKEN_HISTORY"] = "WoW Token History"
L["TOOLTIP_PROFIT_WOW_TOKENS_THIS_MONTH"] = "Conta as Fichas de WoW compradas durante o mês atual. As compras de fichas são excluídas dos lucros totais."
L["TOOLTIP_RUNESTONE_EVENT"] = "Fortify the Runestones"
L["TOOLTIP_RUNESTONE_SET_WAYPOINT"] = "Click to set waypoint."
L["TOOLTIP_WOW_TOKEN_DESC"] = "Last known WoW Token market price."
L["TOOLTIP_WOW_TOKEN_TITLE"] = "WoW Token"

L["TEXT_ACHIEVEMENT_MOUNT_FMT"] = "Mount: %s"
L["LABEL_INFO"] = "Info"
L["Achievements"] = "Achievements"
L["Criteria"] = "Criteria"
L["Details"] = "Details"
L["Groups"] = "Groups"
L["Treasures of Midnight"] = "Treasures of Midnight"
L["Glory of the Midnight Delver"] = "Glory of the Midnight Delver"
L["Runestone Rush"] = "Runestone Rush"
L["The Party Must Go On"] = "The Party Must Go On"
L["A Singular Problem"] = "A Singular Problem"
L["From The Cradle to the Grave"] = "From The Cradle to the Grave"
L["Chronicler of the Haranir"] = "Chronicler of the Haranir"
L["Legends Never Die"] = "Legends Never Die"
L["Dust 'Em Off"] = "Dust 'Em Off"
L["No Time to Paws"] = "No Time to Paws"
L["Stormarion Assault"] = "Stormarion Assault"
L["Moths"] = "Moths"
L["Rares of Midnight"] = "Rares of Midnight"
L["Discover all of the lore objects found on the Coiled Isle."] = "Descubra todos os objetos de história de Coiled Isle."
L["%s contains %d moth coordinates. Click a moth to place a waypoint."] = "%s contém %d coordenadas de mariposas. Clique em uma mariposa para colocar um ponto de referência."
L["Abundance: Prosperous Plentitude!"] = "Abundance: Prosperous Plentitude!"


L["DIFFICULTY_LFR"] = "LFR"
L["LABEL_VAULT_TIER_FMT"] = "Tier %d"
L["LABEL_CRESTS"] = "Crests:"
L["TITLE_MOUNT_DROPS"] = "Mount Drops"
L["STATUS_COLLECTED_PARENS"] = "(Collected)"
L["STATUS_UNCOLLECTED_PARENS"] = "(Uncollected)"

L["LABEL_MAX_RENOWN"] = "Renome máximo"
L["TOOLTIP_FACTION_CARD_HINT"] = "Click to switch this faction."
L["TEXT_PROFIT_WARBAND_BREAKDOWN_SUBTITLE"] = "Distribuição das fontes de renda e gastos semanais do seu Bando de Guerra."
L["MSG_NO_GOLD_WORLD_QUESTS"] = "No active gold world quests found."
L["LEDGER_WORLD_QUESTS"] = "World Quests"
L["OPTION_DISABLE_RUNESTONE_MAP_PINS"] = "Desativar marcadores de Pedras Rúnicas"
L["OPTION_DISABLE_RUNESTONE_MAP_PINS_DESC"] = "Oculta os marcadores de Pedras Rúnicas do LiteVault no mapa da Floresta do Canto Eterno."
L["OPTION_ENABLE_CALENDAR_PROFIT_HIGHLIGHTS"] = "Ativar destaques de lucro no calendário"
L["OPTION_ENABLE_CALENDAR_PROFIT_HIGHLIGHTS_DESC"] = "Show green and red profit-day highlights on the calendar."
L["Void Strike"] = "Void Strike"
L["Void Assaults"] = "Void Assaults"
L["Void Assaults: Eversong Woods"] = "Void Assaults: Eversong Woods"
L["Void Assaults: Zul'Aman"] = "Void Assaults: Zul'Aman"
L["LABEL_NEXT_WEEK_FMT"] = "Next Week: %s"
L["Abundance Event"] = "Abundance Event"
L["Darkness Unmade"] = "Darkness Unmade"
L["Harvesting the Void"] = "Harvesting the Void"
L["Mining"] = "Mining"
L["Remnant of Anguish"] = "Remnant of Anguish"
L["Shard of Dundun"] = "Shard of Dundun"
L["Adventurer Dawncrest"] = "Adventurer Dawncrest"
L["Veteran Dawncrest"] = "Veteran Dawncrest"
L["Champion Dawncrest"] = "Champion Dawncrest"
L["Hero Dawncrest"] = "Hero Dawncrest"
L["Myth Dawncrest"] = "Myth Dawncrest"
L["Raid resync unavailable."] = "Raid resync unavailable."
L["Time played messages will be suppressed."] = "Time played messages will be suppressed."
L["The Dreamrift"] = "The Dreamrift"
L["Artisan"] = "Artesão"
L["Catch-up"] = "Catch-up"

L["LABEL_CHARACTER"] = "Character"


L["Midnight, the Highest Peaks"] = "Midnight, the Highest Peaks"
L["Explore Eversong Woods"] = "Explore Eversong Woods"
L["Explore Voidstorm"] = "Explore Voidstorm"
L["Explore Zul'Aman"] = "Explore Zul'Aman"
L["Explore Harandar"] = "Explore Harandar"
L["Thrill of the Chase"] = "Thrill of the Chase"
L["Making an Amani Out of You"] = "Making an Amani Out of You"
L["That's Aln, Folks!"] = "That's Aln, Folks!"
L["Forever Song"] = "Forever Song"
L["Yelling into the Voidstorm"] = "Yelling into the Voidstorm"
L["Light Up the Night"] = "Light Up the Night"
L["Altar of Blessings: Sacred Buffet Devotee"] = "Altar of Blessings: Sacred Buffet Devotee"

-- Register this locale
L["LABEL_FIRST_KILL"] = "Primeira vitória:"
L["LABEL_EARLIEST_RECORDED_KILL"] = "Primeira vitória registrada:"
L["TEXT_HISTORICAL_DATA_UNAVAILABLE"] = "Dados históricos indisponíveis"
L["LABEL_KNOWN_KILLS"] = "Vitórias conhecidas:"
L["LABEL_ALSO_KILLED_BY"] = "Também derrotado por:"
L["TEXT_KILL_DATE_UNAVAILABLE"] = "Data da vitória indisponível"

L["BUTTON_ZULJARRA_FORCES"] = "Zul'jarra's Forces"
L["BUTTON_CAPTAIN_TOKKA"] = "Capitã Tokka"
L["LABEL_VALEERA_SANGUINAR"] = "Valeera Sanguinar"
L["LABEL_SLAYERS_DUELLUM"] = "Slayer's Duellum"
L["LABEL_MAXIMUM"] = "Maximum"
L["BUTTON_FACTION_WEEKLIES"] = "Faction Weeklies"
L["TITLE_TREASURES_OF_THE_DAMNED"] = "Treasures of the Damned"
L["LABEL_COMPLETED"] = "Completed"
L["LABEL_NOT_COMPLETED"] = "Not Completed"
L["LABEL_QUEST_FMT"] = "Missão: %s"
L["LABEL_QUEST_ID_FMT"] = "ID da missão: %d"
L["TOOLTIP_TOKKA_TREASURE_HINT"] = "Fish this artifact up on the Coiled Isle and return it to Second Mate Sluggs at Tokka's Folly."
L["WARNING_TOKKA_ONE_TIME_ARTIFACTS"] = "Warning: These artifact quests are one-time Warband turn-ins. They do not reset daily or weekly and can only reward reputation once."
L["Turn Back the Surge"] = "Turn Back the Surge"
L["Purging the Vaults"] = "Purging the Vaults"
L["Spark of Tides"] = "Spark of Tides"
L["Venomblight Manaflux"] = "Venomblight Manaflux"
L["Adventurer Mistcrest"] = "Adventurer Mistcrest"
L["Veteran Mistcrest"] = "Veteran Mistcrest"
L["Champion Mistcrest"] = "Champion Mistcrest"
L["Hero Mistcrest"] = "Hero Mistcrest"
L["Myth Mistcrest"] = "Myth Mistcrest"
L["Corrosive Coin"] = "Corrosive Coin"
L["Trailing Xal'atath"] = "Trailing Xal'atath"
L["My Venomous Nemesis"] = "My Venomous Nemesis"
L.LABEL_CURRENT_CHARACTER = L.LABEL_CURRENT_CHARACTER or "Personagem atual"
L.LABEL_WARBAND_THIS_WEEK = L.LABEL_WARBAND_THIS_WEEK or "Bando nesta semana"
L.LABEL_RUNS = L.LABEL_RUNS or "Corridas"
L.STATUS_TIMED = L.STATUS_TIMED or "No tempo"
L.STATUS_DEPLETED = L.STATUS_DEPLETED or "Esgotada"
L.LABEL_BEST_TIMED = L.LABEL_BEST_TIMED or "Melhor no tempo"
L.FILTER_THIS_WEEK = L.FILTER_THIS_WEEK or "Nesta semana"
L.FILTER_SEASON = L.FILTER_SEASON or "Temporada"
L.FILTER_ALL_HISTORY = L.FILTER_ALL_HISTORY or "Todo o histórico"
L.SECTION_SEASON_BESTS = L.SECTION_SEASON_BESTS or "Melhores da temporada"
L.LABEL_BEST = L.LABEL_BEST or "Melhor"
L.LABEL_SCORE = L.LABEL_SCORE or "Pontuação"
L.LABEL_NO_RUN = L.LABEL_NO_RUN or "Sem corrida"
L.LABEL_LOWEST_SCORE = L.LABEL_LOWEST_SCORE or "Menor pontuação"
L.LABEL_NO_MPLUS_KEY = L.LABEL_NO_MPLUS_KEY or "Sem chave M+"
L.LABEL_DUNGEON = L.LABEL_DUNGEON or "Masmorra"
L.LABEL_KEY = L.LABEL_KEY or "Chave"
L.LABEL_RESULT = L.LABEL_RESULT or "Resultado"
L.LABEL_TIME = L.LABEL_TIME or "Tempo"
L.LABEL_DATE = L.LABEL_DATE or "Data"
L.LABEL_REWARDS = L.LABEL_REWARDS or "Recompensas"
L.LABEL_MAP_RECORD = L.LABEL_MAP_RECORD or "Recorde do mapa"
L.LABEL_AFFIX_RECORD = L.LABEL_AFFIX_RECORD or "Recorde de afixos"
L.LABEL_MPLUS_SCORE_PLAIN = L.LABEL_MPLUS_SCORE_PLAIN or "Pontuação M+"
L.LABEL_TIMER = L.LABEL_TIMER or "Cronômetro"
L.LABEL_TIME_REMAINING = L.LABEL_TIME_REMAINING or "Tempo restante"
L.LABEL_OVER_TIMER = L.LABEL_OVER_TIMER or "Acima do tempo"
L.LABEL_RECORDED_DURATION = L.LABEL_RECORDED_DURATION or "Duração registrada"
L.LABEL_NOT_AVAILABLE = L.LABEL_NOT_AVAILABLE or "--"
L.SECTION_MPLUS_HISTORY = L.SECTION_MPLUS_HISTORY or "Histórico de Mítica+"
L.TEXT_NO_MPLUS_RUNS_THIS_WEEK = L.TEXT_NO_MPLUS_RUNS_THIS_WEEK or "Nenhuma Mítica+ concluída nesta semana."
L.TEXT_NO_MPLUS_RUNS_THIS_SEASON = L.TEXT_NO_MPLUS_RUNS_THIS_SEASON or "Nenhuma Mítica+ concluída nesta temporada."
L.TEXT_NO_MPLUS_RUNS_RECORDED = L.TEXT_NO_MPLUS_RUNS_RECORDED or "Nenhuma Mítica+ registrada."
L.BUTTON_PLAN_RATING = L.BUTTON_PLAN_RATING or "Planejar pontuação"
L.TITLE_MPLUS_RATING_PLANNER = L.TITLE_MPLUS_RATING_PLANNER or "Planejador de pontuação M+"
L.BUTTON_BACK_TO_DASHBOARD = L.BUTTON_BACK_TO_DASHBOARD or "Voltar ao painel"
L.LABEL_CURRENT_RATING = L.LABEL_CURRENT_RATING or "Pontuação atual"
L.LABEL_TARGET_RATING = L.LABEL_TARGET_RATING or "Pontuação alvo"
L.LABEL_MINIMUM_KEY = L.LABEL_MINIMUM_KEY or "Chave mínima"
L.LABEL_MAXIMUM_KEY = L.LABEL_MAXIMUM_KEY or "Chave máxima"
L.LABEL_AVOID_DUNGEONS = L.LABEL_AVOID_DUNGEONS or "Evitar masmorras"
L.BUTTON_CALCULATE_PLAN = L.BUTTON_CALCULATE_PLAN or "Calcular plano"
L.LABEL_MAXIMUM_PROJECTED_RATING = L.LABEL_MAXIMUM_PROJECTED_RATING or "Pontuação máxima projetada"
L.LABEL_PROJECTED_RATING = L.LABEL_PROJECTED_RATING or "Pontuação projetada"
L.LABEL_CURRENT = L.LABEL_CURRENT or "Atual"
L.LABEL_PLAN = L.LABEL_PLAN or "Plano"
L.LABEL_GAIN = L.LABEL_GAIN or "Ganho"
L.TEXT_PLANNER_ALREADY_REACHED = L.TEXT_PLANNER_ALREADY_REACHED or "Você já alcançou esta pontuação."
L.TEXT_PLANNER_UNREACHABLE = L.TEXT_PLANNER_UNREACHABLE or "O alvo não pode ser alcançado com os limites atuais."
L.TEXT_PLANNER_INVALID_MINIMUM = L.TEXT_PLANNER_INVALID_MINIMUM or "A chave mínima deve ser um inteiro igual ou maior que 2."
L.TEXT_PLANNER_INVALID_MAXIMUM = L.TEXT_PLANNER_INVALID_MAXIMUM or "A chave máxima deve ser no mínimo a chave mínima e no máximo 20."
L.TEXT_PLANNER_INVALID_TARGET = L.TEXT_PLANNER_INVALID_TARGET or "Insira uma pontuação alvo inteira válida."
L.TEXT_PLANNER_TIMED_ASSUMPTION = L.TEXT_PLANNER_TIMED_ASSUMPTION or "A projeção pressupõe que cada chave sugerida seja concluída no tempo."
L.PLANNER_FASTEST = L.PLANNER_FASTEST or "MAIS RÁPIDO"
L.PLANNER_BALANCED = L.PLANNER_BALANCED or "EQUILIBRADO"
L.PLANNER_EASIEST = L.PLANNER_EASIEST or "MAIS FÁCIL"
local phase2 = {
MSG_NO_FACTION_WEEKLY_COMPLETIONS="Nenhuma conclusão semanal registrada.", TOOLTIP_QUEST_ID_FMT="ID: |cffffffff%d", CALENDAR_MONTH_YEAR_FMT="%s de %d",
LABEL_RENOWN_LEVEL_MAXIMUM_FMT="Nível de Renome %d - Máximo", LABEL_RENOWN_LEVEL_PROGRESS_FMT="Nível de Renome %d (%d/%d)", LABEL_RENOWN_LEVEL_FMT="Nível de Renome %d", LABEL_RENOWN_VALUE_FMT="Renome %d",
TEXT_CRESTS_WITH_VALUES_FMT="Brasões %s", TOOLTIP_REWARDS_FMT="Recompensas: %s", TOOLTIP_MOUNT_COLLECTED_FMT="%s (Coletada)", TOOLTIP_MOUNT_UNCOLLECTED_FMT="%s (Não coletada)", LABEL_REWARD="Recompensa", LABEL_NOTE="Observação", STATUS_ACTIVE="Ativo",
TOOLTIP_ENTRANCE_COORDINATES_FMT="Entrada: %.2f, %.2f (mapa %d)", TOOLTIP_INSCRIPTION_COORDINATES_FMT="Inscrição: %.2f, %.2f (mapa %d)", TOOLTIP_ENTRANCE_INSCRIPTION_CLICK_INSTRUCTIONS="Shift-clique para a entrada; clique para a inscrição.", LABEL_100_RENOWN_FMT="100 de Renome: %s", TOOLTIP_ACHIEVEMENT_CREDIT_FROM_FMT="Crédito da conquista concedido por: %s",
NOTE_HARANDAR_TREASURE_REQUIREMENTS="Alguns tesouros exigem etapas ou itens adicionais para serem abertos.", NOTE_FORGOTTEN_MASK_LOCATION="Em uma parede de pedra quebrada na Ilha Gnarldor, ao sul da entrada da imersão.", NOTE_HEAD_MASONS_TABLET_LOCATION="Dentro do Portão da Presa Oriental. Entrada: 45.72, 64.94 no mapa 2512.", NOTE_PROFANED_PLAQUE_LOCATION="Dentro do Portão da Presa Ocidental, na sala imediatamente à esquerda após entrar. Entrada: 31.80, 64.91 no mapa 2512.",
BUTTON_CANCEL="Cancelar", BUTTON_SAVE="Salvar", BUTTON_SELECT_ALL="Selecionar tudo", LABEL_COMPLETED="Concluído", LABEL_NOT_COMPLETED="Não concluído", LABEL_DETAILS="Detalhes", LABEL_DETAIL="Detalhe", LABEL_INFO="Informações", LABEL_MAXIMUM="Máximo", LABEL_PREVIOUS="Anterior", LABEL_RECENT_HISTORY="Histórico recente", LABEL_SOURCE="Origem", LABEL_STATUS="Status", TIME_JUST_NOW="Agora mesmo", TIME_YESTERDAY="Ontem",
BUTTON_BACK_TO_GROUPS="Voltar aos grupos", TEXT_COORDINATE_GROUPS_NOT_AVAILABLE="Os grupos de coordenadas ainda não foram adicionados.", TEXT_ZONE_REWARD_NOT_AVAILABLE="A recompensa da zona ainda não foi adicionada.", TEXT_META_REWARD_NOT_AVAILABLE="A recompensa da meta-conquista ainda não foi adicionada.", TEXT_ACHIEVEMENT_REWARD_NOT_LISTED="Nenhuma recompensa de conquista informada.", TOOLTIP_RUNESTONE_CHARGE_INSTRUCTION="Carregue a pedra rúnica com Arcano Latente para iniciar o evento de defesa.", TEXT_COORDINATES_PENDING="Coordenadas pendentes.", TOOLTIP_CLICK_OPEN_TRACKER="Clique para abrir este rastreador.", TEXT_TRACKER_NOT_AVAILABLE="Rastreador ainda não adicionado.",
MSG_PROFIT_GOAL_INVALID="Insira uma quantidade válida de ouro.", MSG_PROFIT_GOAL_NOT_SET="Nenhuma meta definida", TEXT_PROFIT_EXPORT_HINT="Clique na caixa e pressione Ctrl+C para copiar.", TEXT_PROFIT_EXPORT_SUBTITLE="Copie o texto CSV abaixo.", TEXT_PROFIT_SOURCE_BLACK_MARKET="Mercado Negro", TEXT_PROFIT_SOURCE_CHEST="Baú", TEXT_PROFIT_SOURCE_CRAFT="Criação", TEXT_PROFIT_SOURCE_FLIGHT_PATH="Rota de voo", TEXT_PROFIT_SOURCE_GUILD_BANK="Banco da guilda", TEXT_PROFIT_SOURCE_LOOTED="Saqueado", TEXT_PROFIT_SOURCE_REPAIR="Reparo", TEXT_PROFIT_SOURCE_TRAINING="Treinamento", TEXT_PROFIT_SOURCE_WORLD_QUEST="Missão mundial", MSG_RAID_RESYNC_COMPLETE="Ressincronização de raide concluída.", MSG_RAID_RESYNC_STARTED="Ressincronização de raide iniciada...", MSG_RAID_RESYNC_UNAVAILABLE="Ressincronização de raide indisponível.",
TEXT_PROFIT_FALLBACK_APPEARANCE_COST="Custo de aparência", TEXT_PROFIT_FALLBACK_AUCTION_DEPOSIT="Depósito de leilão", TEXT_PROFIT_FALLBACK_AUCTION_FEE="Taxa de leilão", TEXT_PROFIT_FALLBACK_AUCTION_PURCHASE="Compra em leilão", TEXT_PROFIT_FALLBACK_AUCTION_SALE="Venda em leilão", TEXT_PROFIT_FALLBACK_BARBER_COST="Custo de barbearia", TEXT_PROFIT_FALLBACK_BLACK_MARKET_PURCHASE="Compra no Mercado Negro", TEXT_PROFIT_FALLBACK_CRAFTING_ORDER="Ordem de serviço", TEXT_PROFIT_FALLBACK_GEAR_UPGRADE="Aprimoramento de equipamento", TEXT_PROFIT_FALLBACK_GOLD_RECEIVED="Ouro recebido", TEXT_PROFIT_FALLBACK_GOLD_REWARD="Recompensa em ouro", TEXT_PROFIT_FALLBACK_GOLD_SENT="Ouro enviado", TEXT_PROFIT_FALLBACK_GUILD_DEPOSIT="Depósito da guilda", TEXT_PROFIT_FALLBACK_GUILD_WITHDRAWAL="Saque da guilda", TEXT_PROFIT_FALLBACK_RAW_GOLD="Ouro direto", TEXT_PROFIT_FALLBACK_SERVICE_COST="Custo de serviço", TEXT_PROFIT_FALLBACK_TRADE_GAIN="Ganho de troca", TEXT_PROFIT_FALLBACK_TRADE_PAYMENT="Pagamento de troca", TEXT_PROFIT_FALLBACK_TRAINING_COST="Custo de treinamento", TEXT_PROFIT_FALLBACK_TRAVEL_COST="Custo de viagem", TEXT_PROFIT_GRAPH_EMPTY_MONTHLY="Ainda não há histórico mensal de lucro.", TEXT_PROFIT_GRAPH_EMPTY_WARBAND="Ainda não há histórico de lucro do Bando de Guerra.", TEXT_PROFIT_GRAPH_EMPTY_WARBAND_MONTHLY="Ainda não há histórico mensal de lucro do Bando de Guerra.", TEXT_PROFIT_GRAPH_EMPTY_WEEKLY="Ainda não há histórico semanal de lucro.", TEXT_PROFIT_LEDGER_EMPTY_MONTHLY="Ainda não há transações mensais registradas.", TEXT_PROFIT_LEDGER_EMPTY_WARBAND="Ainda não há transações do Bando de Guerra registradas.", TEXT_PROFIT_LEDGER_EMPTY_WEEKLY="Ainda não há transações semanais registradas.", TEXT_PROFIT_SUBTITLE="Lucro semanal e mensal dos seus personagens rastreados.",
BUTTON_BREAKDOWN="Detalhamento", BUTTON_FILTER="Filtrar", BUTTON_SET="Definir", BUTTON_RAIDS="Raides", BUTTON_WARBAND_BANK_HISTORY="Histórico do banco do Bando de Guerra", TITLE_TREASURES_OF_THE_DAMNED="Tesouros dos Condenados", TOOLTIP_TOKKA_TREASURE_HINT="Pesque este artefato em Coiled Isle e devolva-o a Second Mate Sluggs em Tokka's Folly.", WARNING_TOKKA_ONE_TIME_ARTIFACTS="Aviso: estas missões de artefato são entregas únicas do Bando de Guerra. Elas não reiniciam diária nem semanalmente e só concedem reputação uma vez.", MSG_RAID_HISTORY_PRESERVED="O histórico de raides foi preservado; a redefinição destrutiva da temporada está desativada.", TOOLTIP_RAID_BOSS_DIFFICULTY_FMT="%s — %s", TITLE_MINI_OMNIUM_FOLIO="Fólio de Omnium", TOOLTIP_HIDE_MINI_FOLIO="Ocultar Mini Fólio", TOOLTIP_LOCK_MINI_FOLIO="Bloquear Mini Fólio", TOOLTIP_UNLOCK_MINI_FOLIO="Desbloquear Mini Fólio", TAB_GLYPHS="Glifos", TITLE_GLYPH_HUNTER="Caçador de Glifos", TOOLTIP_RUNESTONE_SET_WAYPOINT="Clique para definir um ponto de referência.", LABEL_CHARACTER_TIME="Tempo do personagem", LABEL_LAST_UPDATED="Última atualização", LABEL_VAULT_OVERALL_PROGRESS="Progresso geral: %d/%d", LABEL_VAULT_ROW_DUNGEONS="Masmorras", TITLE_CHARACTER_GREAT_VAULT_FMT="Grande Cofre de %s: %s", TITLE_CHARACTER_WEEKLY_PLANNER_FMT="Planejador semanal de %s: %s", LABEL_NEXT_WEEK_FMT="Próxima semana: %s",
BUTTON_EDIT_MONTHLY_GOAL="Editar meta mensal", BUTTON_EDIT_WEEKLY_GOAL="Editar meta semanal", BUTTON_EXPORT_CSV="Exportar CSV", BUTTON_MONTHLY_PROFIT_EXPORT="Lucro mensal em CSV", BUTTON_WARBAND_PROFIT_BREAKDOWN="Detalhamento do Bando de Guerra", BUTTON_WARBAND_PROFIT_EXPORT="Lucro semanal do Bando de Guerra em CSV", BUTTON_WEEKLY_PROFIT_EXPORT="Lucro semanal em CSV", LABEL_GOAL_AMOUNT="Valor da meta (ouro)", LABEL_GOLD="Ouro", LABEL_NET="Líquido", LABEL_SHARE="Compartilhar", LABEL_ZONE="Zona", LABEL_WARBAND_WEEKLY_PROFIT="Lucro semanal do Bando de Guerra", MSG_NIT_TIMEPLAYED_WARNING="NovaInstanceTracker detectado. O NIT pode ocultar a mensagem /played mesmo quando a opção do LiteVault está desativada.", MSG_TIMEPLAYED_RESTORED="Mensagens de tempo de jogo restauradas.", MSG_TIMEPLAYED_SUPPRESSED="As mensagens de tempo de jogo serão ocultadas.", MSG_WOW_TOKEN_API_UNAVAILABLE="A API da Ficha de WoW não está disponível neste cliente.", MSG_WOW_TOKEN_DATA_UNAVAILABLE="Dados da Ficha de WoW indisponíveis.", MSG_WOW_TOKEN_VISIT_AH="Visite a Casa de Leilões para atualizar o preço da Ficha de WoW.", OPTION_ENABLE_CALENDAR_PROFIT_HIGHLIGHTS_DESC="Mostra destaques verdes e vermelhos nos dias de lucro ou prejuízo do calendário.",
TITLE_ACHIEVEMENTS="Conquistas", LABEL_ACHIEVEMENT_GROUPS="Grupos", LABEL_GLOWING_MOTHS="Mariposas", LABEL_SHARED_LOOT="Saque compartilhado", LABEL_KNOWLEDGE_CATCHUP="Recuperação", STATUS_ASSAULT_WAVE_1_COMPLETE="Onda 1 concluída", STATUS_ASSAULT_WAVE_2_COMPLETE="Onda 2 concluída", STATUS_ASSAULT_WAVE_3_COMPLETE="Onda 3 concluída", TEXT_MIDNIGHT_RARES_TRACKER_DESCRIPTION="Rastreie conquistas de raros de Midnight, recompensas e saques compartilhados.", TEXT_MIDNIGHT_TREASURES_TRACKER_DESCRIPTION="Rastreie as conquistas de tesouros de Midnight e suas recompensas.", TEXT_HARANIR_JOURNAL_INSTRUCTION="Recupere as entradas do diário haranir listadas abaixo.", TEXT_HARANIR_LEGEND_DEFENSE_INSTRUCTION="Defenda cada local de lenda haranir listado abaixo.", TEXT_BLESSING_EFFECT_INSTRUCTION="Ative cada efeito de bênção listado para obter crédito.", TOOLTIP_CAVE_RUN_CREDIT_INSTRUCTION="Conclua a exploração desta caverna para obter crédito.", TEXT_TELESCOPE_ZONE_REQUIREMENT="Conclua os cinco telescópios desta zona.",
TEXT_MIDNIGHT_DELVER_META_INSTRUCTION="Conclua as quatro conquistas auxiliares de imersões de Midnight para finalizar esta meta-conquista.", TEXT_COILED_ISLE_META_INSTRUCTION="Conclua as conquistas de Coiled Isle.", TEXT_MIDNIGHT_ZONE_META_REWARD_REQUIREMENT="Conclua as quatro meta-conquistas de zona de Midnight e receba a montaria como recompensa.", TEXT_CLAW_ENFORCEMENT_REQUIREMENT="Conclua a missão mundial de Harandar 'Claw Enforcement' com pelo menos 15 aplicações de Predator's Pursuit.", TEXT_ATALUTEK_META_INSTRUCTION="Conclua as conquistas de Vaults of Atal'Utek.", TEXT_COILED_ISLE_LORE_INSTRUCTION="Descubra os objetos de história de Coiled Isle.", TEXT_HUNGERING_PRESENCE_REQUIREMENT="Escape das garras de Hungering Presence em Voidstorm por pelo menos 60 segundos.", TEXT_CRADLE_FLIGHT_REQUIREMENT="Voe até The Cradle, bem acima de Harandar, para concluir esta conquista.", TEXT_EVERSONG_META_TRACKER_DESCRIPTION="Rastreie a meta-conquista de Eversong Woods e acesse seus rastreadores secundários.", TEXT_MIDNIGHT_PEAKS_TRACKER_DESCRIPTION="Rastreie as quatro conquistas de zona de Midnight, the Highest Peaks.", TEXT_HARANDAR_META_TRACKER_DESCRIPTION="Rastreie a meta-conquista de Harandar e acesse seus rastreadores secundários.", TEXT_VOIDSTORM_META_TRACKER_DESCRIPTION="Rastreie a meta-conquista de Voidstorm e acesse seus rastreadores secundários.", TEXT_ZULAMAN_META_TRACKER_DESCRIPTION="Rastreie a meta-conquista de Zul'Aman e acesse seus rastreadores secundários.", TEXT_CRADLE_FLIGHT_ATTEMPT="Tente voar até The Cradle, bem acima de Harandar.", NOTE_MOTH_ROUTE_RENOWN_REQUIREMENT="A rota do LiteVault pressupõe que Hara'ti Renown 11 já esteja desbloqueado.",
TEXT_HARATI_META_PROGRESS_INSTRUCTION="Ajude os Hara'ti concluindo as conquistas abaixo. x/y concluídas.", TEXT_VOIDSTORM_META_PROGRESS_INSTRUCTION="Conclua todas as conquistas de Voidstorm listadas abaixo. x/y concluídas.", TEXT_ZULAMAN_META_PROGRESS_INSTRUCTION="Conclua todas as conquistas de Zul'Aman listadas abaixo. x/y concluídas.", TEXT_STORMARION_ASSAULT_PROGRESS_INSTRUCTION="Conclua as três ondas de Stormarion Assault. x/y marcadas.", TEXT_ABUNDANT_HARVEST_PROGRESS_INSTRUCTION="Conclua uma exploração de caverna de Abundant Harvest em cada local. x/y marcadas.", TEXT_EVERSONG_META_PROGRESS_INSTRUCTION="Conclua as conquistas de Eversong Woods listadas abaixo. x/y concluídas.", TEXT_GLOWING_MOTH_PROGRESS="Encontre todas as Glowing Moths escondidas em Harandar. x/y encontradas.", TEXT_HARANIR_LEGEND_PROGRESS="Proteja cada local de lenda haranir listado abaixo. x/y marcados.", TEXT_XALATATH_META_PROGRESS="Reúna suas forças contra Xal'atath concluindo as conquistas abaixo. x/y concluídas.", TEXT_HARANIR_JOURNAL_PROGRESS="Recupere as entradas do diário haranir listadas abaixo. x/y marcadas.", TEXT_BLESSING_EFFECT_PROGRESS="Ative cada efeito de bênção listado. x/y marcados.", TEXT_FACTION_INVITE_PROGRESS="Rastreie os quatro convites de facção de The Party Must Go On. x/y marcados.", TEXT_EVER_PAINTING_PROGRESS="Rastreie as telas conhecidas de Ever-Painting. x/y marcadas.", TEXT_RUNESTONE_RUSH_PROGRESS="Rastreie as entradas conhecidas de Runestone Rush. x/y marcadas.",
TEXT_DELVER_MOUNT_REWARD_REQUIREMENT="Conclua Glory of the Midnight Delver para obter esta montaria.", NOTE_MOTH_GROUP_1_RENOWN="As mariposas 1–40 aparecem em Hara'ti Renown 1, e o rastreamento em Renown 2.", NOTE_MOTH_GROUP_2_RENOWN="As mariposas 41–80 aparecem em Hara'ti Renown 4, e o rastreamento em Renown 6.", NOTE_MOTH_GROUP_3_RENOWN="As mariposas 81–120 aparecem em Hara'ti Renown 9, e o rastreamento em Renown 11.", NOTE_HARANIR_JOURNAL_AVAILABILITY="Estes diários só ficam disponíveis durante a missão semanal vinculada à conta 'Legends of the Haranir'. Durante uma visão, procure o ícone de lupa no minimapa.", NOTE_CLAW_ENFORCEMENT_NO_COORDINATES="Esta conquista não precisa de rastreamento de coordenadas no LiteVault. Conclua a missão mundial de Harandar 'Claw Enforcement' com pelo menos 15 aplicações de Predator's Pursuit.", NOTE_HUNGERING_PRESENCE_NO_COORDINATES="Esta conquista não precisa de rastreamento de coordenadas no LiteVault. Sobreviva ao evento Hungering Presence em Voidstorm por pelo menos 60 segundos.", NOTE_HARANIR_LEGENDS_WEEKLY_ESTIMATE="Isto está vinculado à missão semanal da conta 'Legends of the Haranir'. Se você ainda não tem progresso, a conclusão deve levar cerca de 7 semanas.", NOTE_MOTH_TRACKER_GROUPING="Este rastreador é dividido em 3 grupos de 40 coordenadas para manter as rotas de mariposas organizadas.", TEXT_EVER_PAINTING_TRACKER_PLACEHOLDER="Rastreie o progresso de Ever-Painting. Os detalhes podem ser adicionados mais tarde.", TEXT_EXPLORE_EVERSONG_TRACKER_PLACEHOLDER="Rastreie o progresso de Explore Eversong Woods. Os detalhes podem ser adicionados mais tarde.", TEXT_RUNESTONE_RUSH_TRACKER_PLACEHOLDER="Rastreie o progresso de Runestone Rush. Os detalhes podem ser adicionados mais tarde.", TEXT_PARTY_TRACKER_PLACEHOLDER="Rastreie o progresso de The Party Must Go On. Os detalhes podem ser adicionados mais tarde.", TOOLTIP_ABUNDANT_HARVEST_CREDIT_REQUIREMENT="Você precisa concluir uma exploração de caverna de Abundant Harvest em cada local. Apenas visitar a caverna não basta.",
TEXT_EXPLORE_EVERSONG_PROGRESS="Rastreie o progresso de Explore Eversong Woods. x/y marcados.", TEXT_EXPLORE_HARANDAR_PROGRESS="Rastreie o progresso de Explore Harandar. x/y marcados.", TEXT_EXPLORE_VOIDSTORM_PROGRESS="Rastreie o progresso de Explore Voidstorm. x/y marcados.", TEXT_EXPLORE_ZULAMAN_PROGRESS="Rastreie o progresso de Explore Zul'Aman. x/y marcados.",
}
for key,value in pairs(phase2) do L[key]=value end
L.NOTE_RITUAL_BEHAVIOR_VENOMOUS_OOZE = "Mate Gigantes Venenosos na área central do ritual para obter Gosma Venenosa."
L.TEXT_FACTION_WEEKLY_STILL_NEEDED_FMT = "Ainda precisam: %s"
L.TEXT_ALL_TRACKED_CHARACTERS_COMPLETED = "Todos os personagens rastreados concluíram"
L.TEXT_NO_TRACKED_CHARACTERS = "Nenhum personagem rastreado"
L.OPTION_DISABLE_VOLUME_FOG = "Desativar névoa volumétrica"
L.OPTION_DISABLE_VOLUME_FOG_DESC = "Remove a névoa volumétrica e a neblina atmosférica. Desativar esta opção restaura a névoa."
lv.RegisterLocale("ptBR", L)

-- Store for reload functionality
lv.LocaleData = lv.LocaleData or {}
lv.LocaleData["ptBR"] = L
