# LiteVault Changelog

## 12.1.5.1 (unreleased draft)

Compatibility release for World of Warcraft Retail 12.1.5.

Verification status: the changes below were checked by code review and LiteVault's
automated suite (Lua 5.1 compile, upvalue-limit check, source assertions, locale
validation). In-game testing on 12.1.5 is still pending; see STABILITY_TEST_CHECKLIST.md.

### New raid: The Unbinding of Kith'ix

- Added The Unbinding of Kith'ix (one boss, Kith'ix) to Season 2 raid tracking: the raid
  window tab, Character / This Week / Warband rows, the roster raid badge, saved-lockout
  import, `/lvraidresync`, and the weekly reset.
- Raid Finder, Normal, Heroic and Mythic are tracked. Kith'ix Mythic uses Blizzard's
  flexible 15-25 player Mythic difficulty, which LiteVault now recognizes.
- Story Mode is not tracked: Blizzard's data gives it no saved lockout.
- Kills are matched by Blizzard's instance and encounter IDs, so they are recorded on every
  client language. The raid and boss names are shown in all nine supported languages.

### Compatibility

- Added interface 120105 (Retail 12.1.5) to the TOC.
- Replaced removed global item and money APIs with their current equivalents:
  `C_Item.GetItemCount`, `C_Item.GetItemInfo`, `C_Item.GetItemInfoInstant`,
  `C_Item.GetItemQualityColor`, `C_Item.GetDetailedItemLevelInfo`,
  `C_Item.GetItemIconByID` and `C_CurrencyInfo.GetCoinTextureString`.
- The character card right-click menu (Ignore / Restore / Delete) now uses the Retail
  `MenuUtil` context menu. The previous `EasyMenu` call was removed from Retail and
  raised an error.
- Closing the mailbox is now detected on Retail, which no longer sends the old
  `MAIL_CLOSED` event. The character data refresh and currency rescan after a mailbox
  visit run again, once per visit.
- The gold tracker no longer adds a second auction sale entry when the mailbox closes.
  Auction mail income is recorded once, when the gold arrives.
- Fixed a Lua error when the character overlay option was toggled after a gear-slot
  flyout had been opened in the same session.

### Weekly reset and Great Vault

- Character class and region are recorded before weekly reset processing runs.
- Weekly reset and the Great Vault snapshot now run before other character data is
  collected, so a later failure cannot leave weekly timestamps stale.
- The character that triggers a weekly reset always has its reset timestamp advanced.
- Character refreshes run through WoW's error handler, so a failure reports a full
  stack trace instead of silently stopping the refresh.

### Raid tracking

- The Voidspire, The Dreamrift, March on Quel'Danas, The Venomous Abyss and
  The Tidebound Grotto are now identified by their Blizzard instance IDs, so lockouts
  and kills are recognized on every client language. Name matching remains as a
  fallback.
- Removed an incorrect Sporefall identifier (a zone ID, not an instance ID). Sporefall
  continues to use name matching.
- The Tidebound Grotto now tracks Mythic and World kills. Blizzard runs it on flexible
  Mythic and World difficulties, which LiteVault previously did not display.
- Venomous Abyss saved lockouts are now matched to bosses by name in all nine supported
  languages instead of by list position. Blizzard's lockout list is not in boss order, and
  in Raid Finder it counts every encounter in the raid, so position could mark the wrong boss.
- Venomous Abyss and Tidebound Grotto kills are matched by Blizzard's encounter IDs, and
  their boss names are shown in all nine supported languages.

### Character management

- All character management is now in the character card's right-click menu:
  Favorite / Unfavorite, Ignore / Restore, Delete (still asks for confirmation) and Cancel.
- The Actions menu keeps Bags and Gear only, and its button is hidden when neither is
  available (for example in Manage mode).
- Favorite characters show a gold star next to their name.
- Race and specialization now appear on their own line under the character name and realm,
  so long names no longer push them off the card.
- Character cards show Blizzard's mail envelope (the minimap new-mail icon) when a character has mail: new mail reported by the
  game, or items left in the mailbox at the last visit. Hover for details. Other characters
  show their last known status, which updates the next time they log in.

### Cleanup

- Removed unused internal functions from Achievements, Currency, Raid Lockouts,
  Profit, the main UI and the gold tracker.
- The temporary fishing diagnostic (`/lvfishdebug`) and its "Fishing diagnostic"
  keybinding are no longer part of the release.

### Packaging

- Release archives now use forward-slash paths, so they extract correctly on macOS,
  Linux and in addon managers, not only in Windows Explorer.
- Release packaging now excludes the `dist` folder, the fishing diagnostic and an
  unused image.

### Known limitations

- Labyrinth (Kindo'jan) progress is not tracked.
- Venomous Abyss kills recorded from a saved lockout before this version used list
  position and may show on the wrong boss; they are not rewritten automatically.
